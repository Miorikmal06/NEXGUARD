-- Plate audit trail: every time a plate is removed from the whitelist, WHO removed it,
-- WHICH plate it was and WHEN is recorded here. Run once in the Supabase SQL Editor.
-- Safe to run multiple times (IF NOT EXISTS guards). Nothing here modifies existing tables.
--
-- action: deleted  = a guard removed the plate from the dashboard
--         expired  = visitor pass auto-removed by the expiry sweep (performed_by = 'system')
--         cancelled = visitor pass cancelled by a resident via Telegram
--         replaced = expired-but-unswept pass replaced by a new pass

create table if not exists plate_audit (
    id bigint generated always as identity primary key,
    action text not null default 'deleted',
    plate_id bigint,
    plate_number text not null,
    owner_name text,
    house_no text,
    is_visitor boolean,
    performed_by text not null,          -- guard full_name, 'system' or 'resident: <name>'
    performed_by_id bigint,              -- guards.id when a guard did it (null for system / resident)
    created_at timestamptz not null default now()
);
create index if not exists idx_plate_audit_created on plate_audit (created_at desc);
create index if not exists idx_plate_audit_plate on plate_audit (plate_number);
