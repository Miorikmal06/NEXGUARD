# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

FYP prototype (demo only, not deployed at a real site) of a smart guardhouse for a gated residential area. A Flask dashboard on one Windows laptop reads a webcam, detects plates with YOLO (`models/license_plate_detector.pt`, pretrained single-class) + EasyOCR, checks them against a Supabase (Postgres) whitelist of resident plates and expiring visitor passes, logs every pass, and sends an "open" signal to a Raspberry Pi barrier for registered plates.

- **Users:** only guards use the dashboard — roles `guard` and `head_guard`. Residents do not log in (a resident-only Telegram bot is planned, see below).
- **Deployment:** single laptop at the guardhouse, accessed via localhost.
- **Pi:** receiver runs at `172.20.10.2:5000` and is confirmed working, but its code (the `/plate_detected` endpoint) is **not** in this repo.
- Docs (`README.md`, `CHANGES.md`, `SETUP_TODO.md`) and many code comments are in Malay; the user communicates in Malay. `CHANGES.md` is the running changelog of why detection was tuned the way it is. `README.md` is partly stale (still mentions SQLite/`plates.db` and gate OFF by default).

## Working agreement

Code has been tested by the user and works. Before changing code, explain the plan and ask the user (with options) — don't assume.

## Commands

```bash
python -m venv venv && venv\Scripts\activate
pip install -r requirements.txt
python app.py              # serves http://localhost:5050 (host 0.0.0.0, threaded, debug=False)
python create_guard.py     # interactive: create a login account (role guard | head_guard)
python test_cameras.py     # diagnose which webcam index/backend (DSHOW vs MSMF) works
```

No test suite, linter, or build step. Local Python is 3.14.

## Setup prerequisites

- `.env`: `SUPABASE_URL`, `SUPABASE_KEY`, `SUPABASE_SERVICE_KEY` (preferred; bypasses RLS), `FLASK_SECRET_KEY`, optional `TELEGRAM_BOT_TOKEN` (no token → bot disabled, app runs normally).
- The local machine used by Claude has no project dependencies installed; logic can be tested only with stubbed modules (`supabase`, `dotenv`) via `python -I -X utf8`.
- Supabase base tables (`plates`, `logs`, `guards`, `login_logs`) were created manually — no SQL for them in the repo. `migrations_new_features.sql` and `migrations_telegram.sql` (both idempotent) add the rest. Startup checks `check_alerts_table_exists()` / `check_guards_schema()` / `check_residents_schema()` warn if migrations are missing.

## Architecture

Four Python modules, no packages (`telegram_bot.py` is described in the Telegram section):

- **`app.py`** (~1670 lines) — everything Flask: config constants at the top, background workers, tracking/voting, gate integration, auth decorators, page routes, JSON API, CSV export/import, ReportLab PDF reports.
- **`detector.py`** — `load_models()` (EasyOCR tries GPU, falls back to CPU) and `detect_plates(frame)` → list of `{box, text, confidence, ocr_confidence, crop}`. If YOLO yields no plausible text, a throttled + cached full-frame EasyOCR fallback (`ENABLE_OCR_FALLBACK`) clusters text fragments into a plate (handles two-line plates). Low-confidence OCR (< `FUZZY_MATCH_CONF_THRESHOLD`) is snapped to a registered plate within 1 char.
- **`database.py`** — thin Supabase wrapper (module-level `supabase` client). Plate normalization (`normalize_plate`, `fix_ambiguous_chars`), a 20s cached registered-plate list, fuzzy matching, logs, alerts, guards, login sessions.

### Detection pipeline

1. `detection_worker` thread runs every `DETECTION_INTERVAL` when `SCAN_MODE == "auto"`: `read_frame()` → `process_and_log()` → stores result in `_latest_detections`.
2. `gen_video_stream()` (MJPEG `/video_feed`) only draws the latest stored detections — detection is deliberately decoupled from streaming so the feed never stalls.
3. `_process_one_detection()` matches boxes to tracks by IoU, accumulates readings, and once `VOTES_NEEDED` agree calls the authoritative `db.is_registered()`, writes a snapshot to `captures/logs/`, `db.add_log()`, `check_repeat_visit_alert()`, and if registered fires `send_to_raspberry()` in a daemon thread → `POST {RASPBERRY_API}/plate_detected {"plate", "status":"open"}`. Unregistered plates send nothing. `LOG_COOLDOWN` prevents repeat logs.
4. Box colour uses `_quick_is_registered()` (cached list, no network per frame); only the gate decision uses the DB. Every per-plate step is wrapped in try/except so Supabase failures never kill the live feed — preserve this.
5. Manual mode: `/api/scan/trigger` runs one pass; result held in `_manual_cache` for 5s.

`visitor_expiry_worker` deletes expired visitor plates every 60s (`is_registered()` also checks expiry inline).

Register page polls `/api/live_plate` to auto-capture; `/api/capture` saves the full frame as `captures/registered/temp_*.jpg`; `/api/register` inserts into `plates`. Manual override (`/api/gate/manual`) requires a reason code, logs `status=manual`, then POSTs to the Pi.

### Data model (Supabase)

- `plates`: plate_number (normalized, assumed unique), owner_name, photo_path, car_type, car_color, house_no, registered_by (guard **full_name**), registered_at, is_visitor, expires_at
- `logs`: plate_number, status (`registered`|`unregistered`|`manual`), snapshot_path, confidence, performed_by (guard **full_name**; NULL for auto-detections), timestamp, reason_code, note
- `guards`: username, password_hash, full_name, role, gender, phone, address, ic_front_path, ic_back_path, is_active
- `login_logs`: guard_id (FK → guards, blocks hard delete), guard_name, username, login_at, logout_at
- `alerts`: plate_number, alert_type, occurrence_count, window_minutes, created_at, acknowledged
- `residents` (Telegram bot users; several per house allowed; never hard-deleted): full_name, house_no, phone (normalized via `db.normalize_phone`, e.g. `60123456789`), telegram_user_id, telegram_chat_id, telegram_linked_at, is_active, created_by. `plates.resident_id` links a resident's own cars and bot-created visitor passes; `plates.created_via` is `dashboard`|`telegram`.
- `visitor_requests` (approve/reject at gate) and `resident_messages` (resident → guardhouse) exist in the migration for later Telegram phases.

Timestamps are stored UTC; "today" uses `MY_TZ` (UTC+8).

### Auth & roles

Session login against `guards` (werkzeug hashes); client-side idle logout after `IDLE_TIMEOUT_MINUTES`; sessions recorded in `login_logs`. Decorators `login_required_page/api` and `head_guard_required_page/api` (Team page, `/api/admin/*`, `/captures/guards/*`). Guards with login history are soft-deactivated (`is_active`) instead of deleted. CSV log import is intentionally open to all guards (user decision).

### Frontend

Jinja templates sharing `_sidebar.html`; vanilla JS polling the JSON API (alerts every 3s, sidebar status every 10s). Vendored Chart.js. `captures/` is served via `/captures/<path>`, not `static/`.

## Tuning knobs

Module-level constants: `app.py` — `CAMERA_INDEX`, `CAMERA_WIDTH/HEIGHT`, `GATE_INTEGRATION_ENABLED` (`True` — registered plates physically open the gate), `RASPBERRY_PI_IP`, `VOTES_NEEDED` (currently 1), `LOG_COOLDOWN`, `PLATE_PATTERN`, `MIN_BOX_WIDTH_FOR_OCR`, `REPEAT_VISIT_*`; `detector.py` — `CONF_THRESHOLD`, `DEBUG_YOLO`, `ENABLE_OCR_FALLBACK`, `FALLBACK_*`, `FUZZY_MATCH_CONF_THRESHOLD`.

## Known issues (identified, not yet fixed)

The user plans to fix security issues. Agreed priorities: tighten gate accuracy later, and the Telegram redesign.

- **Gate accuracy:** with `VOTES_NEEDED = 1`, a single low-confidence OCR read 1 char away from a registered plate is snapped to it by fuzzy match and opens the gate. The "distance" is positional (`zip`), not true Levenshtein. User wants to tighten this.
- **Stored XSS:** templates build HTML with `innerHTML` from unescaped DB fields (`note`, `owner_name`, `plate_number`, guard names); `onclick='openLogModal(${JSON.stringify(log)})'` breaks on `'`.
- No CSRF protection; `/logout` is GET; insecure default `FLASK_SECRET_KEY` fallback; deactivated guards keep their active session (`is_active` only checked at login); `/api/system/status` polling keeps the server session alive forever.
- Any guard can delete plates (`DELETE /api/plates/<id>`) - now audited in `plate_audit` (who/what/when, needs `migrations_plate_audit.sql`); image files are still not removed. `photo_path` from the client is trusted. Abandoned `temp_*.jpg` captures accumulate.
- Guards are referenced by full_name string in `logs`/`plates`, so renaming a guard breaks their history. CSV export fills empty `performed_by` with the exporter's name, so re-import attributes auto-detections to them. Leaderboard `detections_handled` only counts rows with `performed_by` (effectively only imported rows).
- **Timezone mismatch:** `/api/logs/dates` and all daily buckets (analytics, leaderboard, PDF) use `timestamp[:10]` (UTC date) while `get_logs_by_date` filters by MYT date.
- Sessions without logout leave `logout_at` NULL → hours on duty undercounted, and CSV export treats the shift as still open.
- Manual override is logged before the Pi request, so a failed request still logs "opened". The Pi endpoint has no auth.
- Expired visitor plates are hard-deleted (history lost); box-colour cache still includes them until the next sweep.
- `_fresh_detections(force_direct=True)` can run YOLO/EasyOCR concurrently with `detection_worker`; each `/video_feed` client reads the camera separately.
- `get_logs_since` caps at 3000 rows (analytics silently truncates); `last_logged` grows unbounded.
- Gallery "Scanning… Verified" modal is a cosmetic timer, not a real check.

## Telegram (current state → planned redesign)

`TELEGRAM/` contains only `.txt` notes for an older, **separate Pi-side system** (`/home/pi/gate_system`: Pi Flask `app.py` + `bot.py` long-polling + ngrok, started by `RUN.txt`). It is not connected to this app or Supabase. Old flow: `/link` → Pi `/generate_link` → one-time `/visit/<token>` page → `POST /api/open_gate/<token>` opens servo. Several divergent Pi versions exist (`APP.txt` in-memory tokens no expiry; `FLASK WEB SERVER.txt` SQLite + 1h expiry; `New` dual gate + Tesseract but visit routes removed). None contain `/plate_detected`. Known flaws: bot has no sender authorization, `/generate_link` and `/api/close_gate` unauthenticated (exposed publicly via ngrok), `FLASK_URL` breaks with an ngrok domain, no audit in Supabase `logs`. `TOKEN.txt`, `AUTHTOKEN.txt` (ngrok) and `TEST BOT.txt` contain secrets — never print them.

**New bot — agreed design** (replaces the visitor-link idea, which the user considers insecure):
- Runs inside `app.py` as a thread (planned `telegram_bot.py`, plain `requests` + `getUpdates` long polling, no ngrok, token from `TELEGRAM_BOT_TOKEN` in `.env`). Resident-only: `/start` → resident shares contact (must be their own: `contact.user_id == from.id`), matched against `residents.phone`. Ignore group chats and unknown/inactive users.
- **Flow A:** `/pelawat` → plate → fixed duration buttons (2 jam, Hari ni = until midnight MYT, 1/2/3/7 malam = until 12:00 noon N days later; same options for all residents incl. homestay units) → creates visitor pass in `plates` (`is_visitor`, `expires_at`, `resident_id`, `created_via='telegram'`). Camera detects it → gate opens automatically → resident notified with snapshot; dashboard tells guard to direct visitor to visitor parking. `/pas` lists and cancels own active passes.
- **Flow B:** unknown car → guard clicks "Contact resident" on an Unauthorized log and picks the house → bot sends snapshot + Approve/Reject buttons to that house's residents (2 min). Approve opens gate and logs `status=manual`, `reason_code='resident_approved'`. No response → dashboard shows "no response" and the guard decides via normal manual override.
- Also: entry notification when a resident's own linked plate is detected (sent to all residents of that house), `/status` (today's entries for their house), `/guard <msg>` → `resident_messages` → dashboard panel.
- Phases: 1) migration + `/residents` page — **done**; 2) bot verification + `/pelawat` + `/pas` + entry notifications — **done** (`telegram_bot.py`); 3) Flow B; 4) `/status`, messages to guard, dashboard panels ("expected visitors today", "resident messages", visitor-parking banner).
- `telegram_bot.py` internals: `start()` (called in `app.py` `__main__`) reads the token, `deleteWebhook`, `setMyCommands`, starts `_poll_loop` thread. Conversation state is in-memory `_state` (lost on restart). Max 5 active passes per house (house = residents whose `normalize_house_no` matches); `/pas` shows/cancels passes of the whole house. A plate with an active pass from another house, or a resident (non-visitor) plate, is rejected; an expired-but-unswept pass is deleted and recreated. `notify_entry(plate_row, plate, snapshot)` is called from `_process_one_detection` after logging when status is registered; it spawns a thread and sends to every linked resident of that house. All Telegram/Supabase errors are printed, never raised.
- Recommend revoking the old bot token via BotFather.

## Security rules (Nov 2026)
- Gate decision in `_process_one_detection` (app.py): blacklist `ban` -> hold; registered + anti-passback violation -> hold (mode `confirm`) or alert (`warn`);
  otherwise `_open_gate_for_entry` (Pi call + `gate_traffic` entry). Rule failures are caught - they must never stop normal gate operation.
- Exit = Pi ultrasonic sensor -> `POST /api/gate/exit` (X-Gate-Key / Pi IP). No plate, so presence is a count, not a per-plate list.
- Guard vs Head Guard scope for Security Intelligence is enforced by `role_gate()` in `intelligence.py`; add new intel endpoints through the `api(...)` helper with the right flags.
