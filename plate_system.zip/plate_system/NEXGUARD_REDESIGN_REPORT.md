# NEXGUARD redesign and Security Intelligence - implementation report

Branch: `ui-redesign` (baseline commit `f0ab6de`; untouched copy of the original zip kept as `proj_ORIGINAL_BACKUP`).
To revert the visual layer only: remove the `nexguard.css` `<link>` from the templates.
To revert everything: `git checkout f0ab6de -- .`

## 1. What was delivered

| Area | Result |
|---|---|
| Design system | `static/nexguard.css` token layer loaded after `style.css` (dark default, light kept for the existing toggle). Status colors have fixed meaning: green authorized, amber attention/manual, red not authorized, cyan AI only. |
| App shell | New `_sidebar.html`: NEXGUARD mark + wordmark, grouped nav, active indicator, live unreviewed-alert badge, user card, sign-out, theme toggle, MYT clock, responsive menu. System status is now honest (see 3). |
| Login | Redesigned, same `POST /login` contract (`username`, `password`, `error`). Shows no sample plate (would simulate recognition). |
| Dashboard | Same markup and logic; camera column widened to be the primary element; offline overlay driven by real camera status; calmer log rows; honest gate pill; detail modals now HTML-escape DB text. |
| Register / Gallery / Analytics ("My activity") / Team / Residents | Restyled through the design layer; logic untouched. Register's camera pill was hard-coded "READY" and now reflects the real camera. |
| **Security Intelligence Center** (`/intelligence`, Head Guard only) | 9 sections, global date filter (Today / 7d / 30d / custom, Malaysia time), 10 clickable KPI cards, drill-down drawer with search, filters, sorting, server-side pagination, row detail and CSV export. Chart bars/segments open the matching records. Plate investigation timeline. Registration audit, override audit, guard session analytics, visitor expiry, incident review. |
| Backend | `intelligence.py` (read-only, bounded queries, validated params, errors never leak internals); registered by 3 lines in `app.py`. |

## 2. Preserved
All 46 existing `@app.route` definitions are byte-identical to the original (`diff` clean). No framework change, no schema change applied, no existing API shape changed (`/api/system/status` only gained two fields). `.env` was never printed, committed or modified. Camera stream, YOLO/EasyOCR pipeline, Pi `POST /plate_detected` and gate-override flow were not edited.

## 3. Small changes to existing behavior (review these)
1. **`/api/system/status`** adds `gate_reachable` and `gate_checked_at`: a cached, background TCP connect to the Pi (never sends a gate command; disable with `GATE_PROBE_ENABLED = False`). The old sidebar "Gate Link: ACTIVE" only reflected a config flag. The UI now says "Reachable / No response / Disabled" and notes this is a network check, **not** physical gate position.
2. **`db.acknowledge_alert(id, by=None)`** records reviewer name/time *if* `migrations_audit_trail.sql` has been applied; otherwise behaves exactly as before.
3. **Team page "Performance Leaderboard"** ranked guards by activity counts with medals. The brief says activity counts must not be a performance score, and also says not to remove features. Compromise: kept the data/endpoint/PDF, renamed to "Guard activity summary", removed medals, added a disclaimer. **Your call**: restore the old wording by reverting the 5 lines in `team.html`.
4. Sidebar clock now always shows Malaysia time (was browser-local).
5. Dashboard's two detail modals escape DB text (stored-XSS fix from your known-issues list). **Other unescaped `innerHTML` sites remain** in index/gallery/team/residents JS; not changed in this pass.

## 4. Data reality: what is and is not shown (Phases 9-18)

| Requested | Status | Why / smallest fix |
|---|---|---|
| Entry vs exit, reconciliation | **Not built** | No direction field; one camera. Add `logs.direction` from a second camera/sensor first. Charts show *logged recognition events* and say so. |
| Override: command sent / ack / gate state | **Shown as "Not recorded"** | Override is logged before the Pi call and the response is discarded. Add `logs.gate_command_result` + update after POST. Pi-side sensor needed for physical state. |
| Override linked to vehicle/incident | Not recorded | Stored with `plate_number='MANUAL'`. Investigation shows nearby overrides only as *time proximity*, labelled as such. |
| Registration audit | Built | Creator = `plates.registered_by` (guard *name* string; renaming a guard breaks history). Visitor passes are hard-deleted at expiry and guards can delete plates, so removed records are unrecoverable; use soft delete / audit table. |
| Guard sessions | Built | Missing logout => "open" (<16 h) or "incomplete"; never counted as hours. Labelled "logged-in time, not duty time". Failed logins are not recorded. |
| AI performance | Partial | Only detector confidence (YOLO box score; OCR score on fallback). Histogram + low-confidence drill-down, labelled "not accuracy". **No accuracy %** (needs human-verified ground truth). Attempts, empty reads, latency, OCR confidence not recorded. |
| Reliability history / uptime % | **Not built** | Only live state exists. Add a `device_events` row on camera/Pi state change. |
| Uncertain / expired-pass categories | Shown as "Not recorded" | Not stored as separate outcomes. |
| Incident review | Built on `alerts` | Reviewer/time need the optional migration. No "suspicious" labels anywhere. |
| Export | CSV for every drill-down kind, respects filters, header has generation time + range, owner names excluded, formula-injection neutralised. |

## 5. Verification actually performed
- **Backend, 76 checks** (`tests/test_backend.py`) against the real `app.py` with a fake Supabase: role gating (401/403/redirect), counts equal ground truth, pagination/sort/filters, hour and day drill-down totals equal chart buckets, session state rules, CSV export, input validation, injection characters, meta honesty, alert acknowledge without migration.
- **UI, ~40 checks** (`jstest/ui_test.js`, jsdom): KPI -> drawer -> real rows, totals match, sort/pagination/row detail, Esc closes, chart click -> filtered drawer, all 9 tabs load, escaping of `<b>` in notes, investigation timeline + empty states, mark-reviewed, custom-range validation.
- **Visual review** in headless Chromium (login, dashboard, intelligence sections, drawer, register, team, mobile 390px); zero page/console errors on all pages. Several defects found this way were fixed (over-saturated log rows, hard-coded camera pill, clipped tabs, cramped header, UTC/MYT clock mismatch).
- `diff` of route decorators; all templates compile; role gating of nav and pages; no secret-looking strings in rendered HTML.

## 6. NOT verified (be aware)
- **Real Supabase**: all tests use an in-memory fake that mimics the query builder. Query method names were checked against the installed `supabase-py`/`postgrest` 2.33 API, but run `/intelligence` once against your live project. Column assumptions: `logs.reason_code/note/performed_by/confidence`, `plates.registered_by/registered_at/is_visitor/expires_at`, `login_logs.login_at/logout_at/guard_name`, `alerts.*` (all exist in your migrations).
- **Real camera, YOLO/EasyOCR, Raspberry Pi, Telegram**: not available here; stubbed. The gate probe was only exercised as "no response".
- Light theme, Residents and Gallery pages with real data/photos were not visually reviewed in detail; only checked for runtime errors.
- Performance with very large tables was reasoned (bounded scans: 20,000 rows per chart, flagged `truncated`), not load-tested. Apply the optional indexes in `migrations_audit_trail.sql` for large histories.
- Inter / JetBrains Mono load from Google Fonts as before; offline PCs fall back to system fonts.

## 7. Known limitations of the new analytics
- Hour-of-day drill-down scans up to 20,000 events in range then pages by id.
- Session "open vs incomplete" refinement is applied per page; the "No sign-out recorded" filter is exact.
- Charts for the "registered vs visitor traffic" view were **not** built: historical visitor plates are deleted, so classification would be wrong.

## 8. Optional migration
`migrations_audit_trail.sql` (additive, idempotent): `alerts.acknowledged_by/acknowledged_at` + 4 indexes. Undo line is in the file.

## 9. Running the tests
```
python -m venv venv && venv/bin/pip install flask supabase reportlab requests python-dotenv
venv/bin/python tests/test_backend.py      # 76 checks, no network/credentials needed
venv/bin/python tests/test_pages.py        # role/page smoke test
```
(The jsdom UI suite and screenshot scripts live outside the project in `jstest/` and are not part of the zip.)
