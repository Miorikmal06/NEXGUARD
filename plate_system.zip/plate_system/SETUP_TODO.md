# Apa yang dah settle vs apa yang kau KENA buat sendiri

## ✅ Dah settle dalam zip ni
- `models/license_plate_detector.pt` — model YOLO pretrained, dah letak sekali.
- `GATE_INTEGRATION_ENABLED = True` — dah aktifkan dalam `app.py`.

## ⚠️ Kau KENA buat sendiri (sebab melibatkan secret/password/hardware, tak boleh isi automatik)

1. **Confirm Pi IP betul.**
   `RASPBERRY_PI_IP` dalam `app.py` di-set `172.20.10.2` (default dari app.py asal kau).
   Tapi zip lama `barrier.zip` ada guna 2 IP berbeza (172.20.10.2 vs 172.20.10.3 dalam
   dashboard.py/laptop_api.py). Semak IP Pi kau **sekarang** (`hostname -I` kat Pi tu
   sendiri) dan tukar dalam `app.py` kalau berbeza.

2. **Supabase service key.**
   Dalam `.env`, `SUPABASE_SERVICE_KEY` masih placeholder
   (`PASTE_YOUR_service_role_KEY_HERE`). Kena ambil key sebenar dari Supabase
   dashboard → Project Settings → API → `service_role` key, then paste dalam `.env`.
   (Ni secret — sengaja tak boleh isi automatik untuk aku.)

3. **Buat table `plates` dan `logs` kat Supabase** (kalau belum ada), then run
   `migrations_new_features.sql` dalam SQL Editor untuk feature tambahan
   (reason code, visitor pass, guard IC fields).

4. **Buat akaun guard untuk login.**
   Run `python create_guard.py` dalam terminal, ikut prompt (perlukan password
   interaktif — tak boleh dibuat automatik).

5. **Kod penerima kat Raspberry Pi (GPIO/servo control) tak ada dalam mana-mana
   zip.** `app.py` cuma hantar `POST http://<PI_IP>:5000/plate_detected` dengan
   `{"plate": ..., "status": "open"}`. Pastikan program yang jalan **kat Pi
   sendiri** (yang dengar request ni dan betul-betul gerakkan barrier) masih
   wujud dan running. Kalau kau dah hilang fail tu, bagitahu — boleh cipta
   semula berdasarkan format request di atas.

6. **Register plate.** Lepas login, pergi `/register` dalam dashboard untuk
   daftar plate (capture → OCR cadang teks → confirm/edit → save). Gate cuma
   buka untuk plate yang status "registered" dalam Supabase — bukan baca txt
   file macam barrier.zip.
