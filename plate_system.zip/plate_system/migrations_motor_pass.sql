-- Run this in Supabase SQL Editor BEFORE using the "Motor QR Pass" page.
-- Safe to run multiple times (IF NOT EXISTS guards).
--
-- Motorcycle QR passes: the system generates a QR per motorcycle, it is stuck on the bike,
-- and the guard scans it with a phone at the gate. The QR only carries a random token -
-- the plate / owner / status are looked up here, so a fake QR is simply "not found".

create table if not exists motor_passes (
    id bigint generated always as identity primary key,
    token text not null unique,              -- random, unguessable (12 chars, no ambiguous letters)
    plate_number text not null,              -- normalized (uppercase, no spaces)
    owner_name text,
    house_no text,
    is_active boolean not null default true, -- false = revoked (lost sticker, bike sold, ...)
    expires_at timestamptz,                  -- null = no expiry
    created_by text,                         -- guard full_name
    created_at timestamptz not null default now(),
    deactivated_by text,
    deactivated_at timestamptz,
    token_rotated_at timestamptz             -- set when a replacement QR was issued
);
create index if not exists idx_motor_passes_plate on motor_passes (plate_number);
create index if not exists idx_motor_passes_active on motor_passes (is_active);

-- Audit trail of every scan and every gate-open triggered from a scan.
-- event: scan_valid | scan_expired | scan_inactive | scan_unknown | opened
create table if not exists motor_pass_events (
    id bigint generated always as identity primary key,
    pass_id bigint references motor_passes(id) on delete set null,
    event text not null,
    plate_number text,
    guard_name text,
    note text,
    created_at timestamptz not null default now()
);
create index if not exists idx_motor_pass_events_pass on motor_pass_events (pass_id, created_at desc);
create index if not exists idx_motor_pass_events_created on motor_pass_events (created_at desc);
