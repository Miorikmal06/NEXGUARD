# Exit sensor -> laptop (entry/exit tracking)

The exit gate has only an ultrasonic sensor (no camera), so the Pi can only tell the laptop
**"a vehicle just left"** - not which plate. The laptop uses that to keep the "Inside now"
estimate and for anti-passback.

## 1. Laptop `.env`
```
GATE_API_KEY=pick-a-long-random-string      # shared secret, must match the Pi
ANTI_PASSBACK_MODE=confirm                  # off | warn | confirm  (default confirm)
PUBLIC_BASE_URL=http://<fixed-laptop-ip>:5050   # so printed Motor QR codes keep working
```
Without `GATE_API_KEY` the laptop only accepts exit signals from `RASPBERRY_PI_IP` (app.py).

## 2. Pi script (`FULL IN OUT`) - add near the top
```python
import requests

LAPTOP_URL = "http://<laptop-ip>:5050"          # same address you open the dashboard on
GATE_API_KEY = "pick-a-long-random-string"      # same as the laptop .env

def report_exit():
    """Tell the laptop one vehicle left. Fire-and-forget: never delays the gate."""
    def _send():
        try:
            requests.post(f"{LAPTOP_URL}/api/gate/exit",
                          headers={"X-Gate-Key": GATE_API_KEY}, timeout=2)
        except Exception as e:
            print(f"Could not report exit to laptop: {e}")
    threading.Thread(target=_send, daemon=True).start()
```

## 3. In `monitor_keluar()` - report once the vehicle has cleared the sensor
```python
                while running:
                    dist = get_distance(TRIG_KELUAR, ECHO_KELUAR)
                    if dist > THRESHOLD or dist < 0:
                        break
                    time.sleep(0.2)

                report_exit()          # <-- add this line (one call per vehicle)
                gate_keluar_tutup()
```
Run `pip install requests` on the Pi if it is not installed. The laptop ignores a second signal
within 3 seconds, so a flickering sensor will not double-count.

## 4. If the sensor misses a car / counts wrongly
* Any guard: dashboard -> **Inside now** -> *Record a missed exit*.
* Head Guard: same dialog -> *Reset counter to 0* (starts a new baseline).
