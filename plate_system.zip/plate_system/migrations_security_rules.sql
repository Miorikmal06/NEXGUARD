-- Entry/exit tracking, anti-passback, blacklist/watchlist, guard lookup audit.
-- Run once in the Supabase SQL Editor. Safe to run multiple times (IF NOT EXISTS guards).

-- ---------------------------------------------------------------- gate traffic (in / out)
-- direction: in    = a registered plate was let in (auto, guard-verified, or motorcycle QR)
--            out   = a vehicle left (Pi ultrasonic exit sensor, or a guard recorded it by hand).
--                    The exit sensor cannot read plates, so plate_number is NULL for exits.
--            reset = Head Guard zeroed the "inside now" counter (start of a new baseline).
create table if not exists gate_traffic (
    id bigint generated always as identity primary key,
    direction text not null check (direction in ('in', 'out', 'reset')),
    plate_number text,
    source text,                       -- auto | motor_qr | guard_verified | sensor | manual
    performed_by text,                 -- guard full_name, or 'exit sensor'
    note text,
    created_at timestamptz not null default now()
);
create index if not exists idx_gate_traffic_created on gate_traffic (created_at desc);
create index if not exists idx_gate_traffic_plate on gate_traffic (plate_number, created_at desc);

-- ---------------------------------------------------------------- blacklist / watchlist
-- severity: ban   = gate is NEVER opened automatically + alarm on the dashboard
--           watch = gate behaves normally, but the guards get an alarm so they keep an eye on it
-- Rows are never hard-deleted: removing = is_active false + who/when (audit).
create table if not exists blacklist (
    id bigint generated always as identity primary key,
    plate_number text not null,
    severity text not null default 'ban' check (severity in ('ban', 'watch')),
    reason text not null,
    added_by text not null,
    added_at timestamptz not null default now(),
    expires_at timestamptz,            -- null = until removed
    is_active boolean not null default true,
    removed_by text,
    removed_at timestamptz
);
create index if not exists idx_blacklist_plate on blacklist (plate_number);
create index if not exists idx_blacklist_active on blacklist (is_active);

-- ---------------------------------------------------------------- alerts: new types + detail
-- alert_type now also: blacklist | watchlist | passback  (existing: frequent_visit)
alter table alerts add column if not exists detail text;

-- ---------------------------------------------------------------- guard plate-history lookups
-- Guards may look up one plate's recent history (last 3 days). Each lookup is recorded.
create table if not exists lookup_audit (
    id bigint generated always as identity primary key,
    guard_name text not null,
    query text not null,
    created_at timestamptz not null default now()
);
create index if not exists idx_lookup_audit_created on lookup_audit (created_at desc);
