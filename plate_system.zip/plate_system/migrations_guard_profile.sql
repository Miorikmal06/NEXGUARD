-- Guard profile / hanging ID card: IC number + profile photo.
-- Run once in the Supabase SQL editor. Safe to run multiple times.
alter table guards add column if not exists ic_number text;
alter table guards add column if not exists photo_path text;
