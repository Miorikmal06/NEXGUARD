"""
create_guard.py
CLI script untuk tambah akaun guard baharu (login credentials).

Run: python create_guard.py
"""

import os
import getpass
from dotenv import load_dotenv
from supabase import create_client
from werkzeug.security import generate_password_hash

load_dotenv()

SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_KEY") or os.environ.get("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    print("SUPABASE_URL / SUPABASE_SERVICE_KEY not found in .env")
    raise SystemExit(1)

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

print("=== Create Guard Account ===\n")

username = input("Username (for login, e.g. guard2): ").strip().lower()
full_name = input("Full name (shown in reports, e.g. Guard 2 - Ahmad): ").strip()
password = getpass.getpass("Password: ")
password_confirm = getpass.getpass("Confirm password: ")

if not username or not full_name or not password:
    print("\nAll fields are required.")
    raise SystemExit(1)

if password != password_confirm:
    print("\nPasswords don't match.")
    raise SystemExit(1)

role = input("Role - 'guard' or 'head_guard' [guard]: ").strip().lower() or "guard"
if role not in ("guard", "head_guard"):
    print("\nRole must be 'guard' or 'head_guard'.")
    raise SystemExit(1)

password_hash = generate_password_hash(password)

try:
    supabase.table("guards").insert({
        "username": username,
        "password_hash": password_hash,
        "full_name": full_name,
        "role": role,
    }).execute()
    print(f"\nGuard account created: {full_name} ({username}, {role})")
except Exception as e:
    print(f"\nFailed to create account (username may already exist): {e}")
