# Perubahan yang ditambah

## 1. Multi-frame tracking + voting (app.py)
Plat yang sama kini dijejak merentasi frame (padan ikut overlap box / IoU),
bukan diproses secara berasingan setiap frame. Gate + log kini hanya dicetuskan
selepas VOTES_NEEDED (default 4) bacaan berturut-turut bersetuju pada teks yang
sama - satu frame OCR yang silap tidak lagi boleh buka gate.

Tetapan boleh tuning di bahagian atas app.py:
- VOTES_NEEDED = 4          (naikkan = lebih tepat tapi lebih lambat)
- TRACKER_TIMEOUT = 3.0     (saat sebelum track dianggap "dah keluar frame")
- IOU_MATCH_THRESHOLD = 0.3
- MIN_BOX_WIDTH_FOR_OCR = 60  (skip OCR untuk plat terlalu kecil/jauh)

## 2. Semakan format plat (app.py)
PLATE_PATTERN menapis bacaan OCR yang tak berbentuk plat Malaysia sebelum ia
dibenarkan "mengundi" - kurangkan bacaan mengarut daripada mencemari voting.
Ini anggaran kasar sahaja - test dan sesuaikan regex ikut plat sebenar kau.

## 3. Alert lawatan berulang (app.py, database.py, migrations_new_features.sql)
- **KENA jalankan migrations_new_features.sql dalam Supabase SQL Editor dulu**
  untuk buat jadual `alerts` yang baru.
- check_repeat_visit_alert() dipanggil lepas setiap log disahkan (bukan setiap
  frame). Kalau plat sama muncul >= REPEAT_VISIT_THRESHOLD (default 3) kali
  dalam REPEAT_VISIT_WINDOW_MIN (default 60) minit, satu alert dicipta dalam
  jadual `alerts`.
- Cooldown REPEAT_ALERT_COOLDOWN_MIN (default 60 min) elak alert berulang
  untuk plat yang sama dalam tempoh singkat.
- Endpoint baru:
  - GET  /api/alerts                       - senarai alert terkini
  - GET  /api/alerts?acknowledged=false    - alert yang belum di-ack
  - POST /api/alerts/<id>/acknowledge      - tandakan alert sebagai dilihat
- **Belum ada UI** untuk papar alert ni di dashboard - endpoint API sahaja buat
  masa ini. Boleh tambah card/badge di templates/index.html bila nak.
- **Tiada notifikasi WhatsApp/Telegram** - alert cuma disimpan dalam DB dan
  boleh di-query. Sambung ke saluran notifikasi ialah langkah berasingan.

## 4. Bug delete guard (app.py, database.py)
db.delete_guard() sekarang check bilangan baris yang benar-benar dipadam.
Kalau 0 baris terpadam (contohnya disekat oleh foreign key constraint dari
jadual logs, atau RLS), API kini pulangkan mesej error yang jelas dan status
409, bukan "berjaya" senyap-senyap. **Punca sebenar masih perlu disahkan** -
cuba delete semula dan tengok mesej error yang keluar / terminal Flask.

## Apa yang TAK diubah / masih perlu buat
- Detection motor belum disokong - model sedia ada terlatih untuk plat kereta.
- SUPABASE_SERVICE_KEY dalam .env kau nampak macam placeholder ("PAST...") -
  sahkan key sebenar dah diisi, atau delete_guard (dan lain-lain admin action)
  mungkin masih gagal disebabkan RLS.

## Kemaskini 3: soft-delete guard (punca sebenar bug delete guard, disahkan)
Punca sebenar dah disahkan lewat mesej error Supabase: SOL (dan guard lain
yang pernah login) tak boleh di-hard-delete sebab foreign key
`login_logs_guard_id_fkey` - Supabase sengaja tolak delete supaya rekod
`login_logs` tak jadi rujuk kepada guard yang dah tak wujud. **Ini bukan bug,
tapi tingkah laku FK yang betul.**

Fix: guard kini **soft-delete** (deactivate) bila mereka ada history login,
bukan hard-delete:
- **KENA run `migrations_new_features.sql` semula** (tambah column
  `guards.is_active`, default true).
- Butang "Remove" cuba hard-delete dulu (masih berjaya untuk guard yang tak
  pernah login/tiada history). Kalau disekat FK, automatik fallback ke
  deactivate - guard hilang dari senarai aktif, tak boleh login lagi, tapi
  login_logs/leaderboard/analytics history mereka kekal utuh.
- Guard yang dinyahaktifkan papar pudar + label "Deactivated" dalam Team
  Management, dengan butang "Reactivate" untuk pulihkan balik.
- Login (`app.py` /login) kini semak `is_active` - guard dinyahaktifkan tak
  boleh login walaupun password betul.

- get_camera() (app.py) kini paksa CAMERA_WIDTH/CAMERA_HEIGHT (default
  1920x1080) dan buffer size 1 supaya stream tak lag di belakang. Startup
  print `[camera] requested 1920x1080, got WxH` - kalau "got" tak sama dengan
  "requested", webcam kau tak support 1080p pada driver semasa dan cv2 dah
  fallback ke resolusi terdekat yang disokong.
- detector.py load_models() try gpu=True dulu untuk EasyOCR, automatik
  fallback ke CPU (dengan mesej) kalau CUDA tak available - selamat run di
  mesin tanpa GPU NVIDIA.
- Dashboard (templates/index.html) kini ada panel "Repeat Visit Alerts" di
  atas Detection Log - papar automatik bila ada alert belum di-ack, dengan
  butang Dismiss yang panggil /api/alerts/<id>/acknowledge. Panel auto-hide
  bila tiada alert aktif, refresh setiap 15 saat.


## 9. Fix repeat-visit alert (patch)
- Kiraan lawatan berulang kini fuzzy: plat yang beza 1 aksara (OCR typo) dikira plat sama (database.py `_plates_similar`).
- Cooldown alert kini hanya block kalau alert lama plat tu BELUM di-dismiss. Dulu alert yang dah di-dismiss pun
  block alert baru sampai 60 minit (punca test kedua nampak tak trigger).
- Log `[repeat-check] PLAT: x/3` di console setiap kali plat dilog, senang debug.
- Dashboard: banner merah berkelip di atas skrin + bunyi beep bila alert baru keluar; polling 3 saat (dulu 15).
  Browser perlu 1 klik di page sekali supaya bunyi dibenarkan.


## 4. Detect plat kosong + semua jenis plat (detector.py, app.py, database.py)
- detector.py: CONF_THRESHOLD diturunkan 0.5 -> 0.25 (plat yang tak lekat kat kereta
  confidence YOLO lebih rendah). Set DEBUG_YOLO = True untuk tengok confidence sebenar.
- detector.py: fallback EasyOCR seluruh frame bila YOLO tak jumpa apa-apa
  (ENABLE_OCR_FALLBACK). Tapis: 4-10 aksara, ada huruf + nombor, OCR conf >= 0.4.
  Set ENABLE_OCR_FALLBACK = False kalau terlalu perlahan / banyak bacaan mengarut.
- app.py: PLATE_PATTERN dilonggarkan kepada ^[A-Z0-9]{2,10}$ supaya plat khas /
  diplomatik / bermula nombor tak ditolak. Voting 4x masih melindungi daripada bacaan silap.
- database.py: fix_ambiguous_chars() tak ubah plat yang bermula dengan nombor
  (elak '0' di depan tersalah jadi 'O').

## 5. Live feed laju + kotak lebih besar (app.py, detector.py)
- VOTES_NEEDED = 1: plat terus di-detect + di-log pada bacaan pertama (tiada "reading..." lama).
  Naikkan ke 2-4 kalau nak tapis bacaan OCR silap (ikut trade-off ketepatan vs kelajuan).
- ENABLE_OCR_FALLBACK dimatikan by default (scan OCR seluruh frame memperlahankan worker
  dan kotak yang dihasilkan kecil). Bila dihidupkan, ia throttle 1.5s dan kotak dibesarkan.
- draw_detections(): tebal garisan + saiz tulisan ikut resolusi frame (lebih jelas pada 1080p).
- PLATE_PATTERN: mesti ada huruf + nombor, 3-10 aksara (elak bacaan mengarut bila 1 undi cukup).
- CONF_THRESHOLD 0.3 (tengah-tengah antara 0.5 asal dan 0.25).

## 6. Fix live feed tak baca / tak warna (app.py, detector.py)
- Punca utama: bila panggilan Supabase (db.is_registered / add_log) gagal atau lambat,
  seluruh pass detection terhenti dan live feed tak dikemas kini -> nampak macam "tak baca apa-apa".
  Kini setiap plat diproses berasingan dengan try/except; ralat DB tak boleh matikan paparan.
- Live feed SENTIASA tunjuk teks yang dibaca + warna: HIJAU = registered, MERAH = tidak registered.
  Teks dipaparkan walaupun tak menepati format plat. Tiada lagi status "reading..." / "too_far".
- Warna guna cache senarai plat (tiada network call setiap frame). Gate tetap guna db.is_registered() yang sahih.
- Plat kecil/jauh (< MIN_BOX_WIDTH_FOR_OCR) masih dipaparkan, cuma tak dilog.
- Bila plat lain muncul di kedudukan yang sama, track di-reset (tak tunjuk teks kereta lama).
- PLATE_PATTERN kini ^[A-Z0-9]{2,12}$ dan hanya untuk log/gate.
- OCR: border 10px pada crop + 3 cubaan preprocessing (CLAHE, greyscale biasa, terbalik) sebelum menyerah.

## 7. Register plate auto-detect (app.py, templates/register.html)
- Halaman Register kini AUTO-DETECT: poll /api/live_plate setiap 0.6s; sebaik sahaja ada plat dengan teks
  di depan kamera, terus capture + isi borang (tak perlu tekan butang). Butang "Capture & Detect Plate"
  masih ada untuk scan semula secara manual.
- /api/capture kini pantas: guna terus hasil background worker (kalau masih segar < 3s) - tiada YOLO+OCR
  kali kedua. Kalau worker tiada hasil / mode manual, baru detect terus pada frame semasa.
- Endpoint baru: GET /api/live_plate -> {found, text, confidence, ocr_confidence}.

## 8. Baca plat SAHAJA - tak bergantung pada YOLO / kereta (detector.py, app.py, register.html)
- Punca screenshot: plat "AMM 1075" close-up (font timbul, plat hitam) tak dikesan YOLO -> tiada kotak, tiada teks.
  Auto-capture pula ambil frame kabur dan bacaan sampah "0161".
- detector.py: kalau YOLO tak beri plat yang teksnya munasabah (3-10 aksara, ada huruf + nombor),
  EasyOCR scan seluruh frame (ENABLE_OCR_FALLBACK = True sekarang). Serpihan teks digabung menjadi satu plat
  ("AMM" + "1075" -> AMM1075, plat 2 baris juga), calon dipilih ikut bentuk plat + saiz + confidence.
  Hasil scan di-cache sekejap (FALLBACK_CACHE_TTL) supaya live feed tak berkelip-kelip bila scan di-throttle.
  Kalau YOLO beri bacaan yang bagus, fallback TIDAK jalan (tiada kos tambahan).
- app.py: /api/live_plate hanya kira bacaan yang munasabah sebagai "found" (elak auto-capture sampah).
  Capture manual memaksa scan penuh (tak di-throttle).
- register.html: bacaan lemah perlu 2 kali sama berturut-turut, bacaan kuat (OCR >= 70%) terus capture.
  Selepas capture, auto-detect terus pantau dan ganti kalau bacaan LEBIH YAKIN muncul (selagi borang belum diedit).
- Tuning di atas detector.py: FALLBACK_MAX_SIDE (kecil = laju), FALLBACK_MIN_INTERVAL, FALLBACK_MIN_OCR_CONF.

## Motor QR pass (Oct 2026)
- Baru: `migrations_motor_pass.sql` (`motor_passes`, `motor_pass_events`), halaman `/motor-passes`, skrin scan `/scan/<token>`,
  kad cetak, reason code override `motor_qr`. Lihat `MOTOR_QR.md`.
- `app.py`: route motor pass + login pulang ke `/scan/...` selepas login. `database.py`: fungsi motor pass di hujung fail.
- `requirements.txt`: tambah `qrcode`. Tiada perubahan pada `detector.py` / aliran auto-detect kereta.

## Login scroller, guard ID card, permanent remove (Oct 2026)
- `/login`: "Login as" + satu baris setiap guard (tak repeat; 3 guard = 3 baris), font Outfit + Instrument Serif dibundle
  dalam `static/fonts/` (jalan offline). Bunyi detent setiap kali nama lalu garisan tengah + chime bila pilih; butang Sound on/off
  di footer (bunyi dijana Web Audio, tiada fail audio; browser aktifkan selepas klik/tekan kekunci pertama).
- `/profile`, `/profile/<id>`: kad ID tergantung (gambar, nama, no IC). `migrations_guard_profile.sql` (`ic_number`, `photo_path`).
- Guard team: **Remove** kini buang betul-betul selepas satu pengesahan - akaun, log login, gambar & salinan IC dipadam;
  sesi guard itu terus ditamatkan. (`database.purge_guard`, `app.api_admin_delete_guard`.) Guard lama yang sekadar "Deactivated"
  kini ada butang Remove juga.

## Audit pembuangan plat (Nov 2026)
- **KENA run `migrations_plate_audit.sql`** dalam Supabase SQL Editor (jadual `plate_audit`).
- Setiap plat yang dibuang dari whitelist kini direkod: nombor plat, owner, rumah, **siapa buang**, bila.
  Audit ditulis DULU, baru plat dipadam - kalau audit gagal, plat TIDAK dipadam (guard dapat mesej jelas).
- `database.delete_plate(plate_id, performed_by, performed_by_id, action, strict)`. Sweep luput visitor = `system`/`expired`,
  batal pas Telegram = `resident: <nama>`/`cancelled` (dua-dua `strict=False` supaya pembersihan tak tersekat).
- Head Guard: panel **Plate removal audit** di halaman Team, API `GET /api/admin/plate-audit`.
- Test: `cd tests && python test_plate_audit.py`.

## Entry/exit, anti-passback, blacklist, guard Intelligence, all-device (Nov 2026)
- **KENA run `migrations_security_rules.sql`** (tables `gate_traffic`, `blacklist`, `lookup_audit`, column `alerts.detail`).
  Without it the gate still works - the new rules are skipped and a startup warning is printed.
- **Entry/exit:** every auto/QR/guard-verified entry is recorded; the Pi exit sensor calls `POST /api/gate/exit`
  (see `PI_EXIT_SENSOR.md`). Because the sensor cannot read plates, "Inside now" is an ESTIMATE (in - out since last reset);
  the dialog also lists plates that entered with no exit recorded since (certainly inside).
- **Anti-passback** (`ANTI_PASSBACK_MODE`, default `confirm`): a registered plate that entered, with NO exit recorded since,
  and tries to enter again is held: gate is not opened, a passback alert appears, a guard presses *Verified - open gate*
  (logged as manual override, reason `anti_passback`). Grace 2 min (same car still at the gate); entries older than 24 h are stale.
- **Blacklist/watchlist** (`/blacklist`, Head Guard edits, guards read): `ban` = never auto-open + alarm (also blocks registering the plate
  or giving it a QR pass); `watch` = enters normally + alarm. A 1-character OCR near-match only warns, it never blocks.
  Removal is a soft delete (who/when kept).
- **Security Intelligence for guards:** guards get a read-only, today-only view (Overview, Traffic, Investigation, Visitors, Incidents).
  Plate look-ups are limited to the last 3 days and recorded (`lookup_audit`, shown to the Head Guard on the Team page).
  Guards/AI recognition/Reliability/Access/exports/staff KPIs remain Head Guard only. Enforced in `intelligence.py` (server side).
- **All devices:** new `static/responsive.css` (5-card KPI strip, 44px touch targets, no iOS zoom, scrollable tabs, modal fit, wide-screen cap).
  Checked with headless Chromium at 390 / 820 / 1440 px.
- Tests: `cd tests && python test_security_rules.py` (plus the existing suites).
