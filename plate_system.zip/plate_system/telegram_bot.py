"""
telegram_bot.py
Bot Telegram untuk PENDUDUK sahaja - jalan sebagai thread dalam app.py.

- Guna long polling (getUpdates): bot yang tarik mesej dari Telegram, jadi tak
  perlu ngrok / URL awam, dan tiada endpoint baru yang terdedah ke internet.
- Hanya penduduk aktif dalam table `residents` boleh guna. Pengesahan: penduduk
  kongsi contact SENDIRI (contact.user_id == from.id), nombor dipadankan dengan
  residents.phone.
- /pelawat cipta pas pelawat terus dalam table `plates` (is_visitor + expires_at),
  jadi bila kamera kesan plat tu, gate buka secara automatik.
- notify_entry() dipanggil oleh app.py bila plat yang terpaut pada penduduk
  (kereta sendiri / pas pelawat) dikesan dan gate dibuka.

Aktif hanya bila TELEGRAM_BOT_TOKEN ada dalam .env.
"""

import os
import re
import time
import html
import threading
from datetime import datetime, timezone, timedelta

import requests

import database as db

MY_TZ = timezone(timedelta(hours=8))

POLL_TIMEOUT = 25            # saat - long polling getUpdates
MAX_ACTIVE_PASSES_PER_HOUSE = 5

# Pilihan tempoh tetap (sama untuk semua penduduk, termasuk unit homestay)
DURATIONS = [
    ("2h", "2 jam"),
    ("today", "Hari ni"),
    ("1n", "1 malam"),
    ("2n", "2 malam"),
    ("3n", "3 malam"),
    ("7n", "7 malam"),
]
DURATION_LABELS = dict(DURATIONS)
CHECKOUT_HOUR = 12  # "N malam" luput 12:00 tengah hari, N hari kemudian

_PLATE_RE = re.compile(r"^[A-Z0-9]{3,10}$")
_HARI = ["Isnin", "Selasa", "Rabu", "Khamis", "Jumaat", "Sabtu", "Ahad"]
_BULAN = ["Jan", "Feb", "Mac", "Apr", "Mei", "Jun", "Jul", "Ogo", "Sep", "Okt", "Nov", "Dis"]

HELP_TEXT = (
    "<b>Senarai command:</b>\n"
    "/pelawat - daftar pas untuk pelawat (gate buka automatik bila plat dikesan)\n"
    "/pas - senarai &amp; batal pas pelawat rumah anda\n"
    "/batal - batalkan langkah yang sedang berjalan\n"
    "/help - papar mesej ini"
)

_token = None
_state = {}  # {telegram_user_id: {"step": "plate"|"duration", "plate": str}} - hilang bila app restart


# ============ TELEGRAM API ============

def _api(method, files=None, timeout=15, **params):
    """Panggil Telegram Bot API. Return 'result' atau None - ralat cuma di-print,
    tak pernah dibaling, supaya bot/detection tak mati sebab Telegram."""
    url = f"https://api.telegram.org/bot{_token}/{method}"
    try:
        if files:
            resp = requests.post(url, data=params, files=files, timeout=timeout)
        else:
            resp = requests.post(url, json=params, timeout=timeout)
        data = resp.json()
    except Exception as e:
        print(f"[telegram] {method} failed: {e}")
        return None
    if not data.get("ok"):
        print(f"[telegram] {method} error {data.get('error_code')}: {data.get('description')}")
        return None
    return data.get("result")


def _send(chat_id, text, reply_markup=None):
    params = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if reply_markup is not None:
        params["reply_markup"] = reply_markup
    return _api("sendMessage", **params)


def _edit(chat_id, message_id, text):
    """Ganti teks mesej (dan buang butang inline) selepas butang ditekan."""
    return _api("editMessageText", chat_id=chat_id, message_id=message_id, text=text, parse_mode="HTML")


def _send_photo(chat_id, photo_path, caption):
    try:
        with open(photo_path, "rb") as f:
            return _api("sendPhoto", files={"photo": f}, timeout=30,
                        chat_id=chat_id, caption=caption, parse_mode="HTML")
    except OSError:
        return _send(chat_id, caption)


# ============ HELPERS ============

def _fmt_time(iso_or_dt):
    """'Sabtu 25 Okt, 12:00' dalam waktu Malaysia."""
    if isinstance(iso_or_dt, str):
        dt = datetime.fromisoformat(iso_or_dt.replace("Z", "+00:00"))
    else:
        dt = iso_or_dt
    dt = dt.astimezone(MY_TZ)
    return f"{_HARI[dt.weekday()]} {dt.day} {_BULAN[dt.month - 1]}, {dt:%H:%M}"


def _compute_expiry(key):
    """Return datetime (UTC) bila pas luput, ikut pilihan tempoh."""
    now = datetime.now(MY_TZ)
    if key == "2h":
        expires = now + timedelta(hours=2)
    elif key == "today":
        expires = now.replace(hour=23, minute=59, second=59, microsecond=0)
    else:
        nights = int(key.rstrip("n"))
        day = now.date() + timedelta(days=nights)
        expires = datetime(day.year, day.month, day.day, CHECKOUT_HOUR, 0, tzinfo=MY_TZ)
    return expires.astimezone(timezone.utc)


def _is_expired(plate_row):
    exp = plate_row.get("expires_at")
    if not exp:
        return False
    try:
        return datetime.fromisoformat(exp.replace("Z", "+00:00")) <= datetime.now(timezone.utc)
    except Exception:
        return False


def _valid_plate(plate):
    return bool(_PLATE_RE.match(plate)) and any(c.isalpha() for c in plate) and any(c.isdigit() for c in plate)


def _house_resident_ids(resident):
    ids = {r["id"] for r in db.get_house_residents(resident["house_no"])}
    ids.add(resident["id"])
    return ids


def _contact_keyboard():
    return {
        "keyboard": [[{"text": "📱 Kongsi Nombor Telefon", "request_contact": True}]],
        "resize_keyboard": True,
        "one_time_keyboard": True,
    }


def _duration_keyboard():
    buttons = [{"text": label, "callback_data": f"dur:{key}"} for key, label in DURATIONS]
    return {"inline_keyboard": [buttons[:3], buttons[3:]]}


# ============ HANDLERS ============

def _ask_contact(chat_id):
    _send(chat_id,
          "Selamat datang ke bot guardhouse.\n\n"
          "Bot ini untuk <b>penduduk berdaftar</b> sahaja. Tekan butang di bawah untuk "
          "kongsi nombor telefon anda supaya kami boleh sahkan akaun anda.",
          reply_markup=_contact_keyboard())


def _handle_contact(msg):
    chat_id = msg["chat"]["id"]
    user_id = msg["from"]["id"]
    contact = msg["contact"]

    # Hanya terima contact milik pengirim sendiri - elak orang kongsi contact penduduk lain
    if contact.get("user_id") != user_id:
        _send(chat_id, "Sila kongsi nombor telefon <b>anda sendiri</b> guna butang di bawah.",
              reply_markup=_contact_keyboard())
        return

    resident = db.get_resident_by_phone(contact.get("phone_number"))
    if not resident:
        _send(chat_id, "❌ Nombor ini tidak berdaftar sebagai penduduk.\n"
                       "Sila hubungi pihak pengurusan / guardhouse untuk didaftarkan.",
              reply_markup={"remove_keyboard": True})
        return
    if not resident.get("is_active"):
        _send(chat_id, "❌ Akaun penduduk anda telah dinyahaktifkan. Sila hubungi pihak pengurusan.",
              reply_markup={"remove_keyboard": True})
        return

    db.link_resident_telegram(resident["id"], user_id, chat_id)
    print(f"[telegram] linked resident {resident['full_name']} ({resident['house_no']}) -> user {user_id}")
    _send(chat_id,
          f"✅ Akaun disahkan. Selamat datang <b>{html.escape(resident['full_name'])}</b> "
          f"({html.escape(resident['house_no'])}).\n\n" + HELP_TEXT,
          reply_markup={"remove_keyboard": True})


def _handle_message(msg):
    chat = msg.get("chat") or {}
    if chat.get("type") != "private":
        return  # abaikan group / channel
    if "from" not in msg:
        return
    chat_id = chat["id"]
    user_id = msg["from"]["id"]

    if "contact" in msg:
        _handle_contact(msg)
        return

    resident = db.get_resident_by_telegram_user(user_id)
    if not resident:
        _ask_contact(chat_id)
        return
    if not resident.get("is_active"):
        _send(chat_id, "❌ Akaun penduduk anda telah dinyahaktifkan. Sila hubungi pihak pengurusan.")
        return

    text = (msg.get("text") or "").strip()
    command = text.split()[0].split("@")[0].lower() if text.startswith("/") else None

    if command in ("/start", "/help", "/menu"):
        _state.pop(user_id, None)
        _send(chat_id, f"Hai <b>{html.escape(resident['full_name'])}</b> "
                       f"({html.escape(resident['house_no'])}).\n\n" + HELP_TEXT)
    elif command == "/batal":
        _state.pop(user_id, None)
        _send(chat_id, "Dibatalkan.")
    elif command == "/pelawat":
        _state[user_id] = {"step": "plate"}
        _send(chat_id, "Taip <b>nombor plat</b> kenderaan pelawat (contoh: WXY 1234).\n"
                       "Taip /batal untuk batalkan.")
    elif command == "/pas":
        _state.pop(user_id, None)
        _send_passes(chat_id, resident)
    elif command:
        _send(chat_id, "Command tak dikenali.\n\n" + HELP_TEXT)
    elif _state.get(user_id, {}).get("step") == "plate":
        _handle_plate_text(chat_id, user_id, text)
    else:
        _send(chat_id, HELP_TEXT)


def _handle_plate_text(chat_id, user_id, text):
    plate = db.normalize_plate(text)
    if not _valid_plate(plate):
        _send(chat_id, "Nombor plat tak sah. Taip semula (3-10 huruf/nombor, contoh: WXY 1234), "
                       "atau /batal.")
        return
    _state[user_id] = {"step": "duration", "plate": plate}
    _send(chat_id, f"Pas untuk <b>{html.escape(plate)}</b>. Berapa lama?",
          reply_markup=_duration_keyboard())


def _create_pass(resident, plate, duration_key):
    """Return mesej (HTML) untuk dipaparkan kepada penduduk."""
    house_ids = _house_resident_ids(resident)
    plate_html = html.escape(plate)

    existing = db.get_plate_by_number(plate)
    if existing:
        if not existing.get("is_visitor"):
            return f"ℹ️ <b>{plate_html}</b> ialah plat penduduk berdaftar - tak perlu pas pelawat."
        if _is_expired(existing):
            db.delete_plate(existing["id"], performed_by="system", action="replaced", strict=False)  # pas lama yang belum dibersihkan oleh sweep
        elif existing.get("resident_id") in house_ids:
            return (f"ℹ️ <b>{plate_html}</b> dah ada pas aktif untuk rumah anda sampai "
                    f"{_fmt_time(existing['expires_at'])}.\nGuna /pas untuk batal dan cipta semula.")
        else:
            return (f"❌ <b>{plate_html}</b> sudah ada pas aktif dari unit lain.\n"
                    "Sila hubungi guardhouse untuk bantuan.")

    if len(db.get_active_passes_for_residents(house_ids)) >= MAX_ACTIVE_PASSES_PER_HOUSE:
        return (f"❌ Rumah anda sudah ada {MAX_ACTIVE_PASSES_PER_HOUSE} pas aktif (maksimum).\n"
                "Guna /pas untuk batalkan pas yang tak diperlukan.")

    expires = _compute_expiry(duration_key)
    ok = db.add_plate(
        plate,
        owner_name=f"Pelawat {resident['house_no']}",
        house_no=resident["house_no"],
        registered_by=f"{resident['full_name']} (Telegram)",
        is_visitor=True,
        expires_at=expires.isoformat(),
        resident_id=resident["id"],
        created_via="telegram",
    )
    if not ok:
        return "❌ Gagal cipta pas. Sila cuba lagi atau hubungi guardhouse."

    print(f"[telegram] visitor pass {plate} created by {resident['full_name']} "
          f"({resident['house_no']}), expires {expires.isoformat()}")
    return (f"✅ Pas pelawat <b>{plate_html}</b> aktif sampai <b>{_fmt_time(expires)}</b> "
            f"({DURATION_LABELS[duration_key]}).\n\n"
            "Gate akan buka secara automatik bila plat ini dikesan. "
            "Sila minta pelawat <b>parking di parking pelawat</b>.")


def _send_passes(chat_id, resident):
    house_ids = _house_resident_ids(resident)
    passes = db.get_active_passes_for_residents(house_ids)
    if not passes:
        _send(chat_id, "Tiada pas pelawat aktif untuk rumah anda.\nGuna /pelawat untuk cipta pas.")
        return
    lines = [f"<b>Pas pelawat aktif ({len(passes)}/{MAX_ACTIVE_PASSES_PER_HOUSE}):</b>"]
    buttons = []
    for p in passes:
        by = (p.get("registered_by") or "").replace(" (Telegram)", "")
        lines.append(f"• <b>{html.escape(p['plate_number'])}</b> - sampai {_fmt_time(p['expires_at'])}"
                     + (f" (oleh {html.escape(by)})" if by else ""))
        buttons.append([{"text": f"❌ Batal {p['plate_number']}", "callback_data": f"cancel:{p['id']}"}])
    _send(chat_id, "\n".join(lines), reply_markup={"inline_keyboard": buttons})


def _handle_callback(cq):
    _api("answerCallbackQuery", callback_query_id=cq["id"])  # hentikan "loading" pada butang
    msg = cq.get("message")
    if not msg or msg.get("chat", {}).get("type") != "private":
        return
    chat_id = msg["chat"]["id"]
    message_id = msg["message_id"]
    user_id = cq["from"]["id"]
    data = cq.get("data") or ""

    resident = db.get_resident_by_telegram_user(user_id)
    if not resident or not resident.get("is_active"):
        _edit(chat_id, message_id, "❌ Akaun anda tidak aktif / belum disahkan. Taip /start.")
        return

    if data.startswith("dur:"):
        key = data[4:]
        state = _state.get(user_id) or {}
        if key not in DURATION_LABELS or state.get("step") != "duration":
            _edit(chat_id, message_id, "Pilihan ini dah tamat. Taip /pelawat untuk mula semula.")
            return
        _state.pop(user_id, None)
        _edit(chat_id, message_id, _create_pass(resident, state["plate"], key))

    elif data.startswith("cancel:"):
        try:
            plate = db.get_plate_by_id(int(data[7:]))
        except ValueError:
            plate = None
        if (not plate or not plate.get("is_visitor")
                or plate.get("resident_id") not in _house_resident_ids(resident)):
            _edit(chat_id, message_id, "Pas ini tidak dijumpai (mungkin dah luput atau dibatalkan).")
            return
        db.delete_plate(plate["id"], performed_by=f"resident: {resident['full_name']}",
                        action="cancelled", strict=False)
        print(f"[telegram] visitor pass {plate['plate_number']} cancelled by {resident['full_name']}")
        _edit(chat_id, message_id, f"✅ Pas <b>{html.escape(plate['plate_number'])}</b> dibatalkan.")


# ============ ENTRY NOTIFICATIONS (called from app.py) ============

def notify_entry(plate_row, plate_number, snapshot_path=None):
    """Dipanggil oleh app.py selepas plat berdaftar dikesan + gate dibuka. Hantar
    notifikasi (dengan snapshot) ke semua penghuni rumah yang dah link Telegram.
    Jalan dalam thread sendiri - tak pernah melambatkan detection."""
    if not _token or not plate_row or not plate_row.get("resident_id"):
        return
    threading.Thread(target=_notify_entry_worker, args=(plate_row, plate_number, snapshot_path),
                     daemon=True).start()


def _notify_entry_worker(plate_row, plate_number, snapshot_path):
    try:
        owner = db.get_resident_by_id(plate_row["resident_id"])
        if not owner:
            return
        recipients = [r for r in db.get_house_residents(owner["house_no"]) if r.get("telegram_chat_id")]
        if not recipients:
            return
        now = datetime.now(MY_TZ)
        plate_html = html.escape(plate_number)
        if plate_row.get("is_visitor"):
            caption = f"🚗 Pelawat <b>{plate_html}</b> telah masuk pada {now:%H:%M}."
            if plate_row.get("expires_at"):
                caption += f"\nPas luput: {_fmt_time(plate_row['expires_at'])}"
        else:
            caption = f"🏠 Kereta <b>{plate_html}</b> telah masuk pada {now:%H:%M}."
        for r in recipients:
            if snapshot_path and os.path.exists(snapshot_path):
                _send_photo(r["telegram_chat_id"], snapshot_path, caption)
            else:
                _send(r["telegram_chat_id"], caption)
    except Exception as e:
        print(f"[telegram] notify_entry error for {plate_number}: {e}")


# ============ POLLING LOOP ============

def _poll_loop():
    offset = None
    while True:
        params = {"timeout": POLL_TIMEOUT, "allowed_updates": ["message", "callback_query"]}
        if offset is not None:
            params["offset"] = offset
        try:
            resp = requests.post(f"https://api.telegram.org/bot{_token}/getUpdates",
                                 json=params, timeout=POLL_TIMEOUT + 10)
            data = resp.json()
        except Exception as e:
            print(f"[telegram] getUpdates failed (no internet?): {e}")
            time.sleep(5)
            continue

        if not data.get("ok"):
            code = data.get("error_code")
            if code == 401:
                print("[telegram] TELEGRAM_BOT_TOKEN is invalid - bot stopped. Check .env.")
                return
            if code == 409:
                print("[telegram] Another bot instance is using this token (old Pi bot.py still "
                      "running?). Stop it - retrying in 10s.")
            else:
                print(f"[telegram] getUpdates error {code}: {data.get('description')}")
            time.sleep(10)
            continue

        for update in data.get("result", []):
            offset = update["update_id"] + 1
            try:
                if "message" in update:
                    _handle_message(update["message"])
                elif "callback_query" in update:
                    _handle_callback(update["callback_query"])
            except Exception as e:
                # Satu mesej rosak / Supabase down tak boleh matikan bot
                print(f"[telegram] error handling update {update.get('update_id')}: {e}")


def start():
    """Dipanggil sekali dari app.py. Tiada token = bot tak jalan, app tetap jalan biasa."""
    global _token
    _token = (os.environ.get("TELEGRAM_BOT_TOKEN") or "").strip()
    if not _token:
        print("[telegram] TELEGRAM_BOT_TOKEN not set in .env - Telegram bot disabled.")
        return
    me = _api("getMe")
    if not me:
        print("[telegram] Could not reach Telegram (bad token or no internet) - will keep retrying.")
    else:
        print(f"[telegram] Bot @{me.get('username')} running (resident-only).")
    _api("deleteWebhook")  # long polling tak boleh jalan kalau ada webhook lama
    _api("setMyCommands", commands=[
        {"command": "pelawat", "description": "Daftar pas pelawat"},
        {"command": "pas", "description": "Senarai & batal pas pelawat"},
        {"command": "batal", "description": "Batalkan langkah semasa"},
        {"command": "help", "description": "Bantuan"},
    ])
    threading.Thread(target=_poll_loop, daemon=True).start()
