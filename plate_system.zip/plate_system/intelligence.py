"""
NEXGUARD Security Intelligence - read-only analytics + audit API.

Design rules (see NEXGUARD_REDESIGN_REPORT.md):
  * READ-ONLY. Nothing in here writes to Supabase or talks to the Pi.
  * Head Guard only (decorators are injected from app.py so permissions stay in one place).
  * Every list endpoint is server-side paginated / bounded; nothing loads a whole table.
  * All dates are Malaysia time (UTC+08:00). Rows are stored in UTC and converted here.
  * Only metrics the database can genuinely support are computed. Anything else is reported
    by /api/intel/meta as "not recorded" together with the smallest change that would fix it.
"""
import csv
import io
import re
from collections import Counter, defaultdict
from datetime import date, datetime, time as dtime, timedelta, timezone

from flask import Blueprint, Response, jsonify, render_template, request, session

MY_TZ = timezone(timedelta(hours=8))
TZ_LABEL = "Asia/Kuala_Lumpur (UTC+08:00)"

MAX_RANGE_DAYS = 366
PAGE_SIZE_DEFAULT = 25
PAGE_SIZE_MAX = 100
SERIES_ROW_CAP = 20000      # max rows scanned to build one chart/aggregate (flagged as truncated)
EXPORT_ROW_CAP = 20000
FETCH_CHUNK = 1000
EXPIRY_SOON_HOURS = 24
OPEN_SESSION_MAX_HOURS = 16  # no logout + started more recently than this -> "open"; older -> "incomplete"
OVERRIDE_PROXIMITY_MIN = 5   # vehicle timeline: override shown as "nearby" if within this many minutes

LOG_STATUS_LABEL = {
    "registered": "Authorized",
    "unregistered": "Unregistered plate",
    "manual": "Manual override",
}


class BadRequest(Exception):
    pass


# --------------------------------------------------------------------------- helpers

def _parse_ts(value):
    """Parse a Supabase/Postgres timestamp into an aware datetime (UTC if no tz)."""
    if not value:
        return None
    s = str(value).strip().replace("Z", "+00:00").replace(" ", "T", 1)
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        # Postgres can emit 1-5 digit fractional seconds on older Pythons - drop the fraction.
        try:
            dt = datetime.fromisoformat(re.sub(r"\.\d+", "", s))
        except ValueError:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _utc_z(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_day(value, label):
    try:
        return date.fromisoformat(str(value))
    except (TypeError, ValueError):
        raise BadRequest(f"'{label}' must be a date in YYYY-MM-DD format")


def resolve_range(a, allow_all=False):
    """Turn ?range=today|7d|30d|custom (&from=&to=) or ?day= into concrete MYT + UTC bounds."""
    today = datetime.now(MY_TZ).date()
    rng = (a.get("range") or "7d").lower()
    if a.get("day"):
        rng, start, end = "custom", _parse_day(a.get("day"), "day"), _parse_day(a.get("day"), "day")
    elif rng == "today":
        start = end = today
    elif rng == "7d":
        start, end = today - timedelta(days=6), today
    elif rng == "30d":
        start, end = today - timedelta(days=29), today
    elif rng == "all" and allow_all:
        start, end = date(2020, 1, 1), today
    elif rng == "custom":
        start, end = _parse_day(a.get("from"), "from"), _parse_day(a.get("to"), "to")
    else:
        raise BadRequest("range must be one of: today, 7d, 30d, custom")
    if end < start:
        raise BadRequest("The end date is before the start date")
    if rng != "all" and (end - start).days + 1 > MAX_RANGE_DAYS:
        raise BadRequest(f"Date range can't exceed {MAX_RANGE_DAYS} days")
    start_dt = datetime.combine(start, dtime.min, MY_TZ)
    end_dt = datetime.combine(end + timedelta(days=1), dtime.min, MY_TZ)  # exclusive
    return {
        "range": rng, "from": start.isoformat(), "to": end.isoformat(), "tz": TZ_LABEL,
        "days": (end - start).days + 1,
        "start_iso": _utc_z(start_dt), "end_iso": _utc_z(end_dt),
    }


def _public_range(r):
    return {k: r[k] for k in ("range", "from", "to", "tz", "days")}


def _int(a, name, default, lo, hi):
    raw = a.get(name)
    if raw in (None, ""):
        return default
    try:
        v = int(raw)
    except ValueError:
        raise BadRequest(f"'{name}' must be a whole number")
    return max(lo, min(hi, v))


def _float(a, name):
    raw = a.get(name)
    if raw in (None, ""):
        return None
    try:
        return float(raw)
    except ValueError:
        raise BadRequest(f"'{name}' must be a number")


def _clean_text(value, limit=40):
    """Search text: letters/digits/space/dash only - keeps PostgREST filter syntax safe."""
    return re.sub(r"[^A-Za-z0-9 \-]", "", value or "").strip()[:limit]


def _clean_plate(value):
    return re.sub(r"[^A-Z0-9]", "", (value or "").upper())[:14]


def _photo_url(path):
    return "/" + str(path).lstrip("/") if path else None


def _csv_safe(v):
    """Neutralise spreadsheet formula injection in exported cells."""
    if v is None:
        return ""
    s = str(v)
    return "'" + s if s[:1] in ("=", "+", "-", "@", "\t", "\r") else s


def _hours_between(a, b):
    return (b - a).total_seconds() / 3600.0


# --------------------------------------------------------------------------- record kinds

# date_col None => not date-filtered (current-state views)
KINDS = {
    "registered_plates": dict(table="plates", date_col=None, default_sort="registered_at",
                              sorts={"registered_at": "registered_at", "plate": "plate_number",
                                     "guard": "registered_by", "house": "house_no"}),
    "registrations": dict(table="plates", date_col="registered_at", default_sort="registered_at",
                          sorts={"registered_at": "registered_at", "plate": "plate_number",
                                 "guard": "registered_by", "expires": "expires_at"}),
    "visitors": dict(table="plates", date_col=None, default_sort="expires_at", default_dir="asc",
                     sorts={"expires": "expires_at", "plate": "plate_number", "registered_at": "registered_at"}),
    "authorized": dict(table="logs", date_col="timestamp", status=("registered",), default_sort="timestamp",
                       sorts={"time": "timestamp", "plate": "plate_number", "confidence": "confidence"}),
    "unregistered": dict(table="logs", date_col="timestamp", status=("unregistered",), default_sort="timestamp",
                         sorts={"time": "timestamp", "plate": "plate_number", "confidence": "confidence"}),
    "detections": dict(table="logs", date_col="timestamp", status=("registered", "unregistered"),
                       default_sort="timestamp",
                       sorts={"time": "timestamp", "plate": "plate_number", "confidence": "confidence"}),
    "overrides": dict(table="logs", date_col="timestamp", status=("manual",), default_sort="timestamp",
                      sorts={"time": "timestamp", "guard": "performed_by", "reason": "reason_code"}),
    "sessions": dict(table="login_logs", date_col="login_at", default_sort="login_at",
                     sorts={"login": "login_at", "logout": "logout_at", "guard": "guard_name"}),
    "alerts": dict(table="alerts", date_col="created_at", default_sort="created_at",
                   sorts={"time": "created_at", "plate": "plate_number", "count": "occurrence_count"}),
}
LOG_KINDS = {k for k, c in KINDS.items() if c["table"] == "logs"}

# Columns written to CSV exports (owner names are deliberately left out - not needed for audit).
EXPORT_COLUMNS = {
    "registered_plates": ["plate_number", "category", "state", "registered_at", "registered_by", "house_no",
                          "car_type", "car_color", "expires_at"],
    "registrations": ["plate_number", "category", "state", "registered_at", "registered_by", "house_no",
                      "car_type", "car_color", "expires_at"],
    "visitors": ["plate_number", "state", "registered_at", "registered_by", "house_no", "expires_at"],
    "authorized": ["timestamp", "plate_number", "status_label", "confidence", "has_snapshot"],
    "unregistered": ["timestamp", "plate_number", "status_label", "confidence", "has_snapshot"],
    "detections": ["timestamp", "plate_number", "status_label", "confidence", "has_snapshot"],
    "overrides": ["timestamp", "performed_by", "reason_label", "note"],
    "sessions": ["guard_name", "username", "login_at", "logout_at", "state", "duration_minutes"],
    "alerts": ["created_at", "plate_number", "alert_type", "occurrence_count", "window_minutes", "review_state",
               "acknowledged_by", "acknowledged_at"],
}


def register(app, *, db, head_guard_page, head_guard_api, override_labels, system_status_fn,
             guard_page=None, guard_api=None):
    """Attach the Security Intelligence page + API to the Flask app."""
    sb = db.supabase
    bp = Blueprint("intel", __name__)

    # ----------------------------------------------------------------- query plumbing

    def _count(table, mutate=None):
        q = sb.table(table).select("id", count="exact")
        if mutate:
            q = mutate(q)
        res = q.limit(1).execute()
        return int(res.count or 0)

    def _fetch_rows(table, cols, date_col, rng, mutate=None, cap=SERIES_ROW_CAP):
        """Bounded scan used for charts/aggregates. Returns (rows, truncated)."""
        rows, offset = [], 0
        while offset < cap:
            q = sb.table(table).select(cols)
            if date_col and rng:
                q = q.gte(date_col, rng["start_iso"]).lt(date_col, rng["end_iso"])
            if mutate:
                q = mutate(q)
            res = q.order(date_col or "id").order("id").range(offset, offset + FETCH_CHUNK - 1).execute()
            chunk = res.data or []
            rows.extend(chunk)
            if len(chunk) < FETCH_CHUNK:
                return rows, False
            offset += FETCH_CHUNK
        return rows[:cap], True

    def _apply_filters(kind, q, a, rng):
        cfg = KINDS[kind]
        now_z = _utc_z(datetime.now(timezone.utc))
        if cfg.get("date_col") and rng:
            q = q.gte(cfg["date_col"], rng["start_iso"]).lt(cfg["date_col"], rng["end_iso"])

        search = (a.get("q") or "")
        plate_term = _clean_plate(search)
        text_term = _clean_text(search)

        if cfg["table"] == "logs":
            statuses = cfg["status"]
            q = q.eq("status", statuses[0]) if len(statuses) == 1 else q.in_("status", list(statuses))
            if plate_term:
                q = q.ilike("plate_number", f"%{plate_term}%")
            if a.get("guard"):
                q = q.eq("performed_by", a.get("guard")[:80])
            if kind == "overrides" and a.get("reason"):
                q = q.eq("reason_code", _clean_text(a.get("reason"), 30))
            lo, hi = _float(a, "conf_min"), _float(a, "conf_max")
            if lo is not None:
                q = q.gte("confidence", lo)
            if hi is not None:
                q = q.lt("confidence", hi)

        elif cfg["table"] == "plates":
            if kind == "visitors":
                q = q.eq("is_visitor", True)
                soon_z = _utc_z(datetime.now(timezone.utc) + timedelta(hours=EXPIRY_SOON_HOURS))
                state = a.get("state")
                if state == "active":
                    q = q.gt("expires_at", now_z)
                elif state == "expiring":
                    q = q.gt("expires_at", now_z).lte("expires_at", soon_z)
                elif state == "expired":
                    q = q.lte("expires_at", now_z)
            else:
                cat = a.get("category")
                if cat == "visitor":
                    q = q.eq("is_visitor", True)
                elif cat == "resident":
                    q = q.eq("is_visitor", False)
                validity = a.get("validity")  # only meaningful for visitor passes
                if validity == "active":
                    q = q.eq("is_visitor", True).gt("expires_at", now_z)
                elif validity == "expired":
                    q = q.eq("is_visitor", True).lte("expires_at", now_z)
            if a.get("guard"):
                q = q.eq("registered_by", a.get("guard")[:80])
            if plate_term or text_term:
                parts = []
                if plate_term:
                    parts.append(f"plate_number.ilike.%{plate_term}%")
                if text_term:
                    t = text_term.replace(" ", "%")
                    parts += [f"owner_name.ilike.%{t}%", f"house_no.ilike.%{t}%"]
                q = q.or_(",".join(parts))

        elif cfg["table"] == "login_logs":
            if a.get("guard"):
                q = q.eq("guard_name", a.get("guard")[:80])
            st = a.get("session_state")
            if st == "closed":
                q = q.not_.is_("logout_at", "null")
            elif st in ("nologout", "open", "incomplete"):
                q = q.is_("logout_at", "null")  # open/incomplete are refined per-page after shaping
            if text_term:
                q = q.ilike("guard_name", f"%{text_term}%")

        elif cfg["table"] == "alerts":
            rv = a.get("review")
            if rv == "open":
                q = q.eq("acknowledged", False)
            elif rv == "reviewed":
                q = q.eq("acknowledged", True)
            if plate_term:
                q = q.ilike("plate_number", f"%{plate_term}%")
        return q

    # ----------------------------------------------------------------- row shaping

    def _plate_state(p, now):
        if not p.get("is_visitor"):
            return "resident"
        exp = _parse_ts(p.get("expires_at"))
        if exp is None:
            return "visitor_no_expiry"
        if exp <= now:
            return "visitor_expired"
        if exp - now <= timedelta(hours=EXPIRY_SOON_HOURS):
            return "visitor_expiring"
        return "visitor_active"

    def _shape(kind, r, now):
        t = KINDS[kind]["table"]
        if t == "plates":
            return {
                "id": r.get("id"), "plate_number": r.get("plate_number"),
                "owner_name": r.get("owner_name"), "house_no": r.get("house_no"),
                "car_type": r.get("car_type"), "car_color": r.get("car_color"),
                "registered_by": r.get("registered_by"), "registered_at": r.get("registered_at"),
                "category": "Visitor pass" if r.get("is_visitor") else "Registered vehicle",
                "is_visitor": bool(r.get("is_visitor")), "expires_at": r.get("expires_at"),
                "state": _plate_state(r, now), "created_via": r.get("created_via"),
                "photo_url": _photo_url(r.get("photo_path")),
            }
        if t == "logs":
            code = r.get("reason_code")
            return {
                "id": r.get("id"), "timestamp": r.get("timestamp"), "plate_number": r.get("plate_number"),
                "status": r.get("status"), "status_label": LOG_STATUS_LABEL.get(r.get("status"), r.get("status")),
                "confidence": r.get("confidence"), "performed_by": r.get("performed_by"),
                "reason_code": code, "reason_label": override_labels.get(code, code) if code else None,
                "note": r.get("note"), "snapshot_url": _photo_url(r.get("snapshot_path")),
                "has_snapshot": bool(r.get("snapshot_path")),
            }
        if t == "login_logs":
            li, lo = _parse_ts(r.get("login_at")), _parse_ts(r.get("logout_at"))
            if lo and li:
                state, dur = "closed", round((lo - li).total_seconds() / 60.0, 1)
                if dur < 0:
                    state, dur = "invalid", None
            elif li and _hours_between(li, now) <= OPEN_SESSION_MAX_HOURS:
                state, dur = "open", None
            else:
                state, dur = "incomplete", None
            return {
                "id": r.get("id"), "guard_name": r.get("guard_name"), "username": r.get("username"),
                "login_at": r.get("login_at"), "logout_at": r.get("logout_at"),
                "state": state, "duration_minutes": dur,
            }
        if t == "alerts":
            ack = bool(r.get("acknowledged"))
            return {
                "id": r.get("id"), "created_at": r.get("created_at"), "plate_number": r.get("plate_number"),
                "alert_type": r.get("alert_type"), "occurrence_count": r.get("occurrence_count"),
                "window_minutes": r.get("window_minutes"), "acknowledged": ack,
                "review_state": "reviewed" if ack else "open",
                "acknowledged_by": r.get("acknowledged_by"), "acknowledged_at": r.get("acknowledged_at"),
            }
        return r

    # ----------------------------------------------------------------- generic record query

    def _hour_filtered_ids(kind, a, rng, hour):
        rows, truncated = _fetch_rows("logs", "id,timestamp", "timestamp", rng,
                                      mutate=lambda q: _apply_filters(kind, q, a, None))
        ids = []
        for r in rows:
            ts = _parse_ts(r.get("timestamp"))
            if ts and ts.astimezone(MY_TZ).hour == hour:
                ids.append((ts, r["id"]))
        ids.sort(reverse=True)
        return [i for _, i in ids], truncated

    def run_records(kind, a, paginate=True):
        cfg = KINDS[kind]
        rng = resolve_range(a) if cfg.get("date_col") else None
        page = _int(a, "page", 1, 1, 100000)
        size = _int(a, "page_size", PAGE_SIZE_DEFAULT, 5, PAGE_SIZE_MAX)
        sort_key = a.get("sort") if a.get("sort") in cfg["sorts"] else None
        sort_col = cfg["sorts"][sort_key] if sort_key else cfg["default_sort"]
        direction = a.get("dir") if a.get("dir") in ("asc", "desc") else cfg.get("default_dir", "desc")
        now = datetime.now(timezone.utc)
        hour = _int(a, "hour", None, 0, 23) if (kind in LOG_KINDS and a.get("hour") not in (None, "")) else None

        # Tables whose derived "state" can't be expressed as a SQL filter are post-filtered:
        # (sessions open vs incomplete). Handled below for that single case.
        if hour is not None:
            ids, truncated = _hour_filtered_ids(kind, a, rng, hour)
            total = len(ids)
            sl = ids[(page - 1) * size: page * size]
            rows = []
            if sl:
                res = sb.table("logs").select("*").in_("id", sl).execute()
                by_id = {r["id"]: r for r in (res.data or [])}
                rows = [by_id[i] for i in sl if i in by_id]
            return {"kind": kind, "items": [_shape(kind, r, now) for r in rows], "total": total, "page": page,
                    "page_size": size, "pages": max(1, -(-total // size)),
                    "range": _public_range(rng) if rng else None, "truncated": truncated}

        q = sb.table(cfg["table"]).select("*", count="exact")
        q = _apply_filters(kind, q, a, rng)
        q = q.order(sort_col, desc=(direction == "desc")).order("id", desc=(direction == "desc"))
        if paginate:
            q = q.range((page - 1) * size, page * size - 1)
        res = q.execute()
        items = [_shape(kind, r, now) for r in (res.data or [])]
        if kind == "sessions" and a.get("session_state") in ("open", "incomplete"):
            want = a.get("session_state")
            items = [i for i in items if i["state"] == want]  # page-level refinement (see report)
        total = int(res.count if res.count is not None else len(items))
        return {"kind": kind, "items": items, "total": total, "page": page, "page_size": size,
                "pages": max(1, -(-total // size)), "range": _public_range(rng) if rng else None,
                "sort": sort_key or None, "dir": direction}

    # ----------------------------------------------------------------- role scoping
    # Head Guard sees everything. A normal guard gets a trimmed, READ-ONLY, today-only view
    # (operational data needed at the gate). This is enforced HERE on the server - hiding tabs in
    # the browser alone would not stop a guard calling the API directly.

    GUARD_RECORD_KINDS = {"authorized", "unregistered", "detections", "visitors", "alerts"}
    GUARD_HIDDEN_KPIS = ("registrations", "visitor_registrations", "sessions", "sessions_no_logout",
                         "registered_plates")
    GUARD_LOOKUP_DAYS = 3

    def _is_head():
        return session.get("guard_role") == "head_guard"

    def _deny(msg):
        return jsonify({"error": msg}), 403

    def role_gate(fn, *, head_only=False, today_only=False, kinds=None, strip_kpis=False,
                  strip_guards=False, lookup=False):
        import functools

        @functools.wraps(fn)
        def gated(*args, **kwargs):
            if _is_head():
                return fn(*args, **kwargs)
            if head_only:
                return _deny("This section is for the Head Guard only.")
            if kinds is not None and kwargs.get("kind") not in kinds:
                return _deny("This record type is for the Head Guard only.")
            if today_only and kwargs.get("kind") != "visitors":
                today = datetime.now(MY_TZ).date().isoformat()
                rname = (request.args.get("range") or "").lower()
                day = request.args.get("day")
                if not ((rname == "today" and not day) or day == today):
                    return _deny("Guards can view today's data only.")
            if lookup:
                try:
                    rng = resolve_range(request.args, allow_all=True)
                except BadRequest as e:
                    return jsonify({"error": str(e)}), 400
                oldest = datetime.now(MY_TZ).date() - timedelta(days=GUARD_LOOKUP_DAYS - 1)
                if rng["range"] == "all" or date.fromisoformat(rng["from"]) < oldest:
                    return _deny(f"Guards can look back {GUARD_LOOKUP_DAYS} days only.")
                if not db.log_lookup(session.get("guard_name"), request.args.get("plate")):
                    return jsonify({"error": "Lookups must be recorded - run migrations_security_rules.sql first."}), 500
            resp = fn(*args, **kwargs)
            if strip_kpis or strip_guards:
                try:
                    data = resp.get_json()
                    if strip_kpis and data and "kpis" in data:
                        for k in GUARD_HIDDEN_KPIS:
                            data["kpis"].pop(k, None)
                    if strip_guards and data:
                        data["guards"] = []
                    return jsonify(data)
                except AttributeError:
                    return resp   # an (error, status) tuple - leave untouched
            return resp
        return gated

    # ----------------------------------------------------------------- error wrapper

    def safe(fn):
        import functools

        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except BadRequest as e:
                return jsonify({"error": str(e)}), 400
            except Exception as e:  # DB/network problem - never leak internals to the browser
                print(f"[intelligence] {fn.__name__} failed: {type(e).__name__}: {e}")
                return jsonify({"error": "The database query failed. Check the Supabase connection and try again."}), 502
        return wrapped

    # ----------------------------------------------------------------- routes

    def page_view():
        return render_template("intelligence.html", is_head=_is_head())

    @safe
    def meta_view():
        guards = []
        try:
            guards = [{"name": g.get("full_name"), "role": g.get("role"), "active": g.get("is_active", True)}
                      for g in db.list_guards(include_inactive=True) if g.get("full_name")]
        except Exception as e:
            print(f"[intelligence] guard list failed: {e}")
        reviewer_cols = True
        try:
            sb.table("alerts").select("acknowledged_by,acknowledged_at").limit(1).execute()
        except Exception:
            reviewer_cols = False
        return jsonify({
            "tz": TZ_LABEL, "max_range_days": MAX_RANGE_DAYS, "guards": guards,
            "override_reasons": [{"value": k, "label": v} for k, v in override_labels.items()],
            "expiry_soon_hours": EXPIRY_SOON_HOURS, "open_session_max_hours": OPEN_SESSION_MAX_HOURS,
            "override_proximity_min": OVERRIDE_PROXIMITY_MIN, "series_row_cap": SERIES_ROW_CAP,
            "availability": [
                {"key": "entry_exit", "label": "Entry vs exit direction", "recorded": False,
                 "why": "Logs store one detection per read and no direction field; a single camera cannot tell entry from exit.",
                 "fix": "Add logs.direction ('in'|'out') populated by a second camera/sensor, then enable reconciliation."},
                {"key": "override_ack", "label": "Override hardware acknowledgement", "recorded": False,
                 "why": "The override is logged before the Pi request and the Pi's HTTP result is not stored.",
                 "fix": "Add logs.gate_command_result (+ http code) and update the row after the POST returns. Physical gate position would still need a Pi-side sensor report."},
                {"key": "failed_reads", "label": "Failed / empty recognition attempts", "recorded": False,
                 "why": "Only plates that pass voting are written to logs; empty or rejected reads are discarded.",
                 "fix": "Add a lightweight counter table (attempts, empty reads, OCR-only fallbacks) incremented in process_and_log()."},
                {"key": "latency", "label": "Processing latency", "recorded": False,
                 "why": "Detection time is not measured or stored.",
                 "fix": "Record per-pass duration in the same counter table."},
                {"key": "ocr_conf", "label": "OCR confidence", "recorded": False,
                 "why": "logs.confidence holds the YOLO box score (OCR score only on the fallback path); ocr_confidence is not stored.",
                 "fix": "Add logs.ocr_confidence."},
                {"key": "camera_history", "label": "Camera / hardware uptime history", "recorded": False,
                 "why": "Only the live camera state is available; no online/offline transitions are stored.",
                 "fix": "Write a device_events row whenever camera or Pi reachability changes."},
                {"key": "failed_logins", "label": "Failed login attempts", "recorded": False,
                 "why": "login_logs only records successful sign-ins.",
                 "fix": "Insert a login_attempts row (username, success, time, IP) from /login."},
                {"key": "deleted_plates", "label": "History of removed / expired plates", "recorded": False,
                 "why": "Visitor passes are hard-deleted at expiry and guards can delete plates, so their registration record is gone.",
                 "fix": "Soft-delete (deleted_at, deleted_by) instead of DELETE, or copy rows to a plates_audit table first."},
                {"key": "override_plate", "label": "Vehicle linked to a manual override", "recorded": False,
                 "why": "Overrides are stored with plate_number='MANUAL'.",
                 "fix": "Optionally let the guard pick the related log/plate when confirming an override."},
                {"key": "alert_reviewer", "label": "Alert reviewer and review time", "recorded": reviewer_cols,
                 "why": "Reviewer columns exist." if reviewer_cols else "alerts.acknowledged is a bare boolean.",
                 "fix": "" if reviewer_cols else "Run migrations_audit_trail.sql (additive, idempotent)."},
                {"key": "confidence", "label": "Detector confidence per logged read", "recorded": True,
                 "why": "Available. It is a model score, not a measured accuracy.", "fix": ""},
                {"key": "override_reason", "label": "Override reason and note", "recorded": True,
                 "why": "Available since migrations_new_features.sql.", "fix": ""},
                {"key": "sessions", "label": "Login / logout sessions", "recorded": True,
                 "why": "Available. A missing logout leaves the session open/incomplete.", "fix": ""},
            ],
        })

    @safe
    def summary_view():
        rng = resolve_range(request.args)
        now_z = _utc_z(datetime.now(timezone.utc))
        soon_z = _utc_z(datetime.now(timezone.utc) + timedelta(hours=EXPIRY_SOON_HOURS))
        in_range = lambda col: (lambda q: q.gte(col, rng["start_iso"]).lt(col, rng["end_iso"]))

        def log_count(status):
            return _count("logs", lambda q: in_range("timestamp")(q).eq("status", status))

        authorized, unreg, manual = log_count("registered"), log_count("unregistered"), log_count("manual")
        sessions_total = _count("login_logs", in_range("login_at"))
        sessions_no_logout = _count("login_logs", lambda q: in_range("login_at")(q).is_("logout_at", "null"))
        return jsonify({
            "range": _public_range(rng),
            "kpis": {
                "registered_plates": _count("plates"),
                "registrations": _count("plates", in_range("registered_at")),
                "visitor_registrations": _count("plates", lambda q: in_range("registered_at")(q).eq("is_visitor", True)),
                "detections": authorized + unreg,
                "authorized": authorized,
                "unregistered": unreg,
                "overrides": manual,
                "sessions": sessions_total,
                "sessions_no_logout": sessions_no_logout,
                "alerts": _count("alerts", in_range("created_at")),
                "alerts_open": _count("alerts", lambda q: in_range("created_at")(q).eq("acknowledged", False)),
                "visitors_active": _count("plates", lambda q: q.eq("is_visitor", True).gt("expires_at", now_z)),
                "visitors_expiring": _count("plates", lambda q: q.eq("is_visitor", True).gt("expires_at", now_z).lte("expires_at", soon_z)),
                "visitors_expired_unswept": _count("plates", lambda q: q.eq("is_visitor", True).lte("expires_at", now_z)),
            },
        })

    @safe
    def records_view(kind):
        if kind not in KINDS:
            raise BadRequest("Unknown record type")
        return jsonify(run_records(kind, request.args))

    @safe
    def traffic_view():
        rng = resolve_range(request.args)
        rows, truncated = _fetch_rows("logs", "timestamp,status,reason_code", "timestamp", rng)
        key = {"registered": "authorized", "unregistered": "unregistered", "manual": "manual"}
        reason_counts = Counter(r.get("reason_code") or "(none recorded)" for r in rows if r.get("status") == "manual")
        days = {}
        d = date.fromisoformat(rng["from"])
        while d <= date.fromisoformat(rng["to"]):
            days[d.isoformat()] = {"date": d.isoformat(), "authorized": 0, "unregistered": 0, "manual": 0}
            d += timedelta(days=1)
        hours = {h: {"hour": h, "authorized": 0, "unregistered": 0, "manual": 0} for h in range(24)}
        for r in rows:
            ts, k = _parse_ts(r.get("timestamp")), key.get(r.get("status"))
            if not ts or not k:
                continue
            local = ts.astimezone(MY_TZ)
            if local.date().isoformat() in days:
                days[local.date().isoformat()][k] += 1
            hours[local.hour][k] += 1
        daily = list(days.values())
        hourly = list(hours.values())
        for x in daily + hourly:
            x["total"] = x["authorized"] + x["unregistered"] + x["manual"]
        det = lambda x: x["authorized"] + x["unregistered"]
        peaks = sorted((h for h in hourly if det(h) > 0), key=det, reverse=True)[:3]
        return jsonify({
            "range": _public_range(rng), "daily": daily, "hourly": hourly,
            "peak_hours": [{"hour": h["hour"], "detections": det(h)} for h in peaks],
            "override_reasons": [{"code": (None if k == "(none recorded)" else k),
                                  "label": override_labels.get(k, k), "count": v}
                                 for k, v in reason_counts.most_common()],
            "scanned_rows": len(rows), "truncated": truncated, "row_cap": SERIES_ROW_CAP,
        })

    @safe
    def recognition_view():
        rng = resolve_range(request.args)
        rows, truncated = _fetch_rows(
            "logs", "id,confidence,status,timestamp", "timestamp", rng,
            mutate=lambda q: q.in_("status", ["registered", "unregistered"]))
        with_conf = [r for r in rows if isinstance(r.get("confidence"), (int, float))]
        bins = [{"min": round(i / 10, 1), "max": round((i + 1) / 10, 1) if i < 9 else 1.0001, "count": 0} for i in range(10)]
        for r in with_conf:
            bins[min(9, max(0, int(r["confidence"] * 10)))]["count"] += 1
        vals = sorted(r["confidence"] for r in with_conf)
        n = len(vals)
        stats = None
        if n:
            stats = {"count": n, "mean": round(sum(vals) / n, 3),
                     "median": round(vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2, 3),
                     "min": round(vals[0], 3), "max": round(vals[-1], 3),
                     "below_050": sum(1 for v in vals if v < 0.5)}
        daily = defaultdict(list)
        for r in with_conf:
            ts = _parse_ts(r.get("timestamp"))
            if ts:
                daily[ts.astimezone(MY_TZ).date().isoformat()].append(r["confidence"])
        trend = [{"date": k, "mean": round(sum(v) / len(v), 3), "count": len(v)} for k, v in sorted(daily.items())]
        return jsonify({
            "range": _public_range(rng), "logged_reads": len(rows), "reads_with_confidence": n,
            "bins": bins, "stats": stats, "daily_mean": trend, "truncated": truncated,
            "score_source": "Detector confidence stored in logs.confidence (YOLO plate-box score; EasyOCR score when the full-frame OCR fallback produced the read). It is a model score, not measured accuracy.",
        })

    @safe
    def guards_view():
        rng = resolve_range(request.args)
        sess, t1 = _fetch_rows("login_logs", "id,guard_name,login_at,logout_at", "login_at", rng)
        regs, t2 = _fetch_rows("plates", "id,registered_by,registered_at", "registered_at", rng)
        ovr, t3 = _fetch_rows("logs", "id,performed_by,timestamp", "timestamp", rng,
                              mutate=lambda q: q.eq("status", "manual"))
        now = datetime.now(timezone.utc)
        per = {}

        def g(name):
            return per.setdefault(name or "(unnamed)", {"guard": name or "(unnamed)", "sessions": 0,
                                                       "closed_sessions": 0, "open_sessions": 0, "incomplete_sessions": 0,
                                                       "logged_in_minutes": 0.0, "registrations": 0, "overrides": 0,
                                                       "last_login": None})
        by_day, by_hour = Counter(), Counter()
        buckets = [("< 15 min", 0, 15), ("15 min - 1 h", 15, 60), ("1 - 4 h", 60, 240),
                   ("4 - 8 h", 240, 480), ("8 - 12 h", 480, 720), ("> 12 h", 720, 10 ** 9)]
        dur = {b[0]: 0 for b in buckets}
        for s in sess:
            li, lo = _parse_ts(s.get("login_at")), _parse_ts(s.get("logout_at"))
            row = g(s.get("guard_name"))
            row["sessions"] += 1
            if li:
                local = li.astimezone(MY_TZ)
                by_day[local.date().isoformat()] += 1
                by_hour[local.hour] += 1
                if not row["last_login"] or s["login_at"] > row["last_login"]:
                    row["last_login"] = s["login_at"]
            if li and lo and lo >= li:
                m = (lo - li).total_seconds() / 60.0
                row["closed_sessions"] += 1
                row["logged_in_minutes"] += m
                for label, a_, b_ in buckets:
                    if a_ <= m < b_:
                        dur[label] += 1
                        break
            elif li and _hours_between(li, now) <= OPEN_SESSION_MAX_HOURS and not lo:
                row["open_sessions"] += 1
            else:
                row["incomplete_sessions"] += 1
        for r in regs:
            g(r.get("registered_by"))["registrations"] += 1
        for r in ovr:
            g(r.get("performed_by"))["overrides"] += 1
        guards = sorted(per.values(), key=lambda x: x["guard"].lower())  # alphabetical on purpose: not a ranking
        for x in guards:
            x["logged_in_minutes"] = round(x["logged_in_minutes"], 1)
        d, daily = date.fromisoformat(rng["from"]), []
        while d <= date.fromisoformat(rng["to"]):
            daily.append({"date": d.isoformat(), "sessions": by_day.get(d.isoformat(), 0)})
            d += timedelta(days=1)
        return jsonify({
            "range": _public_range(rng), "guards": guards, "sessions_by_day": daily,
            "logins_by_hour": [{"hour": h, "sessions": by_hour.get(h, 0)} for h in range(24)],
            "duration_distribution": [{"label": k, "count": v} for k, v in dur.items()],
            "no_logout_total": sum(x["open_sessions"] + x["incomplete_sessions"] for x in guards),
            "truncated": t1 or t2 or t3,
        })

    @safe
    def vehicle_view():
        plate = _clean_plate(request.args.get("plate"))
        if len(plate) < 2:
            raise BadRequest("Enter at least 2 characters of a plate number")
        rng = resolve_range(request.args, allow_all=True)
        wanted = set((request.args.get("types") or "detection,registration,alert,override_nearby").split(","))
        now = datetime.now(timezone.utc)
        normalized = db.normalize_plate(plate) or plate

        plate_row = None
        res = sb.table("plates").select("*").eq("plate_number", normalized).limit(1).execute()
        if res.data:
            plate_row = _shape("registered_plates", res.data[0], now)

        logs_res = (sb.table("logs").select("*").eq("plate_number", normalized)
                    .in_("status", ["registered", "unregistered"])
                    .gte("timestamp", rng["start_iso"]).lt("timestamp", rng["end_iso"])
                    .order("timestamp", desc=True).limit(300).execute())
        logs = logs_res.data or []
        events = []
        if "detection" in wanted:
            for r in logs:
                s = _shape("detections", r, now)
                events.append({"type": "detection", "time": s["timestamp"], "title": s["status_label"],
                               "status": s["status"], "confidence": s["confidence"],
                               "snapshot_url": s["snapshot_url"], "id": s["id"]})
        if "registration" in wanted and plate_row and plate_row.get("registered_at"):
            ts = _parse_ts(plate_row["registered_at"])
            if ts and rng["start_iso"] <= _utc_z(ts) < rng["end_iso"]:
                events.append({"type": "registration", "time": plate_row["registered_at"],
                               "title": "Visitor pass registered" if plate_row["is_visitor"] else "Plate registered",
                               "by": plate_row.get("registered_by"), "expires_at": plate_row.get("expires_at")})
        if "alert" in wanted:
            al = (sb.table("alerts").select("*").eq("plate_number", normalized)
                  .gte("created_at", rng["start_iso"]).lt("created_at", rng["end_iso"])
                  .order("created_at", desc=True).limit(50).execute()).data or []
            for r in al:
                s = _shape("alerts", r, now)
                events.append({"type": "alert", "time": s["created_at"],
                               "title": f"Repeat reads: {s['occurrence_count']} within {s['window_minutes']} min",
                               "review_state": s["review_state"], "by": s.get("acknowledged_by"), "id": s["id"]})
        if "override_nearby" in wanted:
            unreg = [(_parse_ts(r["timestamp"]), r) for r in logs if r.get("status") == "unregistered"]
            unreg = [(t, r) for t, r in unreg if t]
            if unreg:
                lo_t = min(t for t, _ in unreg)
                hi_t = max(t for t, _ in unreg) + timedelta(minutes=OVERRIDE_PROXIMITY_MIN)
                man = (sb.table("logs").select("*").eq("status", "manual")
                       .gte("timestamp", _utc_z(lo_t)).lte("timestamp", _utc_z(hi_t))
                       .order("timestamp", desc=True).limit(200).execute()).data or []
                for m in man:
                    mt = _parse_ts(m.get("timestamp"))
                    if not mt:
                        continue
                    prior = [t for t, _ in unreg if t <= mt and (mt - t) <= timedelta(minutes=OVERRIDE_PROXIMITY_MIN)]
                    if prior:
                        s = _shape("overrides", m, now)
                        events.append({"type": "override_nearby", "time": s["timestamp"],
                                       "title": f"Manual override by {s['performed_by'] or 'unknown'}",
                                       "reason": s["reason_label"], "note": s["note"], "id": s["id"],
                                       "caveat": f"Recorded within {OVERRIDE_PROXIMITY_MIN} min after an unregistered read of this plate. "
                                                 "Time proximity only - overrides are not linked to a vehicle in the database."})
        events.sort(key=lambda e: e.get("time") or "", reverse=(request.args.get("order") != "asc"))
        counts = Counter(e["type"] for e in events)
        return jsonify({
            "plate": normalized, "range": _public_range(rng), "registration": plate_row,
            "events": events, "counts": dict(counts), "detections_truncated": len(logs) >= 300,
            "registration_note": None if plate_row else
                "No active registration on file. The plate may never have been registered, or it was a visitor pass that expired and was removed.",
        })

    @safe
    def reliability_view():
        status = system_status_fn()
        return jsonify({
            "live": status, "checked_at": datetime.now(MY_TZ).isoformat(timespec="seconds"),
            "history_recorded": False,
            "note": "Only the live state is available. Uptime percentages are not calculated because no availability history is stored.",
        })

    @safe
    def export_view(kind):
        if kind not in KINDS:
            raise BadRequest("Unknown record type")
        a = request.args.to_dict()
        a["page_size"], a["page"] = str(PAGE_SIZE_MAX), "1"
        cfg = KINDS[kind]
        rng = resolve_range(a) if cfg.get("date_col") else None
        cols = EXPORT_COLUMNS[kind]
        out = io.StringIO()
        w = csv.writer(out)
        w.writerow(["NEXGUARD export", kind])
        w.writerow(["Generated at (MYT)", datetime.now(MY_TZ).strftime("%Y-%m-%d %H:%M:%S")])
        w.writerow(["Date range", f"{rng['from']} to {rng['to']} ({TZ_LABEL})" if rng else "Not date-filtered (current records)"])
        w.writerow([])
        w.writerow(cols)
        written, page = 0, 1
        while written < EXPORT_ROW_CAP:
            a["page"] = str(page)
            data = run_records(kind, a)
            for item in data["items"]:
                w.writerow([_csv_safe(item.get(c)) for c in cols])
                written += 1
            if page >= data["pages"] or not data["items"]:
                break
            page += 1
        name = f"nexguard_{kind}_{rng['from']}_{rng['to']}.csv" if rng else f"nexguard_{kind}.csv"
        return Response(out.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename={name}", "Cache-Control": "no-store"})

    @safe
    def lookups_view():
        """Head Guard: which guard searched which plate (guards' plate-history lookups)."""
        return jsonify(db.get_lookup_audit(_int(request.args, "limit", 100, 1, 500)))

    # ----------------------------------------------------------------- registration

    # Any signed-in guard may open the page and the trimmed endpoints; role_gate() narrows
    # what a normal guard actually receives. Head-only endpoints answer 403 to guards.
    page_guard = guard_page or head_guard_page
    api_guard = guard_api or head_guard_api
    bp.add_url_rule("/intelligence", "page", page_guard(page_view))
    api = lambda path, name, fn, **gate: bp.add_url_rule(path, name, api_guard(role_gate(fn, **gate)))
    api("/api/intel/meta", "meta", meta_view, strip_guards=True)
    api("/api/intel/summary", "summary", summary_view, today_only=True, strip_kpis=True)
    api("/api/intel/records/<kind>", "records", records_view, today_only=True, kinds=GUARD_RECORD_KINDS)
    api("/api/intel/traffic", "traffic", traffic_view, today_only=True)
    api("/api/intel/recognition", "recognition", recognition_view, head_only=True)
    api("/api/intel/guards", "guards", guards_view, head_only=True)
    api("/api/intel/vehicle", "vehicle", vehicle_view, lookup=True)
    api("/api/intel/reliability", "reliability", reliability_view, head_only=True)
    api("/api/intel/export/<kind>.csv", "export", export_view, head_only=True)
    api("/api/intel/lookups", "lookups", lookups_view, head_only=True)
    app.register_blueprint(bp)
    return bp
