"""
detector.py
YOLO (detect kotak plat) + EasyOCR (baca teks dalam plat).

Guna model pretrained "license_plate_detector.pt" (1 class: License_Plate) -
takyah train dari kosong, macam guna dlib pretrained dalam face_recognition.
"""

import re
import time

import cv2
import easyocr
from ultralytics import YOLO
from database import normalize_plate, fix_ambiguous_chars, find_closest_registered_plate

MODEL_PATH = "models/license_plate_detector.pt"
CONF_THRESHOLD = 0.3  # diturunkan sikit dari 0.5 - plat kosong (tak lekat kat kereta) confidence YOLO lebih rendah
DEBUG_YOLO = False     # True = print confidence setiap detection YOLO (untuk tuning)

# Fallback: kalau YOLO tak jumpa plat yang BOLEH DIBACA, EasyOCR scan seluruh frame dan cari
# teks berbentuk plat (gabung "AMM" + "1075" jadi satu plat). Tak bergantung pada kereta langsung -
# plat kosong / plat close-up / plat pelik pun boleh dibaca. Hidup by default.
ENABLE_OCR_FALLBACK = True
FALLBACK_MIN_OCR_CONF = 0.3   # confidence minimum untuk setiap serpihan teks
FALLBACK_MAX_SIDE = 1024      # px - kecilkan frame sebelum scan penuh (lebih laju)
FALLBACK_MIN_INTERVAL = 0.8   # saat - had berapa kerap scan penuh boleh jalan
FALLBACK_CACHE_TTL = 1.6      # saat - guna semula hasil scan terakhir sementara scan berikut ditunggu
FALLBACK_MAX_PLATES = 3
_fallback_cache = {"ts": 0.0, "dets": []}

_yolo_model = None
_ocr_reader = None


_PLAUSIBLE_RE = re.compile(r"^[A-Z0-9]{3,10}$")


def is_plausible_plate_text(text):
    """Teks yang munasabah sebagai nombor plat: 3-10 aksara, ada huruf DAN nombor."""
    t = normalize_plate(text or "")
    return bool(_PLAUSIBLE_RE.match(t)) and any(c.isalpha() for c in t) and any(c.isdigit() for c in t)


def load_models():
    """Panggil sekali je time app startup - load YOLO + EasyOCR ke memory."""
    global _yolo_model, _ocr_reader
    print("Loading plate detector (YOLO)...")
    _yolo_model = YOLO(MODEL_PATH)
    print("Loading OCR reader (EasyOCR)... (first run akan download model, ambil masa sekejap)")
    try:
        _ocr_reader = easyocr.Reader(["en"], gpu=True)
        try:
            import torch
            if torch.cuda.is_available():
                print("EasyOCR: guna GPU (CUDA).")
            else:
                print("EasyOCR: CUDA tak available, sebenarnya jalan atas CPU (lebih perlahan).")
        except Exception:
            print("EasyOCR: reader dimuatkan (tak dapat sahkan GPU/CPU).")
    except Exception as e:
        # No CUDA / torch not built with CUDA support - fall back to CPU so the
        # app still runs, just slower. Common on machines without an NVIDIA GPU.
        print(f"EasyOCR: GPU tak available ({e}), fallback ke CPU.")
        _ocr_reader = easyocr.Reader(["en"], gpu=False)
    print("Model siap dimuatkan.")


def detect_plates(frame, force_fallback=False):
    """
    Detect semua plat dalam satu frame.
    Return list of dict: {box: (x1,y1,x2,y2), confidence: float, text: str, crop: np.array}
    """
    if _yolo_model is None:
        raise RuntimeError("Model belum di-load. Panggil load_models() dulu.")

    results = _yolo_model(frame, verbose=False)[0]
    detections = []

    for box in results.boxes:
        conf = float(box.conf[0])
        if DEBUG_YOLO:
            print(f"[yolo] conf={conf:.2f}")
        if conf < CONF_THRESHOLD:
            continue

        x1, y1, x2, y2 = map(int, box.xyxy[0])
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(frame.shape[1], x2), min(frame.shape[0], y2)

        crop = frame[y1:y2, x1:x2]
        if crop.size == 0:
            continue

        text, ocr_conf = read_plate_text(crop)

        detections.append({
            "box": (x1, y1, x2, y2),
            "confidence": conf,
            "text": text,
            "ocr_confidence": ocr_conf,
            "crop": crop,
        })

    # Kalau ada plat YOLO yang teksnya munasabah, guna itu sahaja (buang kotak "?" yang mengelirukan)
    readable = [d for d in detections if is_plausible_plate_text(d["text"])]
    if readable:
        return readable

    # Tiada plat yang boleh dibaca -> scan OCR seluruh frame (tak bergantung pada YOLO / kereta)
    if ENABLE_OCR_FALLBACK:
        fallback = _fallback_full_frame_ocr(frame, force=force_fallback)
        if fallback:
            return fallback

    return detections


def _cluster_items(items):
    """Kumpulkan serpihan teks yang sebaris ("AMM" + "1075") atau bertingkat (plat 2 baris)."""
    n = len(items)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(n):
        for j in range(i + 1, n):
            a, b = items[i], items[j]
            ha, hb = a["y2"] - a["y1"], b["y2"] - b["y1"]
            if ha <= 0 or hb <= 0 or not (0.5 < ha / hb < 2.0):
                continue
            hmax = max(ha, hb)
            v_overlap = min(a["y2"], b["y2"]) - max(a["y1"], b["y1"])
            gap_x = max(a["x1"], b["x1"]) - min(a["x2"], b["x2"])
            same_line = v_overlap > 0.5 * min(ha, hb) and gap_x <= 1.5 * hmax

            h_overlap = min(a["x2"], b["x2"]) - max(a["x1"], b["x1"])
            gap_y = max(a["y1"], b["y1"]) - min(a["y2"], b["y2"])
            stacked = (h_overlap > 0.4 * min(a["x2"] - a["x1"], b["x2"] - b["x1"])
                       and gap_y <= 0.8 * hmax)

            if same_line or stacked:
                parent[find(j)] = find(i)

    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(items[i])
    return list(groups.values())


def _fallback_full_frame_ocr(frame, force=False):
    """
    Bila YOLO tak jumpa plat yang boleh dibaca: scan seluruh frame dengan EasyOCR, gabungkan
    serpihan teks jadi calon plat, dan pulangkan calon yang paling menyerupai nombor plat.
    """
    if _ocr_reader is None:
        return []

    now = time.time()
    since = now - _fallback_cache["ts"]
    if not force and since < FALLBACK_MIN_INTERVAL:
        # Terlalu awal untuk scan baru - guna semula hasil terakhir (kalau masih segar)
        if since <= FALLBACK_CACHE_TTL:
            return [dict(d) for d in _fallback_cache["dets"]]
        return []

    h, w = frame.shape[:2]
    scale = 1.0
    small = frame
    if max(h, w) > FALLBACK_MAX_SIDE:
        scale = FALLBACK_MAX_SIDE / max(h, w)
        small = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)

    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)

    results = []
    try:
        for img in (cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray), gray):
            results = _ocr_reader.readtext(img, allowlist=OCR_ALLOWLIST)
            if results:
                break
    except Exception as e:
        print(f"[fallback OCR] error: {e}")
        results = []

    items = []
    for pts, raw_text, ocr_conf in results:
        text = normalize_plate(raw_text)
        if not text or ocr_conf < FALLBACK_MIN_OCR_CONF:
            continue
        xs = [pt[0] / scale for pt in pts]
        ys = [pt[1] / scale for pt in pts]
        items.append({"t": text, "c": float(ocr_conf),
                      "x1": min(xs), "y1": min(ys), "x2": max(xs), "y2": max(ys)})

    candidates = []
    for group in _cluster_items(items):
        # Susun: baris atas -> bawah, dalam baris kiri -> kanan
        avg_h = sum(g["y2"] - g["y1"] for g in group) / len(group)
        group = sorted(group, key=lambda g: (g["y1"] + g["y2"]) / 2)
        rows, cur = [], [group[0]]
        for g in group[1:]:
            if abs((g["y1"] + g["y2"]) / 2 - (cur[-1]["y1"] + cur[-1]["y2"]) / 2) > 0.6 * avg_h:
                rows.append(cur)
                cur = [g]
            else:
                cur.append(g)
        rows.append(cur)
        ordered = [g for row in rows for g in sorted(row, key=lambda g: g["x1"])]

        text = fix_ambiguous_chars("".join(g["t"] for g in ordered))
        if not is_plausible_plate_text(text):
            continue

        total_len = sum(len(g["t"]) for g in ordered)
        conf = sum(g["c"] * len(g["t"]) for g in ordered) / total_len
        gx1, gy1 = min(g["x1"] for g in ordered), min(g["y1"] for g in ordered)
        gx2, gy2 = max(g["x2"] for g in ordered), max(g["y2"] for g in ordered)
        padx, pady = int((gx2 - gx1) * 0.06), int((gy2 - gy1) * 0.3)
        x1, y1 = max(0, int(gx1) - padx), max(0, int(gy1) - pady)
        x2, y2 = min(w, int(gx2) + padx), min(h, int(gy2) + pady)
        crop = frame[y1:y2, x1:x2]
        if crop.size == 0:
            continue

        looks_malaysian = bool(re.match(r"^[A-Z]{1,3}\d{1,4}[A-Z]?$", text))
        candidates.append((looks_malaysian, conf * (gx2 - gx1) * (gy2 - gy1), {
            "box": (x1, y1, x2, y2),
            "confidence": conf,
            "text": text,
            "ocr_confidence": conf,
            "crop": crop,
        }))

    candidates.sort(key=lambda c: (c[0], c[1]), reverse=True)
    detections = [c[2] for c in candidates[:FALLBACK_MAX_PLATES]]

    _fallback_cache["ts"] = time.time()
    _fallback_cache["dets"] = [dict(d) for d in detections]
    return detections


OCR_ALLOWLIST = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
MIN_CROP_HEIGHT = 100  # px - crop kecil di-upscale dulu sebelum OCR
FUZZY_MATCH_CONF_THRESHOLD = 0.85  # bawah ni, cuba fuzzy-match ke plat registered


def _ocr_attempts(plate_crop):
    """Variasi preprocessing - cuba satu per satu sampai ada teks."""
    # Border kecil supaya huruf di tepi crop YOLO tak terpotong
    padded = cv2.copyMakeBorder(plate_crop, 10, 10, 10, 10, cv2.BORDER_REPLICATE)
    gray = cv2.cvtColor(padded, cv2.COLOR_BGR2GRAY)

    h = gray.shape[0]
    if h < MIN_CROP_HEIGHT:
        scale = MIN_CROP_HEIGHT / h
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    yield clahe.apply(gray)          # 1) greyscale + CLAHE (asal)
    yield gray                        # 2) greyscale biasa
    yield cv2.bitwise_not(clahe.apply(gray))  # 3) terbalik (plat gelap / tulisan cerah)


def read_plate_text(plate_crop):
    """OCR pada gambar plat yang dah di-crop. Return (text, confidence)."""
    if _ocr_reader is None:
        raise RuntimeError("OCR reader belum di-load.")

    results = []
    for img in _ocr_attempts(plate_crop):
        results = _ocr_reader.readtext(img, allowlist=OCR_ALLOWLIST)
        if results:
            break
    if not results:
        return "", 0.0

    # Gabungkan semua text yang detect dalam crop tu (kadang plat 2 baris)
    combined_text = " ".join([r[1] for r in results])
    avg_conf = sum(r[2] for r in results) / len(results)

    text = normalize_plate(combined_text)
    text = fix_ambiguous_chars(text)

    # Kalau confidence rendah, cuba fuzzy-match terhadap plat yang dah
    # registered dalam Supabase - tolong tangkap silap OCR yang tak
    # settle dengan fix_ambiguous_chars je (contoh B/8, S/5)
    if avg_conf < FUZZY_MATCH_CONF_THRESHOLD:
        close_match = find_closest_registered_plate(text)
        if close_match:
            text = close_match

    return text, avg_conf
