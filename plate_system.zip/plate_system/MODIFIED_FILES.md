# Modified / added files (branch ui-redesign vs baseline f0ab6de)

Added: intelligence.py, templates/intelligence.html, static/nexguard.css, migrations_audit_trail.sql,
       NEXGUARD_REDESIGN_REPORT.md, MODIFIED_FILES.md, tests/{fake_supabase,harness,test_backend,test_pages,serve_for_js}.py
Modified: app.py (+imports, gate probe, status payload, blueprint registration, alert reviewer arg)
          database.py (acknowledge_alert optional reviewer)
          templates/_sidebar.html, login.html, index.html, register.html, team.html, gallery.html, analytics.html, residents.html
Untouched: detector.py, telegram_bot.py, all other migrations, .env, static/style.css, static images
