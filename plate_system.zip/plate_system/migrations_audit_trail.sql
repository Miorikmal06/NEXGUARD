-- NEXGUARD audit-trail migration (OPTIONAL, additive, idempotent, non-destructive).
-- Run in the Supabase SQL Editor. The app works without it; it only unlocks the reviewer
-- name/time on the Incidents & Audit view. To undo:  alter table alerts drop column acknowledged_by, drop column acknowledged_at;

alter table alerts add column if not exists acknowledged_by text;
alter table alerts add column if not exists acknowledged_at timestamptz;

-- Helps date-range analytics on large histories (safe to skip).
create index if not exists idx_logs_timestamp on logs (timestamp desc);
create index if not exists idx_logs_status_ts on logs (status, timestamp desc);
create index if not exists idx_plates_registered_at on plates (registered_at desc);
create index if not exists idx_login_logs_login_at on login_logs (login_at desc);
