LOGIN SLIDESHOW IMAGES
======================
The login page shows 5 auto-sliding images. Right now it uses the bundled illustrations (slide-1.svg ... slide-5.svg).

To use real AI-generated photos: save them in THIS folder as
    slide-1.jpg  slide-2.jpg  slide-3.jpg  slide-4.jpg  slide-5.jpg
(.jpeg / .webp / .png also work). A photo automatically replaces the SVG with the same number - no code change.
You can mix: e.g. replace only slide-1 and keep the rest.
Recommended: landscape 1920x1200 (or at least 1600x1000), under ~400 KB each (compress as .jpg/.webp).

Suggested AI prompts (match the caption on each slide)
------------------------------------------------------
1. Secure living, by design      - "Photorealistic architectural photo of a modern Malaysian high-rise condominium complex at golden hour, glass facades reflecting warm sunlight, lush tropical landscaping, clean podium, wide shot, professional real-estate photography, 16:10"
2. Peace of mind, every day      - "Resort-style condominium swimming pool deck in Malaysia, midday blue sky, sun loungers, palm trees, tall residential towers in the background, crisp and clean, professional real-estate photography, 16:10"
3. Every vehicle, on the record  - "Gated condominium entrance in Malaysia at dusk, boom barrier raised, modern guardhouse with warm lit windows, landscaped driveway, residential towers behind, cinematic, professional photography, 16:10"
4. Always watching over...       - "Modern condominium towers at night, blue hour, warm lit windows, subtle street lamps, moonlit sky, landscaped grounds, calm and secure atmosphere, professional architectural photography, 16:10"
5. A greener, safer community    - "Landscaped condominium garden courtyard in Malaysia, winding paved path, manicured hedges, flowers, tropical trees, soft morning light, residential tower softly visible in the haze, professional photography, 16:10"
Tip: add "no text, no logos, no people" to every prompt.
