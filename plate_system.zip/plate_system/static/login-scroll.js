/* NEXGUARD login - "Login as <name>" scroller.
   - One row per registered guard (no repeats). With 3+ guards the list loops; with 1-2 it simply stops at the ends.
   - The row on the centre line is bright; the rest fade with distance.
   - Auto-scrolls slowly until the first interaction; wheel / drag / arrow keys add inertia, then snap to a name.
   - Every row that passes the centre line plays a soft "detent" tick (Web Audio, no audio files); picking a name chimes.
   - Enter (or click the centred name) opens the password step; the form POSTs guard_id + password to /login. */
(function () {
  'use strict';
  var data = JSON.parse(document.getElementById('ls-data').textContent);
  var roster = data.roster || [], N = roster.length;

  var stage = document.getElementById('ls-stage'), list = document.getElementById('ls-list');
  var panel = document.getElementById('ls-panel'), form = document.getElementById('ls-form');
  var pw = document.getElementById('ls-password'), who = document.getElementById('ls-who');
  var gid = document.getElementById('ls-guard-id'), errEl = document.getElementById('ls-err');
  var userFld = document.getElementById('ls-user-fld'), userIn = document.getElementById('ls-username');
  var submit = document.getElementById('ls-submit'), back = document.getElementById('ls-back');
  var live = document.getElementById('ls-live');
  var soundBtn = document.getElementById('ls-sound'), soundLbl = document.getElementById('ls-sound-label');

  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var AUTO = 0.45, EASE = reduce ? 1 : 0.11;     // px per frame, lerp factor
  var LOOP = N >= 3;                              // 1-2 names: no wrap-around (it would look broken)

  /* ====================================================================
     SOUND - tiny synth, created lazily. Browsers only allow audio after a click / key press,
     so it wakes up on the first of those (the footer button shows the state).
     ==================================================================== */
  var Sound = (function () {
    var ctx = null, master = null, noiseBuf = null, on = true, lastTick = 0;
    try { on = localStorage.getItem('nx_login_sound') !== 'off'; } catch (e) {}

    function ensure() {
      if (!on) return null;
      if (!ctx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
        master = ctx.createGain(); master.gain.value = 0.55;
        var comp = ctx.createDynamicsCompressor();
        master.connect(comp); comp.connect(ctx.destination);
        noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.05), ctx.sampleRate);
        var d = noiseBuf.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      }
      if (ctx.state === 'suspended') ctx.resume();
      return ctx.state === 'running' || ctx.state === 'suspended' ? ctx : null;
    }
    function running() { return !!ctx && ctx.state === 'running'; }
    function live() { return (on && running()) ? ctx : null; }   // never creates a context outside a user gesture

    // soft mechanical detent: a short filtered noise "tk" + a tiny wooden "tok" body
    function tick(speed) {
      var c = live(); if (!c) return;
      var now = c.currentTime;
      if (now - lastTick < 0.03) return; lastTick = now;
      var pitch = 1 + Math.min(0.55, speed / 260) + (Math.random() - 0.5) * 0.06;

      var n = c.createBufferSource(); n.buffer = noiseBuf;
      var bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 3100 * pitch; bp.Q.value = 1.1;
      var ng = c.createGain();
      ng.gain.setValueAtTime(0.0001, now);
      ng.gain.exponentialRampToValueAtTime(0.38, now + 0.002);
      ng.gain.exponentialRampToValueAtTime(0.0001, now + 0.028);
      n.connect(bp); bp.connect(ng); ng.connect(master); n.start(now); n.stop(now + 0.05);

      var o = c.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(820 * pitch, now); o.frequency.exponentialRampToValueAtTime(430 * pitch, now + 0.05);
      var og = c.createGain();
      og.gain.setValueAtTime(0.0001, now);
      og.gain.exponentialRampToValueAtTime(0.16, now + 0.003);
      og.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);
      o.connect(og); og.connect(master); o.start(now); o.stop(now + 0.09);
    }
    // two soft bell notes (E5 -> B5) when a name is chosen
    function chime() {
      var c = live(); if (!c) return;
      [[659.25, 0], [987.77, 0.075]].forEach(function (nt) {
        var t = c.currentTime + nt[1];
        var o = c.createOscillator(); o.type = 'sine'; o.frequency.value = nt[0];
        var o2 = c.createOscillator(); o2.type = 'triangle'; o2.frequency.value = nt[0] * 2;
        var g = c.createGain(), g2 = c.createGain();
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.2, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
        g2.gain.setValueAtTime(0.0001, t); g2.gain.exponentialRampToValueAtTime(0.04, t + 0.01); g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
        o.connect(g); o2.connect(g2); g.connect(master); g2.connect(master);
        o.start(t); o.stop(t + 0.75); o2.start(t); o2.stop(t + 0.4);
      });
    }
    // low soft click for "choose another"
    function back() {
      var c = live(); if (!c) return;
      var t = c.currentTime, o = c.createOscillator(), g = c.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(380, t); o.frequency.exponentialRampToValueAtTime(240, t + 0.08);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.16, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
      o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.13);
    }
    function setOn(v) {
      on = v; try { localStorage.setItem('nx_login_sound', v ? 'on' : 'off'); } catch (e) {}
      if (v) ensure();
      paint();
    }
    function paint() {
      soundBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
      soundLbl.textContent = !on ? 'Sound off' : (running() ? 'Sound on' : 'Sound on · click anywhere');
    }
    return { ensure: ensure, tick: tick, chime: chime, back: back, toggle: function () { setOn(!on); }, paint: paint, isOn: function () { return on; }, running: running };
  })();

  // wake the audio engine on the first real gesture (wheel alone doesn't count for browsers)
  ['pointerdown', 'keydown', 'touchend'].forEach(function (ev) {
    window.addEventListener(ev, function once() { Sound.ensure(); setTimeout(Sound.paint, 60); }, { once: false, passive: true });
  });
  soundBtn.addEventListener('click', function (e) { e.stopPropagation(); Sound.toggle(); });
  soundBtn.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
  Sound.paint();

  /* ---------- no guards on the roster: classic username field instead ---------- */
  if (!N) {
    list.innerHTML = '<li class="ls-empty">no guards registered</li>';
    userFld.hidden = false; who.textContent = 'you';
    panel.classList.add('open'); back.hidden = true;
    form.addEventListener('submit', function (e) {
      if (!userIn.value.trim() || !pw.value) { e.preventDefault(); (userIn.value.trim() ? pw : userIn).focus(); }
    });
    return;
  }

  var LH = 80, items = [], pos = [], total = 1;
  var offset = 0, target = 0, interacted = false, picked = false, snapT = null, currentJ = -1, currentI = -1, firstPaint = true;

  /* ---------- build: exactly one row per guard ---------- */
  function build() {
    list.textContent = '';
    var probe = document.createElement('li'); probe.className = 'ls-item'; probe.textContent = 'Xg';
    list.appendChild(probe); LH = probe.getBoundingClientRect().height || 80; list.removeChild(probe);
    items = []; pos = [];
    for (var j = 0; j < N; j++) {
      var li = document.createElement('li');
      li.className = 'ls-item'; li.setAttribute('role', 'option'); li.setAttribute('aria-selected', 'false');
      li.textContent = roster[j].full_name; li.title = roster[j].full_name; li.dataset.j = j;
      list.appendChild(li); items.push(li); pos.push(0);
    }
    // long names (e.g. a full "bin/binti" name) shrink to fit the column instead of being cut off with "…"
    var vw = list.clientWidth;
    items.forEach(function (el) {
      var w = el.scrollWidth, f = (vw > 0 && w > vw) ? Math.max(0.5, vw / w) : 1;
      el._fit = f; el.style.maxWidth = (100 / f) + '%';
    });
    total = N * LH;
    offset = target = snap(target);
  }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function limit(v) { return LOOP ? v : clamp(v, 0, (N - 1) * LH); }   // 1-2 names can't scroll past the ends
  function snap(v) { return limit(Math.round(v / LH) * LH); }

  /* ---------- per-frame render ---------- */
  function render() {
    var half = total / 2, cull = stage.clientHeight / 2 + LH, best = 1e9, bi = 0, i, p, d;
    for (i = 0; i < N; i++) {
      p = i * LH - offset;
      if (LOOP) p = ((p + half) % total + total) % total - half;      // wrap into [-total/2, total/2)
      pos[i] = p; d = Math.abs(p);
      if (d < best) { best = d; bi = i; }
    }
    for (i = 0; i < N; i++) {
      var el = items[i]; d = Math.abs(pos[i]);
      var op = Math.max(0.08, 1 - d / (LH * 2.5));
      if (LOOP) op *= clamp((half - d) / (LH * 0.6), 0, 1);           // fade out before the wrap point so a row never "pops"
      var sc = (0.96 + 0.04 * Math.max(0, 1 - d / (LH * 1.5))) * (el._fit || 1);
      if (picked && i !== bi) op = 0;                                  // only the chosen name stays
      el.style.opacity = op.toFixed(3);
      el.style.transform = 'translate3d(0,' + pos[i].toFixed(2) + 'px,0) scale(' + sc.toFixed(3) + ')';
      el.style.visibility = (d > cull || op < 0.005) ? 'hidden' : 'visible';
    }
    if (bi !== currentI) {
      if (currentI > -1) items[currentI].setAttribute('aria-selected', 'false');
      var had = currentI > -1;
      currentI = bi; items[bi].setAttribute('aria-selected', 'true'); currentJ = +items[bi].dataset.j;
      if (had && interacted && !picked) Sound.tick(Math.abs(target - offset) / 3);   // a row just crossed the centre line
    }
  }
  function frame() {
    if (!interacted && !picked && !reduce && LOOP) target += AUTO;
    target = limit(target);
    offset += (target - offset) * EASE;
    render();
    requestAnimationFrame(frame);
  }

  /* ---------- input ---------- */
  function touched() { interacted = true; clearTimeout(snapT); snapT = setTimeout(function () { target = snap(target); }, 140); }

  document.addEventListener('wheel', function (e) {
    if (picked) return;
    e.preventDefault(); touched();
    target = limit(target + clamp(e.deltaY, -120, 120) * 0.9);
  }, { passive: false });

  var drag = null;
  stage.addEventListener('pointerdown', function (e) {
    if (picked || e.target.closest('.ls-panel')) return;
    drag = { y: e.clientY, t: target, moved: 0, el: e.target.closest('.ls-item') };
    stage.setPointerCapture(e.pointerId); stage.classList.add('drag');
  });
  stage.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var dy = e.clientY - drag.y; drag.moved = Math.max(drag.moved, Math.abs(dy));
    if (drag.moved > 6) { interacted = true; target = limit(drag.t - dy); }
  });
  function endDrag() {
    if (!drag) return;
    var d = drag; drag = null; stage.classList.remove('drag');
    if (d.moved <= 6) {                                     // tap/click
      var idx = d.el ? items.indexOf(d.el) : -1;
      if (idx > -1) {
        interacted = true;
        if (Math.abs(pos[idx]) < LH * 0.5) selectCurrent();             // already centred -> choose
        else target = limit(offset + pos[idx]);                          // bring to centre first
      }
    } else touched();
  }
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);

  document.addEventListener('keydown', function (e) {
    var inPanel = panel.contains(document.activeElement);
    if (e.key === 'Escape' && picked) { e.preventDefault(); unpick(); return; }
    if (picked || inPanel || document.activeElement === soundBtn) return;
    if (e.key === 'ArrowDown' || e.key === 'PageDown') { e.preventDefault(); interacted = true; target = limit(snap(target) + LH); }
    else if (e.key === 'ArrowUp' || e.key === 'PageUp') { e.preventDefault(); interacted = true; target = limit(snap(target) - LH); }
    else if (e.key === 'Enter') { e.preventDefault(); selectCurrent(); }
  });

  /* ---------- choose a name -> password step ---------- */
  function selectCurrent() {
    var g = roster[currentJ]; if (!g) return;
    interacted = true; picked = true; clearTimeout(snapT);
    target = limit(offset + pos[currentI]);                  // centre it exactly
    stage.classList.add('picked');
    gid.value = g.id; who.textContent = g.full_name;
    live.textContent = 'Selected ' + g.full_name + '. Enter your password.';
    panel.classList.add('open');
    Sound.chime();
    setTimeout(function () { pw.focus(); }, 160);
  }
  function unpick() {
    picked = false; stage.classList.remove('picked'); panel.classList.remove('open');
    errEl.textContent = ''; pw.value = ''; stage.focus({ preventScroll: true });
    Sound.back();
  }
  back.addEventListener('click', unpick);

  form.addEventListener('submit', function (e) {
    if (!pw.value) { e.preventDefault(); pw.focus(); return; }
    submit.disabled = true; submit.textContent = 'Signing in…';
  });
  window.addEventListener('pageshow', function () { submit.disabled = false; submit.textContent = 'Enter'; });

  /* ---------- start ---------- */
  build();
  window.addEventListener('resize', function () { var j = currentJ; build(); if (j > -1) offset = target = limit(j * LH); });

  if (data.selectedId) {                                     // wrong password -> reopen that guard's password step
    for (var j = 0; j < N; j++) if (roster[j].id === data.selectedId) { offset = target = limit(j * LH); break; }
    render(); requestAnimationFrame(function () { render(); selectCurrent(); });
  }
  frame();
  stage.focus({ preventScroll: true });
})();
