Bundled locally so the login page looks the same offline (guardhouse PC).
Outfit and Instrument Serif - SIL Open Font License 1.1 (via fontsource.org).
