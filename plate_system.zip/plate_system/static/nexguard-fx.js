/* NEXGUARD FX - background layers, particle network, cursor glow, login scanner loop.
   Pure visual: tidak sentuh logic detection / API. Buang <script> ni untuk revert. */
(function () {
  'use strict';
  var KEY = 'nxfx';
  var root = document.documentElement;
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function getMode() { try { return localStorage.getItem(KEY) || 'full'; } catch (e) { return 'full'; } }
  function setMode(m, persist) { root.setAttribute('data-fx', m); if (persist) { try { localStorage.setItem(KEY, m); } catch (e) {} } }
  setMode(reduce ? 'lite' : getMode(), false);

  var SHIELD = '<svg class="nx-mark-bg" viewBox="0 0 32 32" aria-hidden="true"><path d="M16 2.5 4.5 7v8.2c0 7.1 4.7 12.4 11.5 14.3 6.8-1.9 11.5-7.2 11.5-14.3V7z" fill="none" stroke="currentColor" stroke-width=".6" stroke-linejoin="round"/><path d="M10.5 21V11.5l11 9.5V11" fill="none" stroke="currentColor" stroke-width=".7" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function build() {
    if (document.querySelector('.nx-bg')) return;
    var bg = document.createElement('div');
    bg.className = 'nx-bg';
    bg.setAttribute('aria-hidden', 'true');
    bg.innerHTML =
      '<div class="nx-blob a"></div><div class="nx-blob b"></div><div class="nx-blob c"></div><div class="nx-blob d"></div>' +
      '<div class="nx-grid"></div>' + SHIELD +
      '<canvas class="nx-net"></canvas><div class="nx-beam"></div><div class="nx-spot"></div>' +
      '<div class="nx-vig"></div><div class="nx-grain"></div>' +
      '<i class="nx-corner tl"></i><i class="nx-corner tr"></i><i class="nx-corner bl"></i><i class="nx-corner br"></i>';
    document.body.insertBefore(bg, document.body.firstChild);
    return bg;
  }

  /* ---------- particle network (nodes + lines, reacts to cursor) ---------- */
  var cvs, ctx, nodes = [], W = 0, H = 0, dpr = 1, mouse = { x: -999, y: -999 }, running = false, last = 0, slow = 0, frames = 0;

  function netColor() {
    var v = getComputedStyle(root).getPropertyValue('--fx-net').trim();
    return v || '56,189,248';
  }
  function sizeNet() {
    if (!cvs) return;
    dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    cvs.width = W * dpr; cvs.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.max(24, Math.min(54, Math.round(W * H / 30000)));
    nodes = [];
    for (var i = 0; i < n; i++) nodes.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .28, vy: (Math.random() - .5) * .28, r: Math.random() * 1.3 + .7 });
  }
  function tick(t) {
    if (!running) return;
    requestAnimationFrame(tick);
    if (t - last < 33) return;                       /* ~30fps cap: jimat CPU/GPU untuk YOLO + OCR */
    var dt = t - last; last = t;
    frames++; if (frames > 20 && dt > 60) slow++; else if (slow > 0 && frames % 30 === 0) slow--;
    if (slow > 40) { setMode('lite', false); stopNet(); return; }   /* laptop lambat -> auto lite (tak disimpan) */
    ctx.clearRect(0, 0, W, H);
    var c = netColor(), i, j, a, b, dx, dy, d;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i]; a.x += a.vx; a.y += a.vy;
      if (a.x < -20) a.x = W + 20; else if (a.x > W + 20) a.x = -20;
      if (a.y < -20) a.y = H + 20; else if (a.y > H + 20) a.y = -20;
      for (j = i + 1; j < nodes.length; j++) {
        b = nodes[j]; dx = a.x - b.x; dy = a.y - b.y; d = dx * dx + dy * dy;
        if (d < 21000) { ctx.strokeStyle = 'rgba(' + c + ',' + (.20 * (1 - d / 21000)).toFixed(3) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      }
      dx = a.x - mouse.x; dy = a.y - mouse.y; d = dx * dx + dy * dy;
      if (d < 32000) { ctx.strokeStyle = 'rgba(' + c + ',' + (.55 * (1 - d / 32000)).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke(); }
      ctx.fillStyle = 'rgba(' + c + ',.65)'; ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, 6.2832); ctx.fill();
    }
  }
  function startNet() { if (running || !ctx || root.getAttribute('data-fx') === 'lite') return; running = true; last = 0; frames = 0; requestAnimationFrame(tick); }
  function stopNet() { running = false; if (ctx) ctx.clearRect(0, 0, W, H); }

  /* ---------- cursor spotlight + per-card glow ---------- */
  var spot, px = 0, py = 0, pend = false, hoverEl = null;
  var CARD = '.panel,.kpi-card,.nx-kpi,.gallery-card,.reg-field-group';
  function onMove(e) {
    mouse.x = e.clientX; mouse.y = e.clientY; px = e.clientX; py = e.clientY;
    if (!pend) { pend = true; requestAnimationFrame(frame); }
    var el = e.target && e.target.closest ? e.target.closest(CARD) : null;
    if (hoverEl && hoverEl !== el) { hoverEl.style.setProperty('--mx', '-400px'); hoverEl.style.setProperty('--my', '-400px'); }
    hoverEl = el;
    if (el) { var r = el.getBoundingClientRect(); el.style.setProperty('--mx', (e.clientX - r.left) + 'px'); el.style.setProperty('--my', (e.clientY - r.top) + 'px'); }
  }
  function frame() {
    pend = false;
    if (spot) { spot.classList.add('on'); spot.style.transform = 'translate3d(' + px + 'px,' + py + 'px,0)'; }
  }

  /* ---------- sidebar: effects toggle ---------- */
  function addToggle() {
    var box = document.querySelector('.nx-user-actions');
    if (!box || box.querySelector('.nx-fx-btn')) return;
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'nx-icon-btn nx-fx-btn';
    b.setAttribute('aria-label', 'Toggle background effects');
    b.innerHTML = '<svg class="icon" viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 3v4M17 5h4M5 17v4M3 19h4"/></svg>';
    function paint() { var lite = root.getAttribute('data-fx') === 'lite'; b.classList.toggle('lite', lite); b.title = lite ? 'Effects: Lite (klik untuk Full)' : 'Effects: Full (klik untuk Lite)'; }
    b.addEventListener('click', function () {
      var lite = root.getAttribute('data-fx') === 'lite';
      setMode(lite ? 'full' : 'lite', true);
      if (lite) startNet(); else stopNet();
      paint();
    });
    paint(); box.insertBefore(b, box.firstChild);
  }

  /* ---------- login: plate scanner demo loop (simulasi, bukan data sebenar) ---------- */
  function loginScene() {
    var stage = document.getElementById('lv-stage');
    if (!stage) return;
    var plate = document.getElementById('lv-plate');
    var samples = [['WQA 7788', 'ok'], ['BNK 2026', 'ok'], ['PKD 5150', 'bad'], ['VDM 3141', 'ok'], ['JHR 9021', 'bad']];
    var i = 0, timers = [];
    function at(ms, fn) { timers.push(setTimeout(fn, ms)); }
    function cycle() {
      var s = samples[i % samples.length]; i++;
      stage.setAttribute('data-s', 'idle'); plate.textContent = s[0];
      at(500,  function () { stage.setAttribute('data-s', 'scan'); });
      at(2000, function () { stage.setAttribute('data-s', 'lock'); });
      at(2700, function () { stage.setAttribute('data-s', s[1]); });
      at(5600, cycle);
    }
    cycle();
    var clk = document.getElementById('lv-clock');
    function t() { var d = new Date(); clk.textContent = d.toLocaleTimeString('en-GB', { hour12: false }); }
    if (clk) { t(); setInterval(t, 1000); }
  }

  function init() {
    var bg = build();
    cvs = document.querySelector('.nx-net');
    if (cvs && cvs.getContext) {
      ctx = cvs.getContext('2d'); sizeNet();
      var rt; window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(sizeNet, 200); });
      document.addEventListener('visibilitychange', function () { if (document.hidden) stopNet(); else startNet(); });
      startNet();
    }
    spot = document.querySelector('.nx-spot');
    window.addEventListener('pointermove', onMove, { passive: true });
    document.addEventListener('mouseleave', function () { mouse.x = mouse.y = -999; if (spot) spot.classList.remove('on'); });
    addToggle(); loginScene();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
