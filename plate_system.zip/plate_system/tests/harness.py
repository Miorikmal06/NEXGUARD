"""Test harness: loads the real app.py with camera/YOLO/Telegram/Supabase stubbed out and
seeded in-memory data. Nothing here touches the network, the camera, the Pi or real secrets."""
import os, sys, types, random
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
os.environ.update(SUPABASE_URL="http://fake.local", SUPABASE_SERVICE_KEY="x", FLASK_SECRET_KEY="test")

from fake_supabase import FakeClient
CLIENT = FakeClient()

sup = types.ModuleType("supabase"); sup.create_client = lambda *a, **k: CLIENT; sys.modules["supabase"] = sup
dot = types.ModuleType("dotenv"); dot.load_dotenv = lambda *a, **k: None; sys.modules["dotenv"] = dot  # never read the real .env
sys.modules["cv2"] = MagicMock()
det = types.ModuleType("detector")
det.load_models = lambda: None; det.detect_plates = lambda *a, **k: []; det.is_plausible_plate_text = lambda t: True
sys.modules["detector"] = det
tg = types.ModuleType("telegram_bot"); tg.notify_entry = lambda *a, **k: None; tg.start = lambda: None; sys.modules["telegram_bot"] = tg

from werkzeug.security import generate_password_hash

NOW = datetime.now(timezone.utc)
def iso(dt): return dt.isoformat()

def seed(n_logs=240):
    random.seed(7)
    S = CLIENT.store
    S["guards"] = [
        dict(id=1, username="head", password_hash=generate_password_hash("pw"), full_name="Aminah Head", role="head_guard", is_active=True),
        dict(id=2, username="guard1", password_hash=generate_password_hash("pw"), full_name="Faiz Guard", role="guard", is_active=True),
        dict(id=3, username="guard2", password_hash=generate_password_hash("pw"), full_name="Lina Guard", role="guard", is_active=True),
    ]
    S["plates"] = [
        dict(id=1, plate_number="ABC1234", owner_name="Resident One", house_no="12A", car_type="Sedan", car_color="White",
             registered_by="Faiz Guard", registered_at=iso(NOW - timedelta(days=3)), is_visitor=False, expires_at=None, created_via="dashboard", photo_path="captures/registered/a.jpg"),
        dict(id=2, plate_number="VIS0001", owner_name="Guest A", house_no="12A", registered_by="Lina Guard",
             registered_at=iso(NOW - timedelta(hours=2)), is_visitor=True, expires_at=iso(NOW + timedelta(hours=10)), created_via="telegram"),
        dict(id=3, plate_number="VIS0002", owner_name="Guest B", house_no="7", registered_by="Faiz Guard",
             registered_at=iso(NOW - timedelta(days=1)), is_visitor=True, expires_at=iso(NOW + timedelta(days=3))),
        dict(id=4, plate_number="VIS0003", owner_name="Guest C", house_no="9", registered_by="Faiz Guard",
             registered_at=iso(NOW - timedelta(days=1)), is_visitor=True, expires_at=iso(NOW - timedelta(minutes=5))),
        dict(id=5, plate_number="WXY9999", owner_name="Old Resident", house_no="3", registered_by="Lina Guard",
             registered_at=iso(NOW - timedelta(days=40)), is_visitor=False, expires_at=None),
    ]
    logs, i = [], 1
    for _ in range(n_logs):
        ts = NOW - timedelta(minutes=random.randint(1, 60 * 24 * 9))
        st = random.choices(["registered", "unregistered", "manual"], [60, 30, 10])[0]
        if st == "manual":
            logs.append(dict(id=i, plate_number="MANUAL", status="manual", timestamp=iso(ts), performed_by=random.choice(["Faiz Guard", "Lina Guard"]),
                             reason_code=random.choice(["delivery", "emergency", "other"]), note="note <b>x</b>" if random.random() < .3 else None, confidence=None, snapshot_path=None))
        else:
            logs.append(dict(id=i, plate_number=random.choice(["ABC1234", "ZZZ1111", "XYZ777", "ABC1234"]) if st == "registered" else random.choice(["ZZZ1111", "XYZ777", "=CMD1"]),
                             status=st, timestamp=iso(ts), performed_by=None, reason_code=None, note=None,
                             confidence=round(random.uniform(.3, .98), 3), snapshot_path=f"captures/logs/s{i}.jpg"))
        i += 1
    S["logs"] = logs
    S["login_logs"] = [
        dict(id=1, guard_id=2, guard_name="Faiz Guard", username="guard1", login_at=iso(NOW - timedelta(days=2, hours=9)), logout_at=iso(NOW - timedelta(days=2, hours=1))),
        dict(id=2, guard_id=3, guard_name="Lina Guard", username="guard2", login_at=iso(NOW - timedelta(days=1, hours=5)), logout_at=None),
        dict(id=3, guard_id=2, guard_name="Faiz Guard", username="guard1", login_at=iso(NOW - timedelta(minutes=30)), logout_at=None),
        dict(id=4, guard_id=2, guard_name="Faiz Guard", username="guard1", login_at=iso(NOW - timedelta(days=4)), logout_at=iso(NOW - timedelta(days=4) + timedelta(minutes=7))),
    ]
    S["alerts"] = [
        dict(id=1, plate_number="ZZZ1111", alert_type="frequent_visit", occurrence_count=3, window_minutes=60, created_at=iso(NOW - timedelta(hours=3)), acknowledged=False),
        dict(id=2, plate_number="XYZ777", alert_type="frequent_visit", occurrence_count=4, window_minutes=60, created_at=iso(NOW - timedelta(days=2)), acknowledged=True),
    ]

def make_app():
    import app as appmod
    appmod.app.config["TESTING"] = True
    appmod.camera_is_online = lambda: False  # no camera in the test environment
    return appmod

def login(client, user="head"):
    return client.post("/login", data={"username": user, "password": "pw"})
