import sys
from harness import *
seed(); A = make_app()
pages = ["/", "/register", "/gallery", "/team", "/residents", "/intelligence", "/login"]
for role, user in (("head_guard", "head"), ("guard", "guard1")):
    c = A.app.test_client(); login(c, user)
    print(role.ljust(11), " ".join(f"{p}:{c.get(p).status_code}" for p in pages))
c = A.app.test_client()
print("anonymous  ", " ".join(f"{p}:{c.get(p).status_code}" for p in pages))
g = A.app.test_client(); login(g, "guard1"); h = A.app.test_client(); login(h, "head")
gh, hh = g.get("/").get_data(as_text=True), h.get("/").get_data(as_text=True)
print("guard sees intelligence link:", 'href="/intelligence"' in gh, "| team link:", 'href="/team"' in gh)
print("head  sees intelligence link:", 'href="/intelligence"' in hh, "| team link:", 'href="/team"' in hh)
print("secret-looking strings in rendered HTML:", any(k in (gh + hh) for k in ("SUPABASE_SERVICE", "eyJ", "TELEGRAM_BOT_TOKEN")))
