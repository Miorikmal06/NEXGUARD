"""Plate removal audit: who deleted which plate. No network, camera or Pi needed."""
from harness import *

seed()
A = make_app()
fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""))
    if not cond: fails.append(name)

S = CLIENT.store
S["plate_audit"] = []
anon = A.app.test_client()
g = A.app.test_client(); login(g, "guard1")        # Faiz Guard
h = A.app.test_client(); login(h, "head")          # Aminah Head

check("anon delete -> 401", anon.delete("/api/plates/1").status_code == 401)
check("anon audit list -> 401", anon.get("/api/admin/plate-audit").status_code == 401)
check("guard cannot read audit list -> 403", g.get("/api/admin/plate-audit").status_code == 403)

# guard deletes a resident plate
r = g.delete("/api/plates/1")
check("guard delete ok", r.status_code == 200 and r.get_json()["plate_number"] == "ABC1234", r.get_json())
check("plate really removed", not any(p["id"] == 1 for p in S["plates"]))
a = S["plate_audit"]
check("one audit row written", len(a) == 1, a)
if a:
    check("audit has plate number", a[0]["plate_number"] == "ABC1234")
    check("audit has who (guard name)", a[0]["performed_by"] == "Faiz Guard", a[0])
    check("audit has guard id", a[0]["performed_by_id"] == 2)
    check("audit has owner + action", a[0]["owner_name"] == "Resident One" and a[0]["action"] == "deleted")
    check("audit has timestamp", bool(a[0]["created_at"]))

# unknown plate
r = g.delete("/api/plates/9999")
check("missing plate -> 404, no audit row", r.status_code == 404 and len(S["plate_audit"]) == 1)

# second guard
r = h.delete("/api/plates/5")
check("head guard delete recorded under head's name", r.status_code == 200 and S["plate_audit"][-1]["performed_by"] == "Aminah Head")

# head guard can read the list, newest first
r = h.get("/api/admin/plate-audit")
d = r.get_json()
check("head guard reads audit", r.status_code == 200 and len(d) == 2 and d[0]["plate_number"] == "WXY9999", d)

# fail closed: audit insert fails -> plate must NOT be deleted
before = len(S["plates"])
orig = CLIENT.table
def broken_table(name):
    if name == "plate_audit": raise RuntimeError("relation plate_audit does not exist")
    return orig(name)
CLIENT.table = broken_table
r = g.delete("/api/plates/2")
CLIENT.table = orig
check("audit table missing -> 500 and plate kept", r.status_code == 500 and len(S["plates"]) == before and "audit" in r.get_json()["error"].lower(), r.get_json())

# expiry sweep records 'system'
import database as db
exp = db.get_expired_visitor_plates()
for row in exp:
    db.delete_plate(row["id"], performed_by="system", action="expired", strict=False)
check("sweep delete audited as system/expired", S["plate_audit"][-1]["performed_by"] == "system" and S["plate_audit"][-1]["action"] == "expired", S["plate_audit"][-1:])

# non-strict: audit broken but cleanup still happens
CLIENT.table = broken_table
left = db.get_plate_by_id(3)
res = db.delete_plate(3, performed_by="system", action="expired", strict=False)
CLIENT.table = orig
check("non-strict delete still removes plate when audit fails", res is not None and db.get_plate_by_id(3) is None)

# page renders with the new panel
page = h.get("/team")
check("team page has audit panel", page.status_code == 200 and "Plate removal audit" in page.get_data(as_text=True))

print("\nFAILED: %s" % fails if fails else "\nALL PASSED")
raise SystemExit(1 if fails else 0)
