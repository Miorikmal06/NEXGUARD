import json, sys
from harness import *
seed()
A = make_app(); c = A.app.test_client()
fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""))
    if not cond: fails.append(name)
J = lambda r: r.get_json()

# ---- auth / permissions
check("anon /api/intel/summary -> 401", c.get("/api/intel/summary").status_code == 401)
check("anon /intelligence -> redirect to login", c.get("/intelligence").status_code == 302)
g = A.app.test_client(); login(g, "guard1")
# Guards now get a trimmed, today-only, read-only Security Intelligence (details: test_security_rules.py).
# Everything outside that scope must still answer 403 to a guard.
for p in ["/api/intel/summary", "/api/intel/records/overrides", "/api/intel/traffic",
          "/api/intel/vehicle?plate=ABC1234", "/api/intel/export/overrides.csv",
          "/api/intel/guards", "/api/intel/recognition", "/api/intel/reliability", "/api/intel/lookups"]:
    check(f"guard role blocked (403) {p}", g.get(p).status_code == 403)
check("guard role can open the trimmed /intelligence page", g.get("/intelligence").status_code == 200)

login(c, "head")
CLIENT.store["login_logs"] = [r for r in CLIENT.store["login_logs"] if r["id"] <= 4]  # drop sessions created by the test logins themselves
# ---- existing contracts untouched
st = J(c.get("/api/system/status"))
check("system/status keeps old keys", all(k in st for k in ("camera_online", "gate_integration", "scan_mode")), st)
check("system/status adds gate_reachable", "gate_reachable" in st)
check("/api/stats/today still works", c.get("/api/stats/today").status_code == 200)
check("/api/kpi/registered still works", c.get("/api/kpi/registered").status_code == 200)
check("/api/alerts still works", c.get("/api/alerts").status_code == 200)

# ---- summary counts equal ground truth
rng = "range=30d"
s = J(c.get(f"/api/intel/summary?{rng}"))["kpis"]
logs = CLIENT.store["logs"]
truth = lambda st: sum(1 for l in logs if l["status"] == st)
check("authorized count matches data", s["authorized"] == truth("registered"), (s["authorized"], truth("registered")))
check("unregistered count matches data", s["unregistered"] == truth("unregistered"))
check("overrides count matches data", s["overrides"] == truth("manual"))
check("detections = authorized + unregistered", s["detections"] == s["authorized"] + s["unregistered"])
check("registered_plates == 5", s["registered_plates"] == 5)
check("visitor active/expiring/expired", (s["visitors_active"], s["visitors_expiring"], s["visitors_expired_unswept"]) == (2, 1, 1), s)
check("sessions in 30d == 4, no-logout == 2", (s["sessions"], s["sessions_no_logout"]) == (4, 2), s)
check("alerts 2 / open 1", (s["alerts"], s["alerts_open"]) == (2, 1))

# ---- records: pagination, sort, search, filters
r = J(c.get(f"/api/intel/records/overrides?{rng}&page_size=5&page=2"))
check("overrides pagination total", r["total"] == truth("manual") and len(r["items"]) == min(5, max(0, r["total"] - 5)))
check("overrides items carry reason label", all(i["reason_label"] for i in r["items"]))
r = J(c.get(f"/api/intel/records/overrides?{rng}&reason=emergency&page_size=100"))
check("reason filter exact", all(i["reason_code"] == "emergency" for i in r["items"]) and r["total"] > 0)
r = J(c.get(f"/api/intel/records/overrides?{rng}&guard=Lina%20Guard&page_size=100"))
check("guard filter exact", all(i["performed_by"] == "Lina Guard" for i in r["items"]))
r = J(c.get(f"/api/intel/records/detections?{rng}&q=zzz&page_size=100"))
check("plate search (ilike) works", r["total"] > 0 and all("ZZZ" in i["plate_number"] for i in r["items"]))
r = J(c.get(f"/api/intel/records/detections?{rng}&conf_min=0.9&conf_max=1.1&page_size=100"))
check("confidence bin drilldown", all(0.9 <= i["confidence"] for i in r["items"]))
r = J(c.get(f"/api/intel/records/detections?{rng}&sort=confidence&dir=asc&page_size=100"))
cs = [i["confidence"] for i in r["items"]]; check("sort asc by confidence", cs == sorted(cs))
r = J(c.get(f"/api/intel/records/detections?{rng}&sort=DROP_TABLE"))
check("unknown sort key ignored safely", r["total"] > 0)
r = J(c.get(f"/api/intel/records/registrations?{rng}&category=visitor&page_size=100"))
check("registrations visitor filter", r["total"] == 3 and all(i["is_visitor"] for i in r["items"]), r["total"])
r = J(c.get(f"/api/intel/records/registrations?{rng}&guard=Faiz%20Guard&page_size=100"))
check("registrations by guard", {i["registered_by"] for i in r["items"]} == {"Faiz Guard"})
r = J(c.get("/api/intel/records/visitors?state=expiring")); check("visitors expiring filter", [i["plate_number"] for i in r["items"]] == ["VIS0001"], r["items"])
r = J(c.get("/api/intel/records/visitors?state=expired")); check("visitors expired filter", [i["plate_number"] for i in r["items"]] == ["VIS0003"])
r = J(c.get("/api/intel/records/registered_plates?q=guest")); check("plate owner search", r["total"] == 3)
r = J(c.get(f"/api/intel/records/sessions?{rng}&session_state=closed")); check("sessions closed filter", r["total"] == 2 and all(i["state"] == "closed" for i in r["items"]))
r = J(c.get(f"/api/intel/records/sessions?{rng}&page_size=100")); states = {i["id"]: i["state"] for i in r["items"]}
check("session states: open vs closed", states[3] == "open" and states[2] == "incomplete" and states[1] == "closed", states)
d = {i["id"]: i["duration_minutes"] for i in r["items"]}; check("closed duration = 480 min, open has none", d[1] == 480 and d[2] is None and d[4] == 7.0, d)
r = J(c.get(f"/api/intel/records/alerts?{rng}&review=open")); check("alerts open filter", r["total"] == 1)
r = J(c.get("/api/intel/records/nope")); check("unknown kind -> 400", c.get("/api/intel/records/nope").status_code == 400)

# ---- hour drill-down must equal chart bucket
tr = J(c.get(f"/api/intel/traffic?{rng}"))
hr = max(tr["hourly"], key=lambda h: h["authorized"] + h["unregistered"])
r = J(c.get(f"/api/intel/records/detections?{rng}&hour={hr['hour']}&page_size=100"))
check("hour drilldown total == chart bar", r["total"] == hr["authorized"] + hr["unregistered"], (r["total"], hr))
from datetime import timezone as _tz, timedelta as _td
from intelligence import _parse_ts, MY_TZ
check("hour drilldown rows are all in that MYT hour", all(_parse_ts(i["timestamp"]).astimezone(MY_TZ).hour == hr["hour"] for i in r["items"]))
day = max(tr["daily"], key=lambda d: d["authorized"] + d["unregistered"])
r = J(c.get(f"/api/intel/records/detections?day={day['date']}&page_size=100"))
check("day drilldown total == chart bar", r["total"] == day["authorized"] + day["unregistered"], (r["total"], day))
check("traffic daily covers full range (30 days)", len(J(c.get("/api/intel/traffic?range=30d"))["daily"]) == 30)
check("traffic totals == summary", sum(d["total"] for d in tr["daily"]) == sum(truth(s) for s in ("registered", "unregistered", "manual")))

r = J(c.get(f"/api/intel/records/sessions?{rng}&session_state=nologout")); check("sessions nologout filter", r["total"] == 2 and all(i["state"] in ("open", "incomplete") for i in r["items"]), r["total"])
rs = tr["override_reasons"] if "override_reasons" in tr else []
check("override reason counts sum to manual total", sum(x["count"] for x in rs) == truth("manual"), rs)
check("override reason labels resolved", all(x["label"] for x in rs))

# ---- recognition: histogram sums & no fabricated accuracy
rc = J(c.get(f"/api/intel/recognition?{rng}"))
check("histogram sums to reads_with_confidence", sum(b["count"] for b in rc["bins"]) == rc["reads_with_confidence"])
check("no 'accuracy' key fabricated", "accuracy" not in json.dumps(rc).lower().replace("not measured accuracy", ""))
check("score source is labelled", "not measured accuracy" in rc["score_source"])

# ---- guards analytics
gu = J(c.get(f"/api/intel/guards?{rng}"))
names = [x["guard"] for x in gu["guards"]]; check("guards alphabetical (not ranked)", names == sorted(names, key=str.lower))
f = next(x for x in gu["guards"] if x["guard"] == "Faiz Guard")
check("Faiz: 3 sessions, 1 open, closed minutes = 487", (f["sessions"], f["open_sessions"], f["logged_in_minutes"]) == (3, 1, 487.0), f)
check("Lina's no-logout session older than 16h = incomplete", next(x for x in gu["guards"] if x["guard"] == "Lina Guard")["incomplete_sessions"] == 1)
check("duration histogram total == closed sessions", sum(b["count"] for b in gu["duration_distribution"]) == 2)

# ---- vehicle investigation
v = J(c.get("/api/intel/vehicle?plate=abc-1234&range=30d"))
check("plate normalised + registration found", v["plate"] == "ABC1234" and v["registration"]["plate_number"] == "ABC1234")
check("timeline contains detections", v["counts"].get("detection", 0) > 0)
check("registration event present", v["counts"].get("registration") == 1)
t = [e["time"] for e in v["events"]]; check("timeline newest-first", t == sorted(t, reverse=True))
v2 = J(c.get("/api/intel/vehicle?plate=ZZZ1111&range=30d"))
check("unregistered plate: registration None + explanation", v2["registration"] is None and v2["registration_note"])
for e in v2["events"]:
    if e["type"] == "override_nearby": check("override proximity carries caveat", "not linked" in e["caveat"])
check("types filter respected", set(J(c.get("/api/intel/vehicle?plate=ZZZ1111&range=30d&types=alert"))["counts"]) <= {"alert"})
check("short plate -> 400", c.get("/api/intel/vehicle?plate=A").status_code == 400)

# ---- input validation
check("bad range -> 400", c.get("/api/intel/summary?range=forever").status_code == 400)
check("bad date -> 400", c.get("/api/intel/summary?range=custom&from=xx&to=2026-01-01").status_code == 400)
check("inverted range -> 400", c.get("/api/intel/summary?range=custom&from=2026-02-01&to=2026-01-01").status_code == 400)
check(">366 days -> 400", c.get("/api/intel/summary?range=custom&from=2024-01-01&to=2026-01-01").status_code == 400)
check("bad page ignored/400 not 500", c.get("/api/intel/records/overrides?page=abc").status_code == 400)
check("huge page_size is clamped", len(J(c.get("/api/intel/records/detections?range=30d&page_size=100000"))["items"]) <= 100)
check("filter-injection chars neutralised", c.get("/api/intel/records/registered_plates?q=a),owner_name.ilike.*").status_code == 200)

# ---- export
x = c.get(f"/api/intel/export/overrides.csv?{rng}")
body = x.get_data(as_text=True)
check("export is csv attachment", x.status_code == 200 and "attachment" in x.headers["Content-Disposition"])
check("export has generated-at + range header", "Generated at (MYT)" in body and "Asia/Kuala_Lumpur" in body)
check("export rows == overrides", body.count("\n") >= truth("manual"))
xr = c.get("/api/intel/export/registrations.csv?range=30d").get_data(as_text=True)
check("registrations export omits owner names", "Resident One" not in xr and "Guest A" not in xr)
xd = c.get("/api/intel/export/detections.csv?range=30d").get_data(as_text=True)
check("csv formula injection neutralised", "'=CMD1" in xd and ",=CMD1" not in xd)

# ---- meta honesty
m = J(c.get("/api/intel/meta"))
av = {a["key"]: a for a in m["availability"]}
check("entry/exit declared NOT recorded", av["entry_exit"]["recorded"] is False)
check("override ack declared NOT recorded", av["override_ack"]["recorded"] is False)
check("confidence declared recorded", av["confidence"]["recorded"] is True)
check("guards list has no password/IC fields", all(set(g) == {"name", "role", "active"} for g in m["guards"]))

# ---- alert review audit (fake store has no audit columns -> must still work)
check("acknowledge works w/o migration", c.post("/api/alerts/1/acknowledge").status_code == 200 and CLIENT.store["alerts"][0]["acknowledged"] is True)

print(f"\n{'ALL PASSED' if not fails else str(len(fails)) + ' FAILED: ' + ', '.join(fails)}")
sys.exit(1 if fails else 0)
