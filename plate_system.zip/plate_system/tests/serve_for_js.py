"""Runs the real Flask app on :5071 with seeded fake data (no camera / Pi / Supabase)."""
import os; os.environ["FLASK_SKIP_DOTENV"] = "1"
from harness import *
seed(); A = make_app()
A.app.run(host="127.0.0.1", port=5071, threaded=True, debug=False)
