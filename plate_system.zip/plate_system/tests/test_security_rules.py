"""Entry/exit tracking, anti-passback, blacklist/watchlist and role-based Security Intelligence.
No network, camera or Pi needed."""
import time
from datetime import datetime, timedelta, timezone
from harness import *

seed()
A = make_app()
import database as db
S = CLIENT.store
for t in ("plate_audit", "gate_traffic", "blacklist", "lookup_audit"):
    S[t] = []
A.GATE_INTEGRATION_ENABLED = False   # simulation: no request to the Pi, but entries are still recorded
fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""))
    if not cond: fails.append(name)

anon = A.app.test_client()
g = A.app.test_client(); login(g, "guard1")
h = A.app.test_client(); login(h, "head")
J = {"Content-Type": "application/json"}

def ago(**kw): return (datetime.now(timezone.utc) - timedelta(**kw)).isoformat()
def traffic(direction=None): return [r for r in S["gate_traffic"] if direction in (None, r["direction"])]
def alerts(kind): return [a for a in S["alerts"] if a.get("alert_type") == kind]

def detect(text, box=(0, 0, 400, 120)):
    A._plate_tracker.clear(); A.last_logged.clear()
    d = {"box": box, "text": text, "crop": None, "confidence": 0.9}
    A._process_one_detection(d, time.time())
    for _ in range(40):                     # the gate thread is async - wait for it
        time.sleep(0.05)
        if A.threading.active_count() <= 2: break
    time.sleep(0.15)
    return d

# ------------------------------------------------------------------ exit endpoint auth
r = anon.post("/api/gate/exit")
check("exit: no key + not the Pi's IP -> 403", r.status_code == 403)
A.GATE_API_KEY = "secret-key"
check("exit: wrong key -> 401", anon.post("/api/gate/exit", headers={"X-Gate-Key": "nope"}).status_code == 401)
check("exit: no key header -> 401", anon.post("/api/gate/exit").status_code == 401)
r = anon.post("/api/gate/exit", headers={"X-Gate-Key": "secret-key"})
check("exit: right key -> recorded", r.status_code == 200 and len(traffic("out")) == 1 and traffic("out")[0]["plate_number"] is None, r.get_json())
r = anon.post("/api/gate/exit", headers={"X-Gate-Key": "secret-key"})
check("exit: duplicate within 3 s is ignored", r.get_json().get("status") == "ignored" and len(traffic("out")) == 1)
A._last_exit_ts[0] = 0

# ------------------------------------------------------------------ presence maths
S["gate_traffic"].clear()
for p, mins in (("ABC1234", 50), ("VIS0001", 40), ("WXY9999", 30)):
    S["gate_traffic"].append(dict(id=len(S["gate_traffic"]) + 1, direction="in", plate_number=p, source="auto", created_at=ago(minutes=mins)))
S["gate_traffic"].append(dict(id=10, direction="out", plate_number=None, source="sensor", created_at=ago(minutes=35)))
sm = db.get_presence_summary()
check("presence: 3 in - 1 out = 2 inside", sm["inside"] == 2 and sm["entries"] == 3 and sm["exits"] == 1, sm)
check("presence: only plates with NO exit after them are 'confirmed inside'",
      [c["plate_number"] for c in sm["confirmed_inside"]] == ["WXY9999"], sm["confirmed_inside"])
S["gate_traffic"].append(dict(id=11, direction="out", plate_number=None, source="sensor", created_at=ago(minutes=1)))
S["gate_traffic"].append(dict(id=12, direction="out", plate_number=None, source="sensor", created_at=ago(seconds=30)))
S["gate_traffic"].append(dict(id=13, direction="out", plate_number=None, source="sensor", created_at=ago(seconds=10)))
sm = db.get_presence_summary()
check("presence: never negative, flags more exits than entries", sm["inside"] == 0 and sm["more_exits_than_entries"], sm)
r = g.get("/api/presence"); check("presence API readable by a guard", r.status_code == 200 and "inside" in r.get_json())
check("manual exit by a guard", g.post("/api/presence/exit", json={}).status_code == 200 and traffic("out")[-1]["source"] == "manual" and traffic("out")[-1]["performed_by"] == "Faiz Guard")
check("reset: guard -> 403", g.post("/api/admin/presence/reset", json={}).status_code == 403)
check("reset: head guard ok", h.post("/api/admin/presence/reset", json={}).status_code == 200)
sm = db.get_presence_summary()
check("after reset the baseline restarts at 0", sm["inside"] == 0 and sm["entries"] == 0 and sm["confirmed_inside"] == [], sm)

# ------------------------------------------------------------------ anti-passback check
S["gate_traffic"].clear()
S["gate_traffic"].append(dict(id=1, direction="in", plate_number="ABC1234", source="auto", created_at=ago(seconds=30)))
check("passback: inside the 2-min grace window is the same pass", db.check_passback("ABC1234") is None)
S["gate_traffic"].clear()
S["gate_traffic"].append(dict(id=1, direction="in", plate_number="ABC1234", source="auto", created_at=ago(minutes=10)))
check("passback: entered 10 min ago, nothing left since -> violation", db.check_passback("ABC1234") is not None)
S["gate_traffic"].append(dict(id=2, direction="out", plate_number=None, source="sensor", created_at=ago(minutes=5)))
check("passback: any exit recorded since -> allowed", db.check_passback("ABC1234") is None)
S["gate_traffic"].clear()
S["gate_traffic"].append(dict(id=1, direction="in", plate_number="ABC1234", source="auto", created_at=ago(hours=30)))
check("passback: entry older than 24 h is stale (sensor may have missed it)", db.check_passback("ABC1234") is None)
check("passback: plate never seen before", db.check_passback("NEVER123") is None)

# ------------------------------------------------------------------ live detection flow
S["gate_traffic"].clear(); S["logs"].clear(); S["alerts"].clear()
d = detect("ABC1234")
check("flow: first entry opens (registered) and is recorded", d["status"] == "registered" and len(traffic("in")) == 1 and traffic("in")[0]["plate_number"] == "ABC1234", (d, S["gate_traffic"]))
S["gate_traffic"][0]["created_at"] = ago(minutes=10)
d = detect("ABC1234")
check("flow: re-entry with no exit -> HELD (status unregistered)", d["status"] == "unregistered", d)
check("flow: held car is NOT recorded as an entry", len(traffic("in")) == 1)
check("flow: passback alert raised with detail", len(alerts("passback")) == 1 and "no vehicle has been recorded leaving" in (alerts("passback")[0].get("detail") or ""), alerts("passback"))
check("flow: hold is logged with a note", any("ANTI-PASSBACK" in (l.get("note") or "") for l in S["logs"]))
d = detect("ABC1234")
check("flow: same alert is not duplicated while undismissed", len(alerts("passback")) == 1)

pid = alerts("passback")[0]["id"]
check("release: anonymous -> 401", anon.post(f"/api/alerts/{pid}/release").status_code == 401)
S["alerts"].append(dict(id=500, plate_number="ZZZ1111", alert_type="frequent_visit", occurrence_count=3, window_minutes=60, created_at=ago(minutes=5), acknowledged=False))
check("release: only passback alerts (not repeat-visit)", g.post("/api/alerts/500/release").status_code == 400)
r = g.post(f"/api/alerts/{pid}/release")
check("release: guard verifies -> ok", r.status_code == 200, r.get_json())
check("release: entry recorded as guard_verified", traffic("in")[-1]["source"] == "guard_verified" and traffic("in")[-1]["performed_by"] == "Faiz Guard")
check("release: manual override log under the guard's name",
      any(l["status"] == "manual" and l.get("reason_code") == "anti_passback" and l["performed_by"] == "Faiz Guard" for l in S["logs"]))
check("release: alert marked reviewed", [a for a in S["alerts"] if a["id"] == pid][0]["acknowledged"] is True)
check("release: second release -> 409", g.post(f"/api/alerts/{pid}/release").status_code == 409)

S["gate_traffic"].append(dict(id=99, direction="out", plate_number=None, source="sensor", created_at=ago(minutes=1)))
S["gate_traffic"][0]["created_at"] = ago(minutes=20)
for e in traffic("in"): e["created_at"] = ago(minutes=20)
d = detect("ABC1234")
check("flow: after an exit is recorded the same plate enters normally", d["status"] == "registered")

A.ANTI_PASSBACK_MODE = "warn"
for e in traffic("in"): e["created_at"] = ago(minutes=20)
S["gate_traffic"] = [e for e in S["gate_traffic"] if e["direction"] != "out"]
n_in = len(traffic("in")); S["alerts"].clear()
d = detect("ABC1234")
check("warn mode: gate still opens but an alert is raised", d["status"] == "registered" and len(traffic("in")) == n_in + 1 and len(alerts("passback")) == 1)
A.ANTI_PASSBACK_MODE = "off"
S["alerts"].clear()
for e in traffic("in"): e["created_at"] = ago(minutes=20)
d = detect("ABC1234")
check("off mode: no passback alert", d["status"] == "registered" and not alerts("passback"))
A.ANTI_PASSBACK_MODE = "confirm"

# ------------------------------------------------------------------ blacklist API
check("blacklist: guard can read", g.get("/api/blacklist").status_code == 200)
check("blacklist: guard cannot add", g.post("/api/admin/blacklist", json={"plate_number": "BAD1234", "reason": "x"}).status_code == 403)
check("blacklist: reason required", h.post("/api/admin/blacklist", json={"plate_number": "BAD1234"}).status_code == 400)
check("blacklist: bad plate rejected", h.post("/api/admin/blacklist", json={"plate_number": "!!", "reason": "x"}).status_code == 400)
r = h.post("/api/admin/blacklist", json={"plate_number": "wxy 9999", "reason": "Banned by management", "severity": "ban"})
check("blacklist: head adds a ban (plate normalised)", r.status_code == 200 and S["blacklist"][0]["plate_number"] == "WXY9999" and S["blacklist"][0]["added_by"] == "Aminah Head", r.get_json())
check("blacklist: duplicate -> 409", h.post("/api/admin/blacklist", json={"plate_number": "WXY9999", "reason": "again"}).status_code == 409)
h.post("/api/admin/blacklist", json={"plate_number": "VIS0001", "reason": "Suspicious visitor", "severity": "watch"})
h.post("/api/admin/blacklist", json={"plate_number": "ABC1235", "reason": "Near-miss test", "severity": "ban"})
db._invalidate_blacklist_cache()

S["gate_traffic"].clear(); S["alerts"].clear()
d = detect("WXY9999")
check("ban: a REGISTERED but banned plate is not let in", d["status"] == "unregistered" and not traffic("in"), d)
check("ban: blacklist alarm raised with the reason", len(alerts("blacklist")) == 1 and alerts("blacklist")[0]["detail"] == "Banned by management")
check("ban: logged with a BLACKLISTED note", any("BLACKLISTED" in (l.get("note") or "") for l in S["logs"]))
d = detect("VIS0001")
check("watch: plate enters normally but guards get an alarm", d["status"] == "registered" and len(traffic("in")) == 1 and len(alerts("watchlist")) == 1)
S["alerts"].clear(); S["gate_traffic"].clear()
d = detect("ABC1234")   # one character away from banned ABC1235
check("near-match to a ban does NOT block (OCR could be off), but warns", d["status"] == "registered" and len(alerts("watchlist")) == 1 and "Possible match" in alerts("watchlist")[0]["detail"], alerts("watchlist"))
check("levenshtein: insert/delete/replace", db.levenshtein("ABC123", "ABC1234") == 1 and db.levenshtein("ABC1234", "ABD1244") == 2 and db.levenshtein("", "AB") == 2)

r = g.post("/api/register", json={"plate_number": "WXY 9999", "owner_name": "x"})
check("register: banned plate cannot be registered", r.status_code == 409 and "blacklisted" in r.get_json()["error"], r.get_json())
r = h.post("/api/motor-passes", json={"plate_number": "WXY9999", "owner_name": "Bike Owner"})
check("motor pass: banned plate cannot get a QR pass", r.status_code == 409, r.get_json())
bid = S["blacklist"][0]["id"]
check("blacklist: guard cannot remove", g.delete(f"/api/admin/blacklist/{bid}").status_code == 403)
check("blacklist: head removes (soft delete with who/when)", h.delete(f"/api/admin/blacklist/{bid}").status_code == 200 and S["blacklist"][0]["is_active"] is False and S["blacklist"][0]["removed_by"] == "Aminah Head")
db._invalidate_blacklist_cache()
S["gate_traffic"].clear(); S["alerts"].clear()
d = detect("WXY9999")
check("after removal the plate is let in again", d["status"] == "registered" and len(traffic("in")) == 1)
check("blacklist page renders (head: add form, guard: read only)",
      "Add a plate" in h.get("/blacklist").get_data(as_text=True) and "Add a plate" not in g.get("/blacklist").get_data(as_text=True))
check("blacklist page needs login", anon.get("/blacklist").status_code == 302)

# ------------------------------------------------------------------ role-based Security Intelligence
today = datetime.now(A.MY_TZ).date()
iso_ = lambda d: d.isoformat()
check("intel: anonymous -> 401", anon.get("/api/intel/summary?range=today").status_code == 401)
check("intel page opens for guards", g.get("/intelligence").status_code == 200 and "NX_IS_HEAD = false" in g.get("/intelligence").get_data(as_text=True))
check("intel page for head says head", "NX_IS_HEAD = true" in h.get("/intelligence").get_data(as_text=True))
check("guard: 7-day summary refused (today only)", g.get("/api/intel/summary?range=7d").status_code == 403)
check("guard: summary with no range refused", g.get("/api/intel/summary").status_code == 403)
r = g.get("/api/intel/summary?range=today")
k = r.get_json().get("kpis", {})
check("guard: today's summary works, staff/registration KPIs removed",
      r.status_code == 200 and "authorized" in k and not any(x in k for x in ("sessions", "sessions_no_logout", "registrations", "visitor_registrations", "registered_plates")), k)
check("head: summary keeps everything", {"sessions", "registrations"} <= set(h.get("/api/intel/summary?range=7d").get_json()["kpis"]))
check("guard: custom wide range refused", g.get(f"/api/intel/summary?range=custom&from={iso_(today - timedelta(days=5))}&to={iso_(today)}").status_code == 403)
check("guard: traffic today ok / 7d refused", g.get("/api/intel/traffic?range=today").status_code == 200 and g.get("/api/intel/traffic?range=7d").status_code == 403)
for kind in ("authorized", "unregistered", "detections", "alerts"):
    check(f"guard: records/{kind} today ok", g.get(f"/api/intel/records/{kind}?range=today").status_code == 200)
check("guard: records/visitors (current state) ok", g.get("/api/intel/records/visitors").status_code == 200)
check("guard: records/authorized without 'today' refused", g.get("/api/intel/records/authorized?range=7d").status_code == 403)
for kind in ("overrides", "sessions", "registrations", "registered_plates"):
    check(f"guard: records/{kind} is Head Guard only", g.get(f"/api/intel/records/{kind}?range=today").status_code == 403)
    check(f"head: records/{kind} ok", h.get(f"/api/intel/records/{kind}?range=7d").status_code == 200)
for path in ("recognition?range=today", "guards?range=today", "reliability", "export/authorized.csv?range=today", "lookups"):
    check(f"guard: /api/intel/{path.split('?')[0]} refused", g.get(f"/api/intel/{path}").status_code == 403)
check("head: export still works", h.get("/api/intel/export/authorized.csv?range=today").status_code == 200)
check("guard: meta hides the guard roster", g.get("/api/intel/meta").get_json()["guards"] == [] and len(h.get("/api/intel/meta").get_json()["guards"]) > 0)

# plate look-up for guards: last 3 days only, and recorded
S["lookup_audit"].clear()
rng3 = f"range=custom&from={iso_(today - timedelta(days=2))}&to={iso_(today)}"
check("guard lookup: default (7d) refused", g.get("/api/intel/vehicle?plate=ABC1234").status_code == 403)
check("guard lookup: 'all history' refused", g.get("/api/intel/vehicle?plate=ABC1234&range=all").status_code == 403)
check("guard lookup: 4+ days back refused", g.get(f"/api/intel/vehicle?plate=ABC1234&range=custom&from={iso_(today - timedelta(days=5))}&to={iso_(today)}").status_code == 403)
check("refused lookups are not recorded", len(S["lookup_audit"]) == 0)
r = g.get(f"/api/intel/vehicle?plate=ABC1234&{rng3}")
check("guard lookup: last 3 days ok", r.status_code == 200, r.get_json())
check("guard lookup is recorded with the guard's name", len(S["lookup_audit"]) == 1 and S["lookup_audit"][0]["guard_name"] == "Faiz Guard" and S["lookup_audit"][0]["query"] == "ABC1234", S["lookup_audit"])
check("head lookup: all history ok", h.get("/api/intel/vehicle?plate=ABC1234&range=all").status_code == 200)
r = h.get("/api/intel/lookups")
check("head can read the lookup audit", r.status_code == 200 and len(r.get_json()) == 1 and r.get_json()[0]["guard_name"] == "Faiz Guard")

# ------------------------------------------------------------------ pages
for path in ("/", "/blacklist", "/intelligence", "/team"):
    check(f"head: {path} renders", h.get(path).status_code == 200)
home = g.get("/").get_data(as_text=True)
check("dashboard has the 'Inside now' card and responsive.css", "kpi-inside" in home and "responsive.css" in home)
check("guard sidebar shows Blacklist + Security intelligence, not Team", "/blacklist" in home and "/intelligence" in home and "/team" not in home)

print("\nFAILED: %s" % fails if fails else "\nALL PASSED")
raise SystemExit(1 if fails else 0)
