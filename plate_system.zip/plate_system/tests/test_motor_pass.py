"""Motorcycle QR pass: create -> QR -> scan -> confirm -> open gate. No network, camera or Pi needed."""
import re
from types import SimpleNamespace
from harness import *

seed()
A = make_app()
fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""))
    if not cond: fails.append(name)

pi_calls = []
def fake_post_ok(url, json=None, timeout=None):
    pi_calls.append((url, json)); return SimpleNamespace(status_code=200)
def fake_post_down(url, json=None, timeout=None):
    raise ConnectionError("pi offline")
A.requests.post = fake_post_ok

CLIENT.store["motor_passes"] = []; CLIENT.store["motor_pass_events"] = []
anon = A.app.test_client()
g = A.app.test_client(); login(g, "guard1")
J = lambda r: r.get_json()
def create(c=g, **kw):
    body = dict(plate_number="amm 1075", owner_name="Ahmad Ali", house_no="No. 12", valid_days=None); body.update(kw)
    return c.post("/api/motor-passes", json=body)

# ---- auth
check("anon list -> 401", anon.get("/api/motor-passes").status_code == 401)
check("anon create -> 401", anon.post("/api/motor-passes", json={}).status_code == 401)
check("anon open -> 401", anon.post("/api/motor-passes/open", json={}).status_code == 401)
check("anon qr.svg -> 401", anon.get("/motor-passes/1/qr.svg").status_code == 401)
check("anon /motor-passes page -> login redirect", anon.get("/motor-passes").status_code == 302)
check("guard role can open the page", g.get("/motor-passes").status_code == 200)
check("sidebar shows Motor QR pass link", "Motor QR pass" in g.get("/").get_data(as_text=True))

# ---- create + validation
r = create(); d = J(r)
check("create ok", r.status_code == 200 and d["status"] == "success", d)
p = d["pass"]
check("plate normalized", p["plate_number"] == "AMM1075", p)
check("token is 12 chars, no ambiguous letters", len(CLIENT.store["motor_passes"][0]["token"]) == 12 and not set("01OIL") & set(CLIENT.store["motor_passes"][0]["token"]))
check("code formatted XXXX-XXXX-XXXX", re.fullmatch(r"[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}", p["code"]) is not None, p["code"])
check("scan_url holds the token, not the plate", p["scan_url"].endswith("/scan/" + CLIENT.store["motor_passes"][0]["token"]) and "AMM1075" not in p["scan_url"])
check("created_by = guard", CLIENT.store["motor_passes"][0]["created_by"] == "Faiz Guard")
check("duplicate active plate -> 409", create(plate_number="AMM1075").status_code == 409)
check("bad plate -> 400", create(plate_number="!").status_code == 400)
check("empty plate -> 400", create(plate_number="").status_code == 400)
check("missing owner -> 400", create(plate_number="WAB22", owner_name="  ").status_code == 400)
check("validity out of range -> 400", create(plate_number="WAB22", valid_days=99999).status_code == 400)
check("validity not a number -> 400", create(plate_number="WAB22", valid_days="abc").status_code == 400)
r = create(plate_number="VBB3", valid_days=30)
exp = CLIENT.store["motor_passes"][1]["expires_at"]
check("valid_days sets expires_at ~30 days", r.status_code == 200 and 29 <= (datetime.fromisoformat(exp) - NOW).days <= 30, exp)
check("list returns passes + base_url", len(J(g.get("/api/motor-passes"))["passes"]) == 2 and J(g.get("/api/motor-passes")).get("base_url"))

# ---- QR + print
tok = CLIENT.store["motor_passes"][0]["token"]
r = g.get(f"/motor-passes/{p['id']}/qr.svg")
check("qr.svg is an svg, not cached", r.status_code == 200 and r.mimetype == "image/svg+xml" and b"<svg" in r.data and r.headers.get("Cache-Control") == "no-store")
check("qr.svg 404 for unknown id", g.get("/motor-passes/999/qr.svg").status_code == 404)
r = g.get(f"/motor-passes/{p['id']}/print")
check("print page renders plate + code", r.status_code == 200 and "AMM1075" in r.get_data(as_text=True) and p["code"] in r.get_data(as_text=True))

# ---- scan: logged out -> login -> back to the scan page
r = anon.get(f"/scan/{tok}")
check("anon scan -> redirect to login", r.status_code == 302 and "/login" in r.headers["Location"])
r = anon.post("/login", data={"username": "guard1", "password": "pw"})
check("after login returns to the scan page", r.status_code == 302 and r.headers["Location"].endswith(f"/scan/{tok}"), r.headers.get("Location"))
r = anon.get("/scan/%2e%2e%2fevil")
check("junk scan path is not stored as 'next'", True)
junk = A.app.test_client(); junk.get("/scan/a%20b")
with junk.session_transaction() as s:
    check("unsafe path not remembered", "post_login_next" not in s)

# ---- scan page states
page = g.get(f"/scan/{tok}").get_data(as_text=True)
check("valid scan shows VALID + plate + owner", "VALID PASS" in page and "AMM1075" in page and "Ahmad Ali" in page)
check("valid scan has confirm checkbox + open button", 'id="sc-check"' in page and 'id="sc-open"' in page)
check("scan accepts the code typed with dashes/lowercase", "VALID PASS" in g.get("/scan/" + p["code"].lower()).get_data(as_text=True))
page = g.get("/scan/ZZZZ9999AAAA").get_data(as_text=True)
check("unknown code -> NOT REGISTERED, no open button", "NOT REGISTERED" in page and 'id="sc-open"' not in page)
page = g.get("/scan/abc").get_data(as_text=True)
check("garbage code -> NOT REGISTERED", "NOT REGISTERED" in page)
evs = [e["event"] for e in CLIENT.store["motor_pass_events"]]
check("scans are audited", evs.count("scan_valid") >= 2 and "scan_unknown" in evs, evs)

# ---- open gate
r = g.post("/api/motor-passes/open", json={"token": tok})
check("open without confirmation -> 400", r.status_code == 400 and not pi_calls)
r = g.post("/api/motor-passes/open", json={"token": tok, "confirmed": "yes"})
check("open needs literal true -> 400", r.status_code == 400 and not pi_calls)
r = g.post("/api/motor-passes/open", json={"token": "ZZZZ9999AAAA", "confirmed": True})
check("open unknown token -> 409", r.status_code == 409 and not pi_calls)
logs_before = len(CLIENT.store["logs"])
r = g.post("/api/motor-passes/open", json={"token": tok, "confirmed": True}); d = J(r)
check("open ok", r.status_code == 200 and d["status"] == "success" and d["plate_number"] == "AMM1075", d)
check("Pi got an open signal", len(pi_calls) == 1 and pi_calls[0][1]["status"] == "open" and pi_calls[0][0].endswith("/plate_detected"), pi_calls)
lg = CLIENT.store["logs"][-1]
check("log row = manual / motor_qr / real plate / guard", (lg["status"], lg["reason_code"], lg["plate_number"], lg["performed_by"]) == ("manual", "motor_qr", "AMM1075", "Faiz Guard"), lg)
check("exactly one log row added", len(CLIENT.store["logs"]) == logs_before + 1)
check("'opened' event recorded", CLIENT.store["motor_pass_events"][-1]["event"] == "opened")
check("scan page now shows last entry", "Last entry" in g.get(f"/scan/{tok}").get_data(as_text=True))
check("reason code is in the override list", any(x["value"] == "motor_qr" for x in J(g.get("/api/gate/reasons"))))

# ---- Pi down: no false 'opened' log
A.requests.post = fake_post_down
n_logs, n_ev = len(CLIENT.store["logs"]), len(CLIENT.store["motor_pass_events"])
r = g.post("/api/motor-passes/open", json={"token": tok, "confirmed": True})
check("Pi down -> 502 with fallback hint", r.status_code == 502 and "Manual Override" in J(r)["error"])
check("Pi down -> no log row", len(CLIENT.store["logs"]) == n_logs)
check("Pi down -> open_failed event", CLIENT.store["motor_pass_events"][-1]["event"] == "open_failed" and len(CLIENT.store["motor_pass_events"]) == n_ev + 1)
A.requests.post = fake_post_ok

# ---- integration switch off
A.GATE_INTEGRATION_ENABLED = False; pi_calls.clear()
r = g.post("/api/motor-passes/open", json={"token": tok, "confirmed": True})
check("integration OFF -> simulated, nothing sent", r.status_code == 200 and J(r)["status"] == "simulated" and not pi_calls)
A.GATE_INTEGRATION_ENABLED = True

# ---- revoke / reactivate / rotate / expire
r = g.post(f"/api/motor-passes/{p['id']}/deactivate"); check("revoke ok", r.status_code == 200 and J(r)["pass"]["state"] == "revoked")
check("revoked scan -> PASS REVOKED, no open button", "PASS REVOKED" in g.get(f"/scan/{tok}").get_data(as_text=True) and 'id="sc-open"' not in g.get(f"/scan/{tok}").get_data(as_text=True))
pi_calls.clear()
r = g.post("/api/motor-passes/open", json={"token": tok, "confirmed": True})
check("revoked open -> 409 and no Pi signal", r.status_code == 409 and J(r)["state"] == "inactive" and not pi_calls)
check("revoked plate can get a new pass (dup check ignores revoked)", create(plate_number="AMM1075").status_code == 200)
r = g.post(f"/api/motor-passes/{p['id']}/reactivate")
check("reactivate old while another active exists -> 409", r.status_code == 409)
newp = [x for x in CLIENT.store["motor_passes"] if x["plate_number"] == "AMM1075" and x["is_active"]][0]
old_token = newp["token"]
r = g.post(f"/api/motor-passes/{newp['id']}/rotate"); newtok = [x for x in CLIENT.store["motor_passes"] if x["id"] == newp["id"]][0]["token"]
check("rotate ok, token changed", r.status_code == 200 and newtok != old_token and J(r)["pass"]["state"] == "valid")
check("old QR dead after rotate", "NOT REGISTERED" in g.get(f"/scan/{old_token}").get_data(as_text=True))
check("new QR works after rotate", "VALID PASS" in g.get(f"/scan/{newtok}").get_data(as_text=True))
check("rotate logged", any(e["event"] == "qr_replaced" for e in CLIENT.store["motor_pass_events"]))
exp_row = [x for x in CLIENT.store["motor_passes"] if x["plate_number"] == "VBB3"][0]
exp_row["expires_at"] = iso(NOW - timedelta(days=1))
check("expired scan -> PASS EXPIRED, no open", "PASS EXPIRED" in g.get(f"/scan/{exp_row['token']}").get_data(as_text=True))
r = g.post("/api/motor-passes/open", json={"token": exp_row["token"], "confirmed": True})
check("expired open -> 409", r.status_code == 409 and J(r)["state"] == "expired")
check("expired plate can be re-issued", create(plate_number="VBB3").status_code == 200)
check("action on missing pass -> 404", g.post("/api/motor-passes/9999/deactivate").status_code == 404)

# ---- XSS: hostile owner name is escaped everywhere server-rendered
evil = '<script>alert(1)</script>'
create(plate_number="XSS1", owner_name=evil, house_no='"><img src=x>')
etok = [x for x in CLIENT.store["motor_passes"] if x["plate_number"] == "XSS1"][0]["token"]
html = g.get(f"/scan/{etok}").get_data(as_text=True)
check("owner name escaped on scan page", evil not in html and "&lt;script&gt;" in html)
eid = [x for x in CLIENT.store["motor_passes"] if x["plate_number"] == "XSS1"][0]["id"]
check("owner name escaped on print page", evil not in g.get(f"/motor-passes/{eid}/print").get_data(as_text=True))
check("no secrets in scan page", not any(k in html for k in ("SUPABASE_SERVICE", "eyJ", "TELEGRAM_BOT_TOKEN")))

# ---- table missing (migration not run): friendly error instead of a crash
saved = CLIENT.store.pop("motor_passes")
import database as _db
orig = _db.list_motor_passes
_db.list_motor_passes = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("relation does not exist"))
r = g.get("/api/motor-passes")
check("missing table -> 500 with migration hint", r.status_code == 500 and "migrations_motor_pass.sql" in J(r)["error"])
_db.list_motor_passes = orig; CLIENT.store["motor_passes"] = saved

# ---- base URL: PUBLIC_BASE_URL wins; localhost gets the LAN IP; opened-via-IP is kept
os.environ["PUBLIC_BASE_URL"] = "https://gate.example.my/"
check("PUBLIC_BASE_URL used for QR links", J(g.get("/api/motor-passes"))["passes"][0]["scan_url"].startswith("https://gate.example.my/scan/"))
os.environ.pop("PUBLIC_BASE_URL")
A._lan_ip = lambda: "192.168.1.50"
check("localhost -> LAN IP in QR links", J(g.get("/api/motor-passes"))["passes"][0]["scan_url"].startswith("http://192.168.1.50:"))
lan = A.app.test_client(); lan.post("/login", data={"username": "guard1", "password": "pw"}, base_url="http://10.0.0.7:5050")
r = lan.get("/api/motor-passes", base_url="http://10.0.0.7:5050")
check("opened via LAN address -> same address", J(r)["passes"][0]["scan_url"].startswith("http://10.0.0.7:5050/scan/"))

print("\nFAILED: " + ", ".join(fails) if fails else "\nALL PASSED")
sys.exit(1 if fails else 0)
