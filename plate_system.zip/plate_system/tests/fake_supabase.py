"""In-memory stand-in for the supabase-py query builder (select/filter/order/range/count)
so routes can be exercised without network access or real credentials."""
import re
from types import SimpleNamespace


def _cmp(a, b):
    return (a > b) - (a < b)


class _Not:
    def __init__(self, q): self.q = q
    def is_(self, col, val):
        self.q.preds.append(lambda r: (r.get(col) is not None) if val == "null" else (r.get(col) is not None))
        return self.q


class Query:
    def __init__(self, store, name):
        self.store, self.name = store, name
        self.preds, self.orders, self.mode = [], [], "select"
        self.count_mode, self.lo, self.hi, self.payload = None, None, None, None
        self.lim = None

    # --- verbs
    def select(self, cols="*", count=None, head=None): self.mode, self.count_mode = "select", count; return self
    def insert(self, row): self.mode, self.payload = "insert", row; return self
    def update(self, row): self.mode, self.payload = "update", row; return self
    def delete(self): self.mode = "delete"; return self
    # --- filters
    def _add(self, col, fn): self.preds.append(lambda r: r.get(col) is not None and fn(r[col])); return self
    def eq(self, c, v): self.preds.append(lambda r: r.get(c) == v); return self
    def neq(self, c, v): self.preds.append(lambda r: r.get(c) != v); return self
    def gt(self, c, v): return self._add(c, lambda x: _cmp(x, v) > 0)
    def gte(self, c, v): return self._add(c, lambda x: _cmp(x, v) >= 0)
    def lt(self, c, v): return self._add(c, lambda x: _cmp(x, v) < 0)
    def lte(self, c, v): return self._add(c, lambda x: _cmp(x, v) <= 0)
    def in_(self, c, vs): self.preds.append(lambda r: r.get(c) in vs); return self
    def is_(self, c, v): self.preds.append(lambda r: r.get(c) is None if v == "null" else r.get(c) == v); return self
    @property
    def not_(self): return _Not(self)
    def ilike(self, c, pat):
        rx = re.compile("^" + re.escape(pat).replace("%", ".*") + "$", re.I)
        return self._add(c, lambda x: bool(rx.match(str(x))))
    def or_(self, expr):
        parts = []
        for p in expr.split(","):
            col, op, pat = p.split(".", 2)
            assert op == "ilike", op
            rx = re.compile("^" + re.escape(pat).replace("%", ".*") + "$", re.I)
            parts.append((col, rx))
        self.preds.append(lambda r: any(r.get(c) is not None and rx.match(str(r[c])) for c, rx in parts))
        return self
    # --- shaping
    def order(self, col, desc=False): self.orders.append((col, desc)); return self
    def range(self, lo, hi): self.lo, self.hi = lo, hi; return self
    def limit(self, n): self.lim = n; return self

    def execute(self):
        rows = self.store.setdefault(self.name, [])
        if self.mode == "insert":
            items = self.payload if isinstance(self.payload, list) else [self.payload]
            out = []
            for it in items:
                it = dict(it); it.setdefault("id", max([r.get("id", 0) for r in rows] + [0]) + 1)
                if self.name == "alerts":      # column defaults the real table has (default now() / false)
                    it.setdefault("created_at", __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat())
                    it.setdefault("acknowledged", False)
                rows.append(it); out.append(it)
            return SimpleNamespace(data=out, count=None)
        match = [r for r in rows if all(p(r) for p in self.preds)]
        if self.mode == "update":
            for r in match: r.update(self.payload)
            return SimpleNamespace(data=match, count=None)
        if self.mode == "delete":
            for r in match: rows.remove(r)
            return SimpleNamespace(data=match, count=None)
        for col, desc in reversed(self.orders):
            match.sort(key=lambda r: (r.get(col) is None, r.get(col)), reverse=desc)
        total = len(match)
        if self.lo is not None: match = match[self.lo:self.hi + 1]
        if self.lim is not None: match = match[:self.lim]
        return SimpleNamespace(data=[dict(r) for r in match], count=total if self.count_mode else None)


class FakeClient:
    def __init__(self): self.store = {}
    def table(self, name): return Query(self.store, name)
