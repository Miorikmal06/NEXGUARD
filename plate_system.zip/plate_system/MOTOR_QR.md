# Motor QR pass

Plat motor ada kat belakang je, jadi kamera gate (hadap depan) tak boleh baca. Setiap motor dapat sticker QR.

## Setup (sekali je)
1. Supabase SQL Editor: run `migrations_motor_pass.sql` (selamat run banyak kali).
2. `pip install -r requirements.txt` (tambah `qrcode`).
3. Dalam `.env`, sangat disyorkan: `PUBLIC_BASE_URL=http://<alamat-tetap>:5050`
   - Kalau tak set, QR guna IP laptop semasa. Kalau WiFi/hotspot bertukar, QR yang dah dicetak tak boleh dibuka
     (guard boleh taip kod bawah QR di halaman Motor QR pass > "Scan by code").
4. Phone guard mesti satu rangkaian dengan laptop dan boleh buka `http://<alamat>:5050`.

## Flow
1. Dashboard > Motor QR pass > `+ New QR pass` (plat, nama, rumah, tempoh sah). Print kad, laminate, tampal kat depan motor.
2. Motor sampai gate. Guard scan QR guna kamera phone biasa -> `/scan/<token>` (kalau belum login, login dulu, terus balik ke scan).
3. Skrin hijau/merah: plat, owner, rumah, status. Guard tengok plat belakang motor, tick "plat sepadan", tekan OPEN GATE.
4. Log masuk sebagai manual override (reason `motor_qr`, plat sebenar, nama guard). Setiap scan masuk jadual `motor_pass_events`.

## Keselamatan
- QR cuma simpan token rawak (12 aksara), bukan plat. QR palsu = "NOT REGISTERED".
- Scan sahaja tak buka gate. Hanya guard yang login + tick pengesahan boleh buka.
- Sticker hilang/dicuri: Replace QR (token baru, sticker lama mati serta-merta) atau Revoke.
- Kalau Pi tak boleh dicapai: tiada log "opened" palsu; guard dapat mesej guna Manual Override.

## Test
`cd tests && python test_motor_pass.py` (tanpa kamera/Pi/Supabase sebenar).
