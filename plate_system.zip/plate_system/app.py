"""
app.py
Flask dashboard for the Plate Recognition System (Windows, standalone - does NOT touch
the Pi / barrier_v2 project).

Main routes:
  /                  -> dashboard (live feed + recent logs + registered plates)
  /video_feed        -> MJPEG stream, draws box + label on every detected plate
  /register          -> register a new plate (live capture)
  /gallery           -> gallery of all registered plate photos
  /api/capture       -> grab current frame, run detect+OCR, return suggested text
  /api/register      -> save new plate to database
  /api/plates        -> GET all registered plates / DELETE one
  /api/logs          -> GET recent logs (dashboard auto-refresh)
  /api/logs/dates    -> GET distinct dates with logs (for the day-by-day tabs)
  /api/logs/by-date  -> GET logs for one specific date
  /api/gate/manual   -> POST - guard opens the gate manually
  /api/scan/mode     -> GET/POST - switch between auto and manual scanning
  /api/scan/trigger  -> POST - run one detection pass (manual mode)
  /api/stats/today   -> GET - KPI counters for today
  /api/system/status -> GET - camera / gate link health
  /captures/<path>   -> serve snapshot/registered images (outside static/)
"""

import os
import re
import time
import threading
import functools
import hmac
import socket
import cv2
import requests
from collections import defaultdict, Counter
from flask import Flask, render_template, Response, jsonify, request, send_from_directory, session, redirect, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timezone, timedelta

import database as db
import detector
import telegram_bot
import intelligence

# PDF report export (see _build_activity_pdf / _build_team_pdf below)
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors as rl_colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, HRFlowable
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.legends import Legend
import io

MY_TZ = timezone(timedelta(hours=8))  # Malaysia time - used for "today" boundaries so
                                       # KPI indicators reset at Malaysia midnight, not UTC midnight

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-in-.env-for-production")
if app.secret_key == "change-this-in-.env-for-production":
    print("[WARNING] FLASK_SECRET_KEY not set in .env - using an insecure default. "
          "Guard sessions will reset every time the app restarts. Add FLASK_SECRET_KEY to .env.")

CAMERA_INDEX = 0  # change if your webcam isn't index 0
CAMERA_WIDTH = 1920   # emeet 1080p - if plates still look small/blurry, camera.get()
CAMERA_HEIGHT = 1080  # printed at startup shows what resolution was actually granted
LOG_COOLDOWN = 8  # seconds - avoids repeat logging for the same plate sitting in frame

# ============ MANUAL OVERRIDE: REASON CODES (audit trail) ============
# Single source of truth for the gate override dropdown - served to the frontend via
# GET /api/gate/reasons so the UI never has to hardcode/duplicate these labels.
OVERRIDE_REASONS = [
    {"value": "visitor_no_plate", "label": "Visitor - no plate registered"},
    {"value": "delivery_staff", "label": "Delivery / staff vehicle"},
    {"value": "motor_qr", "label": "Motorcycle - QR pass"},
    {"value": "anti_passback", "label": "Anti-passback - guard verified"},
    {"value": "system_error", "label": "System error - detection failed"},
    {"value": "emergency", "label": "Emergency"},
    {"value": "other", "label": "Other (note required)"},
]
OVERRIDE_REASON_VALUES = {r["value"] for r in OVERRIDE_REASONS}
OVERRIDE_REASON_LABELS = {r["value"]: r["label"] for r in OVERRIDE_REASONS}

# ============ VISITOR PASS: EXPIRY PRESETS ============
# Guard picks one of these on the Register page when marking a plate as a visitor pass.
VISITOR_DURATION_PRESETS = [
    {"value": 4, "label": "4 hours"},
    {"value": 12, "label": "12 hours"},
    {"value": 24, "label": "1 day"},
    {"value": 72, "label": "3 days"},
    {"value": 168, "label": "7 days"},
]
VISITOR_EXPIRY_SWEEP_INTERVAL = 60  # seconds between auto-expire sweeps

# ============ SESSION / IDLE TIMEOUT ============
IDLE_TIMEOUT_MINUTES = 20  # guard gets auto-logged out after this many minutes of no activity
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=IDLE_TIMEOUT_MINUTES + 5)  # absolute backstop


@app.context_processor
def inject_globals():
    """Makes IDLE_TIMEOUT_MINUTES available in every template (e.g. _sidebar.html's idle timer)."""
    return {"IDLE_TIMEOUT_MINUTES": IDLE_TIMEOUT_MINUTES}


# ============ GATE INTEGRATION (Raspberry Pi / barrier_v2) ============
# Enabled. NOTE: barrier.zip used TWO different Pi IPs across its files -
# app.py had 172.20.10.2, dashboard.py/laptop_api.py had 172.20.10.3.
# 172.20.10.2 is kept below as the default (matches the original app.py),
# but CONFIRM your Pi's actual current IP (e.g. via `hostname -I` on the Pi
# itself) and change it here if it's different before relying on this.
GATE_INTEGRATION_ENABLED = True
RASPBERRY_PI_IP = "172.20.10.2"  # CHANGE to match your Pi's current IP
RASPBERRY_API = f"http://{RASPBERRY_PI_IP}:5000"
GATE_REQUEST_TIMEOUT = 2  # seconds

# ============ SECURITY RULES: ENTRY/EXIT, ANTI-PASSBACK, BLACKLIST ============
# The exit gate only has an ultrasonic sensor (no camera), so an exit is "a vehicle left" with
# no plate. Anti-passback therefore asks: did this plate enter and has NOTHING been recorded
# leaving since? If so it cannot have left, and entering again is suspicious.
#   "off"     - no anti-passback checks
#   "warn"    - gate opens as normal, but an alert is raised
#   "confirm" - gate is NOT opened automatically; a guard verifies and releases it (default)
ANTI_PASSBACK_MODE = os.environ.get("ANTI_PASSBACK_MODE", "confirm").strip().lower()
if ANTI_PASSBACK_MODE not in ("off", "warn", "confirm"):
    ANTI_PASSBACK_MODE = "confirm"
ANTI_PASSBACK_WINDOW_HOURS = 24      # an entry older than this with no exit is treated as stale (sensor may have missed it)
PASSBACK_GRACE_SECONDS = 120         # same car still in front of the gate right after entering is NOT a passback
SECURITY_ALERT_COOLDOWN_MIN = 10     # don't repeat the same blacklist/passback alert while it is still un-dismissed
EXIT_DEBOUNCE_SECONDS = 3            # ignore a second exit signal this soon after the previous one
GATE_API_KEY = (os.environ.get("GATE_API_KEY") or "").strip()  # shared secret the Pi sends in X-Gate-Key

camera = None
camera_lock = threading.Lock()
last_logged = {}  # {plate_number: timestamp} for cooldown logging

# ============ MULTI-FRAME TRACKING (accuracy) ============
# Instead of trusting a single OCR reading, we track each plate box across
# consecutive frames (matched by box overlap / IoU) and only log + trigger the
# gate once several recent readings agree. This filters out one-off OCR typos
# and stops the gate from opening on a single bad frame.
_plate_tracker = defaultdict(lambda: {"readings": [], "last_seen": 0, "box": None, "logged": False, "status": None})
_tracker_lock = threading.Lock()
TRACKER_TIMEOUT = 3.0      # seconds - if a track isn't seen again within this, drop it
VOTES_NEEDED = 1           # 1 = terus detect (macam dulu). Naikkan ke 2-4 kalau nak lebih tepat tapi "reading..." lebih lama
IOU_MATCH_THRESHOLD = 0.3  # box overlap ratio to consider "same plate" across frames
MIN_BOX_WIDTH_FOR_OCR = 60  # px - skip OCR for boxes smaller than this (too far/blurry to read reliably)

# Malaysian plate format check (rough) - letters, optional space, digits, optional
# trailing letter. Used to discard OCR readings that can't possibly be a real plate
# before they're allowed to "vote" on what the plate says.
PLATE_PATTERN = re.compile(r'^[A-Z0-9]{2,12}$')  # hanya untuk LOG/gate - live feed sentiasa tunjuk apa saja teks yang dibaca

REPEAT_VISIT_THRESHOLD = 3     # how many times seen...
REPEAT_VISIT_WINDOW_MIN = 60   # ...within this many minutes triggers an alert
REPEAT_ALERT_COOLDOWN_MIN = 60  # jangan buat alert baru kalau alert lama plat ni belum di-dismiss (dalam tempoh ni)


def _looks_like_plate(text):
    if not text:
        return False
    return bool(PLATE_PATTERN.match(text.replace(" ", "").upper()))


def _iou(box1, box2):
    """Intersection-over-union of two (x1,y1,x2,y2) boxes - used to match the
    same physical plate across frames even though YOLO gives no object id."""
    if box1 is None or box2 is None:
        return 0
    x1, y1, x2, y2 = box1
    x1b, y1b, x2b, y2b = box2
    xi1, yi1 = max(x1, x1b), max(y1, y1b)
    xi2, yi2 = min(x2, x2b), min(y2, y2b)
    inter = max(0, xi2 - xi1) * max(0, yi2 - yi1)
    area1 = max(0, x2 - x1) * max(0, y2 - y1)
    area2 = max(0, x2b - x1b) * max(0, y2b - y1b)
    union = area1 + area2 - inter
    return inter / union if union > 0 else 0


def _match_or_create_track(box, now):
    """Find an existing track whose last-known box overlaps this one; otherwise
    start a new track. Must be called with _tracker_lock held."""
    for track_id, t in _plate_tracker.items():
        if now - t["last_seen"] < TRACKER_TIMEOUT and _iou(t["box"], box) > IOU_MATCH_THRESHOLD:
            return track_id
    return f"track_{now}_{box[0]}_{box[1]}"


def _prune_stale_tracks(now):
    """Must be called with _tracker_lock held."""
    stale = [tid for tid, t in _plate_tracker.items() if now - t["last_seen"] > TRACKER_TIMEOUT]
    for tid in stale:
        del _plate_tracker[tid]


def check_repeat_visit_alert(plate_number):
    """Lepas satu plat disahkan & dilog, semak kalau dia muncul >= THRESHOLD kali dalam
    WINDOW minit (registered atau tak, sama je) dan raise alert kepada guard.
    Plat yang OCR-nya beza 1 aksara dikira plat yang sama."""
    try:
        count = db.count_recent_logs(plate_number, minutes=REPEAT_VISIT_WINDOW_MIN)
        print(f"[repeat-check] {plate_number}: {count}/{REPEAT_VISIT_THRESHOLD} in last {REPEAT_VISIT_WINDOW_MIN} min")
        if count >= REPEAT_VISIT_THRESHOLD:
            if db.has_recent_alert(plate_number, minutes=REPEAT_ALERT_COOLDOWN_MIN):
                print(f"[repeat-check] {plate_number}: alert belum di-dismiss lagi, skip alert baru")
            else:
                db.create_alert(plate_number, count, REPEAT_VISIT_WINDOW_MIN)
                print(f"[ALERT] {plate_number} seen {count}x in {REPEAT_VISIT_WINDOW_MIN} min")
    except Exception as e:
        # Loud, not silent - punca #1 alert tak keluar ialah table `alerts` belum wujud.
        err_str = str(e)
        if "alerts" in err_str and ("does not exist" in err_str or "42P01" in err_str or "PGRST" in err_str):
            print("=" * 60)
            print("[ALERT ERROR] The 'alerts' table doesn't exist in Supabase yet.")
            print("Run migrations_new_features.sql in the Supabase SQL Editor,")
            print("then restart this app. Repeat-visit alerts will not work")
            print("until that table exists.")
            print("=" * 60)
        else:
            print(f"[check_repeat_visit_alert] error: {e}")

SCAN_MODE = "auto"  # "auto" (background worker) or "manual" (guard presses a button)
_manual_cache = {"detections": [], "expires": 0}  # holds last manual scan result briefly for box overlay

# ============ BACKGROUND DETECTION (decoupled from video stream) ============
# Running YOLO+OCR on every single streamed frame made the /video_feed loop wait for
# detection to finish before it could send the next frame - that's what caused the
# stream to lag/stutter. Instead, a background thread runs detection at its own pace
# (DETECTION_INTERVAL) on the most recent camera frame, and the video stream just reads
# the camera + overlays whatever the latest detection result was - so the feed itself
# always stays smooth regardless of how long YOLO/OCR takes.
DETECTION_INTERVAL = 0.4  # seconds between detection passes (~2.5x/sec) - tune lower for
                           # faster reaction, higher if CPU still struggles
_latest_detections = {"detections": [], "ts": 0}
_latest_lock = threading.Lock()


def detection_worker():
    """Background loop: grab a frame, run detect+log, store result for the stream to draw."""
    while True:
        loop_start = time.time()
        try:
            if SCAN_MODE == "auto":
                frame = read_frame()
                if frame is not None:
                    detections = process_and_log(frame)
                    with _latest_lock:
                        _latest_detections["detections"] = detections
                        _latest_detections["ts"] = time.time()
        except Exception as e:
            print(f"[detection_worker] error: {e}")

        elapsed = time.time() - loop_start
        time.sleep(max(0.0, DETECTION_INTERVAL - elapsed))


def visitor_expiry_worker():
    """
    Background loop - sweeps the 'plates' table every VISITOR_EXPIRY_SWEEP_INTERVAL
    seconds and deletes any visitor pass whose expires_at has passed, so temporary
    plates auto-remove themselves from the whitelist instead of piling up forever.
    (db.is_registered() also double-checks expiry inline as a defensive backstop for
    the window between a pass expiring and the next sweep.)
    """
    while True:
        try:
            expired = db.get_expired_visitor_plates()
            for row in expired:
                db.delete_plate(row["id"], performed_by="system", action="expired", strict=False)
                print(f"[visitor_expiry] auto-removed expired visitor plate: {row['plate_number']}")
        except Exception as e:
            print(f"[visitor_expiry_worker] error: {e}")
        time.sleep(VISITOR_EXPIRY_SWEEP_INTERVAL)


def send_to_raspberry(plate_number, status="open"):
    """
    Send the open-gate signal to the Pi. Runs in its own thread (fire-and-forget)
    so a slow/offline Pi never freezes the live feed or the OCR loop on Windows.
    Returns True when the Pi answered (any HTTP status < 400), else False.
    """
    try:
        response = requests.post(
            f"{RASPBERRY_API}/plate_detected",
            json={"plate": plate_number, "status": status},
            timeout=GATE_REQUEST_TIMEOUT,
        )
        print(f"[GATE] Sent to Pi: {plate_number} | Status: {status} | Code: {response.status_code}")
        return response.status_code < 400
    except Exception as e:
        print(f"[GATE] Failed to reach Pi: {e}")
        return False


def _open_gate_for_entry(plate_number, source="auto", performed_by=None):
    """Open the entry gate for a registered plate, and - only if the gate really opened
    (or gate integration is off, i.e. simulation) - record the entry for presence tracking."""
    ok = True
    if GATE_INTEGRATION_ENABLED:
        ok = send_to_raspberry(plate_number, "open")
    if ok:
        try:
            db.add_traffic("in", plate_number, source, performed_by)
        except Exception as e:
            print(f"[traffic] could not record entry for {plate_number} (run migrations_security_rules.sql?): {e}")
    return ok


def _raise_security_alert(plate_number, alert_type, detail):
    """blacklist | watchlist | passback alert on the dashboard (banner + beep).
    Never raises - a failure here must not stop the gate logic."""
    try:
        if db.has_recent_alert(plate_number, minutes=SECURITY_ALERT_COOLDOWN_MIN, alert_type=alert_type):
            return
        db.create_alert(plate_number, 1, 0, alert_type=alert_type, detail=detail)
        print(f"[ALERT:{alert_type}] {plate_number}: {detail}")
    except Exception as e:
        print(f"[alert:{alert_type}] could not raise alert for {plate_number}: {e}")


# ============ CAMERA HELPERS ============

def get_camera():
    global camera
    with camera_lock:
        if camera is None or not camera.isOpened():
            if camera is not None:
                camera.release()
            # CAP_DSHOW (DirectShow) is far more reliable than the default MSMF backend
            # on Windows - MSMF frequently fails to open a camera even on a valid index.
            camera = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
            if not camera.isOpened():
                # fall back to default backend in case DSHOW isn't available for this device
                camera = cv2.VideoCapture(CAMERA_INDEX)

            # Force 1080p - webcams often default to a much lower resolution
            # (e.g. 640x480) unless explicitly told otherwise, which hurts OCR
            # accuracy at any real distance. If the camera doesn't support the
            # exact resolution, it'll silently fall back to its closest match -
            # check camera.get(...) below if plates still look small/blurry.
            # MJPG = kamera hantar frame termampat, jauh lebih stabil untuk 1080p di Windows
            # (tanpa ni, 1080p raw sering gagal grab frame / MSMF error -1072875772)
            camera.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            camera.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
            camera.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)

            # Reduce buffering so the stream shows the *current* frame, not a
            # stale one queued a few frames behind - matters more at 1080p since
            # each frame is bigger and the default buffer can lag further behind.
            camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)

            actual_w = camera.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_h = camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
            print(f"[camera] requested {CAMERA_WIDTH}x{CAMERA_HEIGHT}, got {int(actual_w)}x{int(actual_h)}")
    return camera


_cam_fail_count = 0


def read_frame():
    global camera, _cam_fail_count
    cam = get_camera()
    with camera_lock:
        ret, frame = cam.read()
    if not ret:
        # Kalau gagal grab banyak kali berturut-turut, lepaskan kamera supaya
        # get_camera() cuba buka semula dari awal (bukan spam error selamanya).
        _cam_fail_count += 1
        if _cam_fail_count >= 10:
            print("[camera] gagal grab frame 10x berturut-turut, cuba buka semula kamera...")
            with camera_lock:
                if camera is not None:
                    camera.release()
                camera = None
            _cam_fail_count = 0
        return None
    _cam_fail_count = 0
    return frame


def camera_is_online():
    cam = get_camera()
    return cam is not None and cam.isOpened()


# ============ AUTH ============

# Guards removed/deactivated while logged in: their existing session cookie must stop working
# immediately, not at the next idle timeout. (In-memory; a removed guard can't log in again anyway.)
_REVOKED_GUARD_IDS = set()


def _session_valid():
    gid = session.get("guard_id")
    if not gid:
        return False
    if gid in _REVOKED_GUARD_IDS:
        session.clear()
        return False
    return True


def login_required_page(view_func):
    """For page routes - redirects to /login if not authenticated."""
    @functools.wraps(view_func)
    def wrapped(*args, **kwargs):
        if not _session_valid():
            return redirect(url_for("login_page"))
        return view_func(*args, **kwargs)
    return wrapped


def login_required_api(view_func):
    """For API routes - returns 401 JSON if not authenticated."""
    @functools.wraps(view_func)
    def wrapped(*args, **kwargs):
        if not _session_valid():
            return jsonify({"error": "Not logged in"}), 401
        return view_func(*args, **kwargs)
    return wrapped


def head_guard_required_page(view_func):
    """For page routes - only 'head_guard' role may pass; others get redirected home."""
    @functools.wraps(view_func)
    def wrapped(*args, **kwargs):
        if not _session_valid():
            return redirect(url_for("login_page"))
        if session.get("guard_role") != "head_guard":
            return redirect(url_for("dashboard"))
        return view_func(*args, **kwargs)
    return wrapped


def head_guard_required_api(view_func):
    """For API routes - only 'head_guard' role may pass; others get 403 JSON."""
    @functools.wraps(view_func)
    def wrapped(*args, **kwargs):
        if not _session_valid():
            return jsonify({"error": "Not logged in"}), 401
        if session.get("guard_role") != "head_guard":
            return jsonify({"error": "Head Guard access only"}), 403
        return view_func(*args, **kwargs)
    return wrapped


# ============ DETECTION + LOGGING ============

def _quick_is_registered(plate_text):
    """Semakan pantas guna cache senarai plat (TIADA network call setiap frame) -
    hanya untuk warna kotak di live feed. Keputusan gate guna db.is_registered()."""
    try:
        target = db.normalize_plate(plate_text)
        if not target:
            return False
        return target in {db.normalize_plate(p) for p in db._get_registered_plates_cached()}
    except Exception:
        return False


def _process_one_detection(det, now):
    box = det["box"]
    plate_text = det["text"]
    box_width = box[2] - box[0]

    track_id = _match_or_create_track(box, now)
    track = _plate_tracker[track_id]
    track["box"] = box
    track["last_seen"] = now

    # Plat lain muncul di kedudukan yang sama (kereta lama keluar, kereta baru masuk
    # dalam masa TRACKER_TIMEOUT) - reset track supaya tak tunjuk teks plat lama.
    if track["logged"] and track["readings"] and _looks_like_plate(plate_text):
        old = Counter(track["readings"]).most_common(1)[0][0]
        diff = sum(1 for a, b in zip(plate_text, old) if a != b) + abs(len(plate_text) - len(old))
        if diff > 2:
            track["readings"] = []
            track["logged"] = False
            track["status"] = None

    # ---- Live feed: SENTIASA tunjuk teks yang dibaca + warna (hijau registered / merah tidak) ----
    det["status"] = track["status"] or ("registered" if _quick_is_registered(plate_text) else "unregistered")

    if _looks_like_plate(plate_text):
        track["readings"].append(plate_text)
        if len(track["readings"]) > 10:
            track["readings"] = track["readings"][-10:]  # keep last 10 only

    # Track ni dah dilog - guna keputusan yang dah disahkan tadi (tak query DB setiap frame)
    if track["logged"]:
        if track["readings"]:
            det["text"] = Counter(track["readings"]).most_common(1)[0][0]
        det["status"] = track["status"]
        return

    # Terlalu kecil/jauh untuk dilog dengan yakin - masih dipaparkan di live feed, cuma tak dilog
    if box_width < MIN_BOX_WIDTH_FOR_OCR:
        return

    if len(track["readings"]) < VOTES_NEEDED:
        return
    stable_plate, vote_count = Counter(track["readings"]).most_common(1)[0]
    if vote_count < VOTES_NEEDED:
        return

    # ---- Sahkan dengan DB (authoritative), log, buka gate ----
    plate_row = db.is_registered(stable_plate)  # row (resident_id etc.) - used for Telegram notification
    registered = bool(plate_row)

    # Security rules (blacklist / watchlist / anti-passback). Wrapped so that a problem here
    # (e.g. migration not run yet) can never stop the normal gate flow.
    hold_gate = False
    rule_note = None
    rule_alerts = []   # list of (alert_type, detail)
    try:
        bl = db.get_blacklist_match(stable_plate)
        if bl and not bl.get("near") and bl.get("severity") == "ban":
            hold_gate = True
            rule_note = f"BLACKLISTED: {bl.get('reason')}"
            rule_alerts.append(("blacklist", bl.get("reason") or "Blacklisted plate"))
        elif bl and bl.get("near"):
            rule_alerts.append(("watchlist", f"Possible match to {bl['plate_number']} ({bl['severity']}): "
                                             f"{bl.get('reason')} - OCR may be one character off"))
        elif bl:
            rule_alerts.append(("watchlist", bl.get("reason") or "Watchlist plate"))

        if registered and not hold_gate and ANTI_PASSBACK_MODE != "off":
            pb = db.check_passback(stable_plate, ANTI_PASSBACK_WINDOW_HOURS, PASSBACK_GRACE_SECONDS)
            if pb:
                detail = (f"Entered {max(1, pb['seconds_since'] // 60)} min ago and no vehicle has been "
                          f"recorded leaving since")
                rule_alerts.append(("passback", detail))
                if ANTI_PASSBACK_MODE == "confirm":
                    hold_gate = True
                    rule_note = "ANTI-PASSBACK HOLD: " + detail
    except Exception as e:
        print(f"[rules] {stable_plate}: {e}")

    status = "registered" if (registered and not hold_gate) else "unregistered"
    det["text"] = stable_plate
    det["status"] = status
    track["status"] = status
    track["logged"] = True

    if now - last_logged.get(stable_plate, 0) > LOG_COOLDOWN:
        last_logged[stable_plate] = now

        snapshot_path = None
        try:
            os.makedirs("captures/logs", exist_ok=True)
            snapshot_path = f"captures/logs/{stable_plate.replace(' ', '_')}_{int(now)}.jpg"
            cv2.imwrite(snapshot_path, det["crop"])
            db.add_log(stable_plate, status, snapshot_path, det["confidence"], note=rule_note)
            check_repeat_visit_alert(stable_plate)
        except Exception as e:
            # Kegagalan log (contoh Supabase down) TAK BOLEH matikan live feed / gate
            print(f"[log error] {stable_plate}: {e}")

        for alert_type, detail in rule_alerts:
            _raise_security_alert(stable_plate, alert_type, detail)

        # ============ GATE: open only for registered plates that are not on hold ============
        if status == "registered":
            threading.Thread(
                target=_open_gate_for_entry,
                args=(stable_plate, "auto"),
                daemon=True,
            ).start()

        # Resident's own car / their visitor pass entered -> Telegram notification
        # (runs in its own thread inside notify_entry; no-op if the bot is disabled)
        if status == "registered":
            telegram_bot.notify_entry(plate_row, stable_plate, snapshot_path)


def process_and_log(frame):
    """Detect semua plat, baca teks, dan warnakan kotak (hijau = registered, merah = tidak).
    Log + gate dicetuskan bila VOTES_NEEDED bacaan sepadan (default 1 = terus).
    Ralat pada satu plat/DB TIDAK akan menghentikan paparan live feed."""
    detections = detector.detect_plates(frame)
    now = time.time()

    with _tracker_lock:
        for det in detections:
            try:
                _process_one_detection(det, now)
            except Exception as e:
                print(f"[process_and_log] error pada {det.get('text')!r}: {e}")
                det.setdefault("status", "unregistered")
        _prune_stale_tracks(now)

    return detections


def draw_detections(frame, detections):
    # Skala garisan + tulisan ikut saiz frame supaya kotak nampak jelas pada 1080p
    fh, fw = frame.shape[:2]
    thickness = max(2, fw // 400)
    font_scale = max(0.6, fw / 1600)
    for det in detections:
        x1, y1, x2, y2 = det["box"]
        status = det.get("status", "unknown")
        color = (0, 200, 0) if status == "registered" else (0, 0, 255)
        label = f'{det["text"] or "?"} ({status})'

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        cv2.putText(frame, label, (x1, max(int(30 * font_scale), y1 - 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, font_scale, color, thickness)
    return frame


def gen_video_stream():
    while True:
        frame = read_frame()
        if frame is None:
            time.sleep(0.1)
            continue

        try:
            if SCAN_MODE == "auto":
                # Detection runs in the background worker (see detection_worker) - here we
                # just draw whichever result is freshest, so streaming stays smooth even
                # while YOLO/OCR is still crunching on a previous frame.
                with _latest_lock:
                    detections = _latest_detections["detections"]
                frame = draw_detections(frame, detections)
            else:
                # Manual mode - skip per-frame detection (saves CPU).
                # If there's a recent manual scan result (within 5s), draw that box.
                if time.time() < _manual_cache["expires"]:
                    frame = draw_detections(frame, _manual_cache["detections"])
        except Exception as e:
            print(f"Detection error: {e}")

        ok, buffer = cv2.imencode(".jpg", frame)
        if not ok:
            continue

        yield (b"--frame\r\n"
               b"Content-Type: image/jpeg\r\n\r\n" + buffer.tobytes() + b"\r\n")


# ============ ROUTES: AUTH ============

def _login_slides():
    """Pick the image for each of the 5 login slides: a real photo/AI render dropped into
    static/images/login/slide-N.(jpg|jpeg|webp|png) wins; otherwise the bundled slide-N.svg is used."""
    base = os.path.join(app.static_folder, "images", "login")
    out = []
    for n in range(1, 6):
        pick = f"slide-{n}.svg"
        for ext in ("jpg", "jpeg", "webp", "png"):
            if os.path.exists(os.path.join(base, f"slide-{n}.{ext}")):
                pick = f"slide-{n}.{ext}"
                break
        out.append("images/login/" + pick)
    return out


def _render_login(error=None, selected_id=None, status=200):
    """Login screen: a scroller of registered guard names (id + name only)."""
    roster = []
    try:
        roster = db.list_login_roster()
    except Exception as e:
        print(f"[login] could not load guard roster: {e}")
    return render_template("login.html", error=error, roster=roster, selected_id=selected_id), status


@app.route("/login", methods=["GET", "POST"])
def login_page():
    if request.method == "GET":
        return _render_login()

    password = request.form.get("password", "")
    guard_id = request.form.get("guard_id", type=int)

    if guard_id:
        # Normal path: the guard picked their name from the scroller.
        guard = db.get_guard_for_login(guard_id)
    else:
        # Fallback (roster failed to load): classic username entry.
        guard = db.get_guard_by_username(request.form.get("username", "").strip().lower())

    if not guard or not check_password_hash(guard["password_hash"], password):
        return _render_login("Wrong password. Try again.", selected_id=guard_id, status=401)
    if not guard.get("is_active", True):
        return _render_login("This account has been deactivated. Contact your Head Guard.", status=401)

    session["guard_id"] = guard["id"]
    session["guard_name"] = guard["full_name"]
    session["guard_role"] = guard["role"]
    session["login_log_id"] = db.create_login_log(guard["id"], guard["full_name"], guard["username"])
    session.permanent = True  # so PERMANENT_SESSION_LIFETIME (idle-timeout backstop) applies
    # Guard scanned a motorcycle QR while logged out -> send them straight back to that scan.
    nxt = session.pop("post_login_next", None)
    if nxt and _SCAN_PATH_RE.fullmatch(nxt):
        return redirect(nxt)
    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    db.close_login_log(session.get("login_log_id"))
    session.clear()
    return redirect(url_for("login_page"))


# ============ ROUTES: PAGES ============

@app.route("/")
@login_required_page
def dashboard():
    plates = db.get_all_plates()
    logs = db.get_recent_logs(8)
    return render_template("index.html", plates=plates, logs=logs)


@app.route("/register")
@login_required_page
def register_page():
    return render_template("register.html")


@app.route("/gallery")
@login_required_page
def gallery_page():
    plates = db.get_all_plates()
    return render_template("gallery.html", plates=plates)


@app.route("/team")
@head_guard_required_page
def team_page():
    return render_template("team.html")


@app.route("/profile")
@app.route("/profile/<int:guard_id>")
@login_required_page
def profile_page(guard_id=None):
    """Guard profile with the hanging ID card. A guard sees their own; the Head Guard
    can open anyone's (IC number + photo are personal data)."""
    me = session.get("guard_id")
    if guard_id is None:
        guard_id = me
    if guard_id != me and session.get("guard_role") != "head_guard":
        return redirect(url_for("profile_page"))
    guard = db.get_guard_by_id(guard_id)
    if not guard:
        return redirect(url_for("dashboard"))

    stats = None
    try:
        stats = _build_guard_activity_report(guard["full_name"], guard_id, days=30)["totals"]
    except Exception as e:
        print(f"[profile] could not build activity stats: {e}")
    return render_template("profile.html", g=guard, stats=stats, is_self=(guard_id == me))


@app.route("/video_feed")
@login_required_api
def video_feed():
    return Response(gen_video_stream(),
                     mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/captures/<path:filename>")
@login_required_api
def serve_capture(filename):
    """Serve snapshot/registered images (captures/registered/*, captures/logs/*) - outside static/.
    captures/guards/* holds IC copies, which are personal documents, so those are
    restricted to the Head Guard even though the rest of /captures is open to any
    signed-in guard."""
    if filename.startswith("guards/") and session.get("guard_role") != "head_guard":
        return jsonify({"error": "Head Guard access only"}), 403
    return send_from_directory("captures", filename)


# ============ ROUTES: API ============

_register_detect_lock = threading.Lock()


def _fresh_detections(max_age=6.0, force_direct=False):
    """
    Dapatkan hasil detect+OCR TERKINI dengan pantas untuk halaman Register.
    - Mode auto: guna terus hasil background worker kalau masih segar (< max_age saat; longgar sebab OCR di CPU boleh ambil masa) -
      TIADA YOLO/OCR kedua, jadi respons hampir serta-merta.
    - Selainnya (mode manual / worker lambat): detect terus pada frame kamera semasa.
    Return None kalau kamera tak boleh diakses.
    """
    if SCAN_MODE == "auto" and not force_direct:
        with _latest_lock:
            ts = _latest_detections["ts"]
            dets = list(_latest_detections["detections"])
        if ts and time.time() - ts <= max_age:
            return dets

    if not _register_detect_lock.acquire(timeout=5):
        return []
    try:
        frame = read_frame()
        if frame is None:
            return None
        return detector.detect_plates(frame, force_fallback=True)
    finally:
        _register_detect_lock.release()


def _best_detection(dets):
    """Pilih plat terbaik: teks munasabah dahulu, kemudian confidence OCR, kemudian confidence kotak."""
    return max(dets, key=lambda d: (
        detector.is_plausible_plate_text(d.get("text")),
        bool(d.get("text")),
        d.get("ocr_confidence", 0),
        d.get("confidence", 0),
    ))


@app.route("/api/live_plate", methods=["GET"])
@login_required_api
def api_live_plate():
    """Dipanggil berkala oleh halaman Register (auto-detect): ada plat dengan teks di depan kamera?"""
    dets = _fresh_detections()
    if dets is None:
        return jsonify({"found": False, "error": "Could not access the camera"})
    # Hanya bacaan yang munasabah sebagai nombor plat dikira "found" (elak auto-capture sampah)
    dets = [d for d in dets if detector.is_plausible_plate_text(d.get("text"))]
    if not dets:
        return jsonify({"found": False})
    best = _best_detection(dets)
    return jsonify({
        "found": True,
        "text": best["text"],
        "confidence": round(best["confidence"], 2),
        "ocr_confidence": round(best["ocr_confidence"], 2),
    })


@app.route("/api/capture", methods=["POST"])
@login_required_api
def api_capture():
    """Ambil hasil detect+OCR semasa (pantas - guna hasil worker kalau segar), simpan gambar penuh."""
    dets = _fresh_detections()
    if dets is None:
        return jsonify({"error": "Could not access the camera"}), 500
    if not dets:
        # Worker mungkin belum sempat nampak - cuba detect terus pada frame semasa
        dets = _fresh_detections(force_direct=True)
        if dets is None:
            return jsonify({"error": "Could not access the camera"}), 500
    if not dets:
        return jsonify({"status": "no_plate", "message": "No plate detected. Try repositioning the vehicle."})

    best = _best_detection(dets)

    frame = read_frame()
    if frame is None:
        return jsonify({"error": "Could not access the camera"}), 500

    os.makedirs("captures/registered", exist_ok=True)
    temp_path = f"captures/registered/temp_{int(time.time())}.jpg"
    # Save the FULL frame (not the tight plate crop) so the registration photo and
    # gallery actually show the whole vehicle, not just a zoomed-in plate rectangle.
    cv2.imwrite(temp_path, frame)

    return jsonify({
        "status": "success",
        "suggested_plate": best["text"],
        "confidence": round(best["confidence"], 2),
        "ocr_confidence": round(best["ocr_confidence"], 2),
        "photo_path": temp_path,
    })


@app.route("/api/register", methods=["POST"])
@login_required_api
def api_register():
    data = request.json
    plate_number = data.get("plate_number", "").strip()
    owner_name = data.get("owner_name", "").strip() or None
    photo_path = data.get("photo_path")
    car_type = data.get("car_type", "").strip() or None
    car_color = data.get("car_color", "").strip() or None
    house_no = data.get("house_no", "").strip() or None
    registered_by = session.get("guard_name")  # auto-captured from the logged-in guard

    is_visitor = bool(data.get("is_visitor"))
    expires_at = None
    if is_visitor:
        try:
            duration_hours = float(data.get("expiry_hours"))
        except (TypeError, ValueError):
            duration_hours = None
        if not duration_hours or duration_hours <= 0:
            return jsonify({"error": "Pick how long this visitor pass should stay valid"}), 400
        if duration_hours > 24 * 30:
            return jsonify({"error": "Visitor pass can't be longer than 30 days"}), 400
        expires_at = (datetime.now(timezone.utc) + timedelta(hours=duration_hours)).isoformat()

    if not plate_number:
        return jsonify({"error": "Plate number can't be empty"}), 400

    bl = _banned_entry(plate_number)
    if bl:
        return jsonify({"error": f"This plate is blacklisted ({bl.get('reason')}). It cannot be registered."}), 409

    success = db.add_plate(plate_number, owner_name, photo_path, car_type, car_color, house_no,
                            registered_by, is_visitor=is_visitor, expires_at=expires_at)
    if not success:
        return jsonify({"error": "This plate is already registered"}), 409

    message = f"Plate {plate_number} registered successfully"
    if is_visitor:
        expires_local = datetime.fromisoformat(expires_at).astimezone(MY_TZ).strftime("%d %b, %H:%M")
        message = f"Visitor plate {plate_number} registered - expires {expires_local} (auto-removed after that)"

    return jsonify({"status": "success", "message": message})


@app.route("/api/plates", methods=["GET"])
@login_required_api
def api_get_plates():
    return jsonify(db.get_all_plates())


@app.route("/api/plates/<int:plate_id>", methods=["DELETE"])
@login_required_api
def api_delete_plate(plate_id):
    """Any signed-in guard may remove a plate, but every removal is written to the
    plate_audit table first (plate number, owner, who deleted it, when)."""
    guard_name = session.get("guard_name")
    try:
        row = db.delete_plate(plate_id, performed_by=guard_name,
                              performed_by_id=session.get("guard_id"), action="deleted")
    except Exception as e:
        print(f"[plate_delete] failed for plate id {plate_id}: {e}")
        return jsonify({"error": "Could not record the audit entry, so the plate was NOT removed. "
                                 "Ask the Head Guard to run migrations_plate_audit.sql in Supabase."}), 500
    if row is None:
        return jsonify({"error": "Plate not found (maybe already removed)"}), 404
    print(f"[plate_delete] {row.get('plate_number')} removed by {guard_name}")
    return jsonify({"status": "success", "plate_number": row.get("plate_number")})


@app.route("/api/admin/plate-audit", methods=["GET"])
@head_guard_required_api
def api_admin_plate_audit():
    """Head Guard only: who removed which plate, newest first."""
    limit = min(max(request.args.get("limit", 100, type=int), 1), 500)
    try:
        return jsonify(db.get_plate_audit(limit))
    except Exception as e:
        print(f"[plate_audit] read failed: {e}")
        return jsonify({"error": "plate_audit table not found - run migrations_plate_audit.sql in Supabase."}), 500


@app.route("/api/logs", methods=["GET"])
@login_required_api
def api_get_logs():
    limit = request.args.get("limit", 30, type=int)
    status = request.args.get("status")
    return jsonify(db.get_recent_logs(limit, status))


@app.route("/api/scan/mode", methods=["GET", "POST"])
@login_required_api
def api_scan_mode():
    """GET - read current mode. POST {"mode": "auto"|"manual"} - switch mode."""
    global SCAN_MODE
    if request.method == "POST":
        data = request.json or {}
        mode = data.get("mode")
        if mode not in ("auto", "manual"):
            return jsonify({"error": "mode must be 'auto' or 'manual'"}), 400
        SCAN_MODE = mode
    return jsonify({"mode": SCAN_MODE})


@app.route("/api/scan/trigger", methods=["POST"])
@login_required_api
def api_scan_trigger():
    """Guard presses 'Scan now' while in manual mode."""
    frame = read_frame()
    if frame is None:
        return jsonify({"error": "Could not access the camera"}), 500

    detections = process_and_log(frame)
    _manual_cache["detections"] = detections
    _manual_cache["expires"] = time.time() + 5  # keep the box overlay visible for 5s

    results = [
        {"plate": d["text"], "status": d.get("status", "unknown"), "confidence": round(d["confidence"], 2)}
        for d in detections if d["text"]
    ]

    if not results:
        return jsonify({"status": "no_plate", "message": "No plate detected in the current frame."})

    return jsonify({"status": "success", "detections": results})


@app.route("/api/logs/dates", methods=["GET"])
@login_required_api
def api_get_log_dates():
    """Distinct dates found in the last 200 logs (for the day-by-day tabs)."""
    logs = db.get_recent_logs(200)
    dates = sorted({log["timestamp"][:10] for log in logs}, reverse=True)
    return jsonify(dates)


@app.route("/api/logs/by-date", methods=["GET"])
@login_required_api
def api_get_logs_by_date():
    date_str = request.args.get("date")
    status = request.args.get("status")
    if not date_str:
        return jsonify({"error": "The 'date' parameter is required (format YYYY-MM-DD)"}), 400
    return jsonify(db.get_logs_by_date(date_str, status=status))


@app.route("/api/gate/reasons", methods=["GET"])
@login_required_api
def api_gate_reasons():
    """Reason-code options for the Manual Gate Override form - single source of
    truth shared with OVERRIDE_REASON_LABELS used when rendering logs."""
    return jsonify(OVERRIDE_REASONS)


@app.route("/api/gate/manual", methods=["POST"])
@login_required_api
def api_gate_manual():
    """Guard presses the 'Manual Gate Override' button on the dashboard. A reason
    code is REQUIRED (audit trail) - free-text note is optional, except when
    reason_code is 'other', where a note is required so there's still something
    to go on when reviewing the log later."""
    data = request.json or {}
    reason_code = (data.get("reason_code") or "").strip()
    note = (data.get("note") or "").strip() or None

    if reason_code not in OVERRIDE_REASON_VALUES:
        return jsonify({"error": "Please select a reason for this override"}), 400
    if reason_code == "other" and not note:
        return jsonify({"error": "Please add a short note when reason is 'Other'"}), 400

    guard_note = note or OVERRIDE_REASON_LABELS[reason_code]

    db.add_log("MANUAL", "manual", None, None, performed_by=session.get("guard_name"),
               reason_code=reason_code, note=note)

    if not GATE_INTEGRATION_ENABLED:
        return jsonify({
            "status": "simulated",
            "message": "Gate integration is OFF - action logged, but NO signal was sent to the Pi. "
                       "Set GATE_INTEGRATION_ENABLED to True in app.py to send the real signal.",
        })

    try:
        response = requests.post(
            f"{RASPBERRY_API}/plate_detected",
            json={"plate": "MANUAL", "status": "open", "note": guard_note},
            timeout=GATE_REQUEST_TIMEOUT,
        )
        return jsonify({"status": "success", "message": "Gate opened manually", "pi_response_code": response.status_code})
    except Exception as e:
        return jsonify({"error": f"Failed to reach the Pi: {e}"}), 502


@app.route("/api/stats/today", methods=["GET"])
@login_required_api
def api_stats_today():
    """KPI counters for the top status strip."""
    today = datetime.now(MY_TZ).strftime("%Y-%m-%d")
    logs_today = db.get_logs_by_date(today)

    authorized_today = sum(1 for l in logs_today if l["status"] == "registered")
    unregistered_today = sum(1 for l in logs_today if l["status"] == "unregistered")
    manual_today = sum(1 for l in logs_today if l["status"] == "manual")

    return jsonify({
        "registered_total": len(db.get_all_plates()),
        "authorized_today": authorized_today,
        "unregistered_today": unregistered_today,
        "manual_today": manual_today,
    })


@app.route("/api/kpi/<kind>", methods=["GET"])
@login_required_api
def api_kpi_detail(kind):
    """Backs the clickable KPI cards on the dashboard - today's data for each indicator."""
    today = datetime.now(MY_TZ).strftime("%Y-%m-%d")
    if kind == "registered":
        return jsonify(db.get_all_plates())
    if kind == "authorized":
        return jsonify(db.get_logs_by_date(today, status="registered"))
    if kind == "unauthorized":
        return jsonify(db.get_logs_by_date(today, status="unregistered"))
    if kind == "manual":
        return jsonify(db.get_logs_by_date(today, status="manual"))
    return jsonify({"error": "Unknown KPI kind"}), 400


def _build_team_overview(days=14):
    """Aggregated data across ALL guards - shared by the JSON leaderboard endpoint
    and the Head Guard team PDF export."""
    logs = db.get_logs_since(days=days)

    daily = {}
    guard_stats = {}

    for log in logs:
        day = (log.get("timestamp") or "")[:10]
        status = log.get("status") or "unregistered"
        if day:
            bucket = daily.setdefault(day, {"registered": 0, "unregistered": 0, "manual": 0})
            bucket[status if status in bucket else "unregistered"] += 1

        guard = log.get("performed_by")
        if guard:
            g = guard_stats.setdefault(guard, {"guard": guard, "detections_handled": 0, "manual_overrides": 0, "registrations": 0})
            if status == "manual":
                g["manual_overrides"] += 1
            else:
                g["detections_handled"] += 1

    for p in db.get_all_plates_light():
        guard = p.get("registered_by")
        reg_at = p.get("registered_at") or ""
        # Only count registrations that actually fall within the selected date range,
        # so the leaderboard stays consistent with the daily chart / other totals.
        if guard and reg_at >= (datetime.now(timezone.utc) - timedelta(days=days)).isoformat():
            g = guard_stats.setdefault(guard, {"guard": guard, "detections_handled": 0, "manual_overrides": 0, "registrations": 0})
            g["registrations"] += 1

    daily_series = [{"date": d, **counts} for d, counts in sorted(daily.items())]
    guard_series = sorted(guard_stats.values(), key=lambda g: g["detections_handled"] + g["manual_overrides"] + g["registrations"], reverse=True)

    return {
        "daily": daily_series,
        "by_guard": guard_series,
        "totals": {
            "detections": len([l for l in logs if l.get("status") != "manual"]),
            "manual_overrides": sum(1 for l in logs if l.get("status") == "manual"),
            "unauthorized": sum(1 for l in logs if l.get("status") == "unregistered"),
            "registered_plates": len(db.get_all_plates()),
        },
    }


@app.route("/api/analytics/overview", methods=["GET"])
@head_guard_required_api
def api_analytics_overview():
    """Aggregated data across ALL guards - Head Guard only (used by /team leaderboard)."""
    days = request.args.get("days", 14, type=int)
    return jsonify(_build_team_overview(days))


# ============ ROUTES: TEAM ADMIN (Head Guard only) ============

ALLOWED_IC_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}


def _save_ic_upload(file_storage, label):
    """Save an uploaded IC photo (front/back) to captures/guards/. Returns the
    stored path, or None if no valid file was provided."""
    if not file_storage or not file_storage.filename:
        return None
    ext = file_storage.filename.rsplit(".", 1)[-1].lower() if "." in file_storage.filename else ""
    if ext not in ALLOWED_IC_EXTENSIONS:
        return None
    os.makedirs("captures/guards", exist_ok=True)
    safe_label = secure_filename(label)
    filename = f"{safe_label}_{int(time.time()*1000)}.{ext}"
    path = f"captures/guards/{filename}"
    file_storage.save(path)
    return path


def _save_profile_photo(file_storage, label):
    """Save a guard's profile photo to captures/profiles/ (any signed-in guard may view
    it - it's printed on their ID card; IC copies stay Head Guard only)."""
    if not file_storage or not file_storage.filename:
        return None
    ext = file_storage.filename.rsplit(".", 1)[-1].lower() if "." in file_storage.filename else ""
    if ext not in ALLOWED_IC_EXTENSIONS:
        return None
    os.makedirs("captures/profiles", exist_ok=True)
    filename = f"{secure_filename(label)}_{int(time.time()*1000)}.{ext}"
    path = f"captures/profiles/{filename}"
    file_storage.save(path)
    return path


def _normalize_ic(raw):
    """Malaysian IC -> 'YYMMDD-PB-###G'. Returns (value, error). Empty input is fine (None)."""
    digits = re.sub(r"\D", "", raw or "")
    if not digits:
        return None, None
    if len(digits) != 12:
        return None, "IC number must be 12 digits (e.g. 040512-10-1234)"
    return f"{digits[:6]}-{digits[6:8]}-{digits[8:]}", None


@app.route("/api/admin/guards", methods=["GET", "POST"])
@head_guard_required_api
def api_admin_guards():
    if request.method == "GET":
        return jsonify(db.list_guards())

    # Accepts multipart/form-data (so the Head Guard can attach IC front/back
    # photos in the same request); falls back to JSON if no files are sent.
    data = request.form if request.form else (request.json or {})
    username = (data.get("username") or "").strip().lower()
    full_name = (data.get("full_name") or "").strip()
    password = data.get("password") or ""
    role = (data.get("role") or "guard").strip().lower()
    gender = (data.get("gender") or "").strip() or None
    phone = (data.get("phone") or "").strip() or None
    address = (data.get("address") or "").strip() or None

    if not username or not full_name or not password:
        return jsonify({"error": "Username, full name and password are all required"}), 400
    if role not in ("guard", "head_guard"):
        return jsonify({"error": "Role must be 'guard' or 'head_guard'"}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters"}), 400

    ic_number, ic_err = _normalize_ic(data.get("ic_number"))
    if ic_err:
        return jsonify({"error": ic_err}), 400

    ic_front_path = _save_ic_upload(request.files.get("ic_front"), f"{username}_ic_front")
    ic_back_path = _save_ic_upload(request.files.get("ic_back"), f"{username}_ic_back")
    photo_path = _save_profile_photo(request.files.get("photo"), f"{username}_photo")

    success, error = db.create_guard(
        username, full_name, generate_password_hash(password), role,
        gender=gender, phone=phone, address=address,
        ic_front_path=ic_front_path, ic_back_path=ic_back_path,
        ic_number=ic_number, photo_path=photo_path,
    )
    if not success:
        return jsonify({"error": f"Could not create guard (username may already exist): {error}"}), 409

    return jsonify({"status": "success", "message": f"Guard account '{full_name}' created"})


def _delete_capture_files(*paths):
    """Remove a deleted guard's photo / IC images from disk (personal data). Only ever touches
    files inside captures/."""
    root = os.path.realpath("captures")
    for rel in paths:
        if not rel:
            continue
        full = os.path.realpath(rel)
        if full.startswith(root + os.sep) and os.path.isfile(full):
            try:
                os.remove(full)
            except OSError as e:
                print(f"[delete guard] could not remove {rel}: {e}")


@app.route("/api/admin/guards/<int:guard_id>", methods=["DELETE"])
@head_guard_required_api
def api_admin_delete_guard(guard_id):
    """Permanent removal - the guard, their login history, photo and IC copies are all gone and
    they disappear from Guard team. (The confirmation lives in the Team page.)"""
    if guard_id == session.get("guard_id"):
        return jsonify({"error": "You can't remove your own account while logged in"}), 400
    ok, error, guard = db.purge_guard(guard_id)
    if not ok:
        return jsonify({"error": error}), (404 if error == "Guard not found" else 409)
    _REVOKED_GUARD_IDS.add(guard_id)          # kick them out if they're logged in right now
    _delete_capture_files(guard.get("photo_path"), guard.get("ic_front_path"), guard.get("ic_back_path"))
    return jsonify({"status": "success", "message": f"{guard['full_name']} was removed permanently"})


@app.route("/api/admin/guards/<int:guard_id>/reactivate", methods=["POST"])
@head_guard_required_api
def api_admin_reactivate_guard(guard_id):
    db.reactivate_guard(guard_id)
    _REVOKED_GUARD_IDS.discard(guard_id)
    return jsonify({"status": "success"})


@app.route("/api/admin/guards/<int:guard_id>/details", methods=["POST"])
@head_guard_required_api
def api_admin_update_guard_details(guard_id):
    """Head Guard edits a guard's personal info (name/gender/phone/address) and/or
    re-uploads IC front/back copies. Multipart form - any field left blank/absent
    keeps its existing stored value."""
    guard = db.get_guard_by_id(guard_id)
    if not guard:
        return jsonify({"error": "Guard not found"}), 404

    data = request.form
    updates = {
        "full_name": (data.get("full_name") or "").strip() or None,
        "gender": (data.get("gender") or "").strip() or None,
        "phone": (data.get("phone") or "").strip() or None,
        "address": (data.get("address") or "").strip() or None,
    }

    ic_number, ic_err = _normalize_ic(data.get("ic_number"))
    if ic_err:
        return jsonify({"error": ic_err}), 400
    if ic_number:
        updates["ic_number"] = ic_number
    new_photo = _save_profile_photo(request.files.get("photo"), f"guard{guard_id}_photo")
    if new_photo:
        updates["photo_path"] = new_photo

    new_ic_front = _save_ic_upload(request.files.get("ic_front"), f"guard{guard_id}_ic_front")
    if new_ic_front:
        updates["ic_front_path"] = new_ic_front
    new_ic_back = _save_ic_upload(request.files.get("ic_back"), f"guard{guard_id}_ic_back")
    if new_ic_back:
        updates["ic_back_path"] = new_ic_back

    db.update_guard_details(guard_id, updates)
    return jsonify({"status": "success", "message": "Guard details updated"})


@app.route("/api/admin/guards/<int:guard_id>/reset-password", methods=["POST"])
@head_guard_required_api
def api_admin_reset_password(guard_id):
    data = request.json or {}
    new_password = data.get("password", "")
    if len(new_password) < 6:
        return jsonify({"error": "Password must be at least 6 characters"}), 400

    guard = db.get_guard_by_id(guard_id)
    if not guard:
        return jsonify({"error": "Guard not found"}), 404

    db.reset_guard_password(guard_id, generate_password_hash(new_password))
    return jsonify({"status": "success", "message": f"Password reset for {guard['full_name']}"})


# ============ ROUTES: RESIDENTS (Head Guard only) ============
# Residents are the only people allowed to use the Telegram bot (see
# migrations_telegram.sql). Never hard-deleted - deactivate instead so visitor
# pass / approval history stays intact.

@app.route("/residents")
@head_guard_required_page
def residents_page():
    return render_template("residents.html")


@app.route("/api/admin/residents", methods=["GET", "POST"])
@head_guard_required_api
def api_admin_residents():
    if request.method == "GET":
        return jsonify({
            "residents": db.list_residents(),
            "linkable_plates": db.get_linkable_plates(),
        })

    data = request.json or {}
    full_name = (data.get("full_name") or "").strip()
    house_no = (data.get("house_no") or "").strip()
    phone = (data.get("phone") or "").strip()
    if not full_name or not house_no or not phone:
        return jsonify({"error": "Full name, house no. and phone are all required"}), 400
    if len(db.normalize_phone(phone)) < 10:
        return jsonify({"error": "Please enter a valid phone number (e.g. 012-3456789)"}), 400

    success, error = db.create_resident(full_name, house_no, phone, created_by=session.get("guard_name"))
    if not success:
        return jsonify({"error": f"Could not add resident (phone number may already be registered): {error}"}), 409
    return jsonify({"status": "success", "message": f"Resident '{full_name}' added"})


@app.route("/api/admin/residents/<int:resident_id>", methods=["POST"])
@head_guard_required_api
def api_admin_update_resident(resident_id):
    if not db.get_resident_by_id(resident_id):
        return jsonify({"error": "Resident not found"}), 404
    data = request.json or {}
    phone = (data.get("phone") or "").strip() or None
    if phone and len(db.normalize_phone(phone)) < 10:
        return jsonify({"error": "Please enter a valid phone number (e.g. 012-3456789)"}), 400
    success, error = db.update_resident(
        resident_id,
        full_name=(data.get("full_name") or "").strip() or None,
        house_no=(data.get("house_no") or "").strip() or None,
        phone=phone,
    )
    if not success:
        return jsonify({"error": f"Could not update resident (phone number may already be registered): {error}"}), 409
    return jsonify({"status": "success", "message": "Resident details updated"})


@app.route("/api/admin/residents/<int:resident_id>/deactivate", methods=["POST"])
@head_guard_required_api
def api_admin_deactivate_resident(resident_id):
    db.set_resident_active(resident_id, False)
    return jsonify({"status": "success"})


@app.route("/api/admin/residents/<int:resident_id>/reactivate", methods=["POST"])
@head_guard_required_api
def api_admin_reactivate_resident(resident_id):
    db.set_resident_active(resident_id, True)
    return jsonify({"status": "success"})


@app.route("/api/admin/residents/<int:resident_id>/unlink-telegram", methods=["POST"])
@head_guard_required_api
def api_admin_unlink_resident_telegram(resident_id):
    db.unlink_resident_telegram(resident_id)
    return jsonify({"status": "success"})


@app.route("/api/admin/residents/<int:resident_id>/plates", methods=["POST"])
@head_guard_required_api
def api_admin_set_resident_plates(resident_id):
    if not db.get_resident_by_id(resident_id):
        return jsonify({"error": "Resident not found"}), 404
    plate_ids = (request.json or {}).get("plate_ids") or []
    try:
        db.set_resident_plates(resident_id, plate_ids)
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid plate selection"}), 400
    return jsonify({"status": "success", "message": "Linked plates updated"})


def _build_guard_activity_report(guard_name, guard_id, days=14):
    """
    Shared logic for the personal activity report - used by BOTH:
    - /api/admin/guards/<id>/analytics (Head Guard viewing any guard's activity)
    """
    my_logs = db.get_logs_for_guard(guard_name, days=days)
    my_plates = db.get_plates_for_guard(guard_name, days=days)
    my_sessions = db.get_login_sessions_for_guard(guard_id, days=days)

    # Daily trend: overrides handled + plates registered + login sessions + hours,
    # bucketed by Malaysia calendar day (day of the timestamp/login_at)
    daily = {}

    def _bucket(day):
        return daily.setdefault(day, {
            "manual_overrides": 0, "registrations": 0,
            "login_sessions": 0, "hours_on_duty": 0.0,
        })

    for log in my_logs:
        day = (log.get("timestamp") or "")[:10]
        if day:
            _bucket(day)["manual_overrides"] += 1
    for p in my_plates:
        day = (p.get("registered_at") or "")[:10]
        if day:
            _bucket(day)["registrations"] += 1
    for s in my_sessions:
        day = (s.get("login_at") or "")[:10]
        if day:
            _bucket(day)["login_sessions"] += 1
        if s.get("login_at") and s.get("logout_at"):
            try:
                start = datetime.fromisoformat(s["login_at"])
                end = datetime.fromisoformat(s["logout_at"])
                if day:
                    _bucket(day)["hours_on_duty"] += (end - start).total_seconds() / 3600
            except Exception:
                pass

    for counts in daily.values():
        counts["hours_on_duty"] = round(counts["hours_on_duty"], 1)

    daily_series = [{"date": d, **counts} for d, counts in sorted(daily.items())]

    # Hours on duty - sum of (logout_at - login_at) for closed sessions
    total_seconds = 0
    for s in my_sessions:
        if s.get("login_at") and s.get("logout_at"):
            try:
                start = datetime.fromisoformat(s["login_at"])
                end = datetime.fromisoformat(s["logout_at"])
                total_seconds += (end - start).total_seconds()
            except Exception:
                pass
    hours_on_duty = round(total_seconds / 3600, 1)

    # Recent actions feed (registrations + overrides merged, newest first)
    recent = []
    for log in my_logs:
        reason_code = log.get("reason_code")
        recent.append({
            "type": "override",
            "plate_number": log.get("plate_number"),
            "timestamp": log.get("timestamp"),
            "reason_code": reason_code,
            "reason_label": OVERRIDE_REASON_LABELS.get(reason_code, reason_code),
            "note": log.get("note"),
        })
    for p in my_plates:
        recent.append({
            "type": "registration",
            "plate_number": p.get("plate_number"),
            "timestamp": p.get("registered_at"),
            "is_visitor": p.get("is_visitor"),
        })
    recent.sort(key=lambda r: r.get("timestamp") or "", reverse=True)

    return {
        "guard_name": guard_name,
        "daily": daily_series,
        "totals": {
            "registrations": len(my_plates),
            "manual_overrides": len(my_logs),
            "login_sessions": len(my_sessions),
            "hours_on_duty": hours_on_duty,
        },
        "recent_actions": recent[:15],
    }


_PDF_BRAND_GREEN = rl_colors.HexColor("#1a9459")
_PDF_BRAND_GREEN_DARK = rl_colors.HexColor("#12703f")
_PDF_BRAND_AMBER = rl_colors.HexColor("#c97e15")
_PDF_MUTED = rl_colors.HexColor("#67766c")
_PDF_BORDER = rl_colors.HexColor("#dfe6e1")
_PDF_PANEL_SOFT = rl_colors.HexColor("#f6f8f6")
_PDF_TEXT = rl_colors.HexColor("#17241c")


def _pdf_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="BrandTitle", fontSize=18, leading=22, fontName="Helvetica-Bold", textColor=_PDF_TEXT))
    styles.add(ParagraphStyle(name="BrandSub", fontSize=9.5, leading=13, textColor=_PDF_MUTED))
    styles.add(ParagraphStyle(name="SectionHeading", fontSize=11.5, leading=14, fontName="Helvetica-Bold", textColor=_PDF_TEXT, spaceBefore=14, spaceAfter=6))
    styles.add(ParagraphStyle(name="KpiNum", fontSize=17, leading=20, fontName="Helvetica-Bold", textColor=_PDF_TEXT, alignment=TA_CENTER))
    styles.add(ParagraphStyle(name="KpiLabel", fontSize=7.7, leading=10, textColor=_PDF_MUTED, alignment=TA_CENTER))
    return styles


def _pdf_header(story, styles, subtitle):
    header_tbl = Table([[
        Paragraph("PLATE CHECKPOINT", styles["BrandTitle"]),
        Paragraph(f"Generated {datetime.now(MY_TZ).strftime('%d %b %Y, %H:%M')} (MYT)", styles["BrandSub"]),
    ]], colWidths=[110 * mm, 64 * mm])
    header_tbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM"), ("ALIGN", (1, 0), (1, 0), "RIGHT")]))
    story.append(header_tbl)
    story.append(Paragraph(subtitle, styles["BrandSub"]))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", thickness=1.2, color=_PDF_BRAND_GREEN, spaceAfter=12))


def _pdf_kpi_row(story, styles, cells):
    """cells: list of (number, label) tuples - up to 4 across."""
    def cell(num, label):
        return [Paragraph(str(num), styles["KpiNum"]), Paragraph(label, styles["KpiLabel"])]

    width = 174 / max(len(cells), 1)
    tbl = Table([[cell(n, l) for n, l in cells]], colWidths=[width * mm] * len(cells))
    tbl.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.8, _PDF_BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.8, _PDF_BORDER),
        ("BACKGROUND", (0, 0), (-1, -1), _PDF_PANEL_SOFT),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 10), ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(tbl)


def _pdf_activity_chart(story, styles, daily):
    if not daily:
        return
    story.append(Paragraph("Activity Over Time", styles["SectionHeading"]))
    drawing = Drawing(478, 150)
    chart = VerticalBarChart()
    chart.x, chart.y, chart.height, chart.width = 30, 20, 110, 420
    chart.data = [[d.get("registrations", 0) for d in daily], [d.get("manual_overrides", 0) for d in daily]]
    chart.categoryAxis.categoryNames = [d["date"][5:] for d in daily]
    chart.categoryAxis.labels.fontSize = 6.5
    chart.valueAxis.valueMin = 0
    chart.valueAxis.labels.fontSize = 7
    chart.bars[0].fillColor = _PDF_BRAND_GREEN
    chart.bars[1].fillColor = _PDF_BRAND_AMBER
    chart.barSpacing = 1.5
    chart.groupSpacing = 6
    drawing.add(chart)
    legend = Legend()
    legend.x, legend.y, legend.fontSize, legend.dx, legend.dy = 380, 140, 7, 6, 6
    legend.colorNamePairs = [(_PDF_BRAND_GREEN, "Registrations"), (_PDF_BRAND_AMBER, "Overrides")]
    drawing.add(legend)
    story.append(drawing)


def _build_activity_pdf(guard_name, role_label, days, report):
    """Personal activity report PDF - used for both a guard's own report and a
    Head Guard pulling one specific guard's report."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=16 * mm,
                             leftMargin=16 * mm, rightMargin=16 * mm,
                             title=f"Activity Report - {guard_name}")
    styles = _pdf_styles()
    story = []
    _pdf_header(story, styles, f"Activity Report &middot; {guard_name} ({role_label}) &middot; Last {days} days")

    totals = report["totals"]
    _pdf_kpi_row(story, styles, [
        (totals["registrations"], "PLATES REGISTERED"),
        (totals["manual_overrides"], "MANUAL OVERRIDES"),
        (totals["login_sessions"], "LOGIN SESSIONS"),
        (totals["hours_on_duty"], "HOURS ON DUTY"),
    ])

    _pdf_activity_chart(story, styles, report["daily"])

    story.append(Paragraph("Recent Activity", styles["SectionHeading"]))
    table_data = [["Plate", "Type", "Reason / Note", "Timestamp (MYT)"]]
    for a in report["recent_actions"][:40]:
        ts = a.get("timestamp") or ""
        try:
            ts_local = datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(MY_TZ).strftime("%d %b, %H:%M")
        except Exception:
            ts_local = ts[:16].replace("T", " ")
        if a["type"] == "registration":
            reason = "Visitor pass" if a.get("is_visitor") else "-"
        else:
            reason = a.get("reason_label") or "-"
            if a.get("note"):
                reason += f" ({a['note']})"
        table_data.append([
            a.get("plate_number") or "MANUAL",
            "Registration" if a["type"] == "registration" else "Manual Override",
            reason,
            ts_local,
        ])
    if len(table_data) == 1:
        table_data.append(["-", "No activity in this range", "-", "-"])
    act_tbl = Table(table_data, colWidths=[28 * mm, 32 * mm, 68 * mm, 46 * mm], repeatRows=1)
    act_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), _PDF_BRAND_GREEN_DARK),
        ("TEXTCOLOR", (0, 0), (-1, 0), rl_colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.2),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [rl_colors.white, _PDF_PANEL_SOFT]),
        ("GRID", (0, 0), (-1, -1), 0.5, _PDF_BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(act_tbl)

    doc.build(story)
    return buf.getvalue()


def _build_team_pdf(days, overview):
    """Team-wide leaderboard PDF - Head Guard only."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=18 * mm, bottomMargin=16 * mm,
                             leftMargin=16 * mm, rightMargin=16 * mm, title="Team Activity Report")
    styles = _pdf_styles()
    story = []
    _pdf_header(story, styles, f"Team Activity Report &middot; All guards &middot; Last {days} days")

    totals = overview["totals"]
    _pdf_kpi_row(story, styles, [
        (totals["registered_plates"], "REGISTERED PLATES"),
        (totals["detections"], "DETECTIONS"),
        (totals["unauthorized"], "UNAUTHORIZED"),
        (totals["manual_overrides"], "MANUAL OVERRIDES"),
    ])

    story.append(Paragraph("Guard Leaderboard", styles["SectionHeading"]))
    table_data = [["Guard", "Registrations", "Overrides", "Detections Handled", "Total"]]
    for g in overview["by_guard"]:
        total = g["detections_handled"] + g["manual_overrides"] + g["registrations"]
        table_data.append([g["guard"], str(g["registrations"]), str(g["manual_overrides"]), str(g["detections_handled"]), str(total)])
    if len(table_data) == 1:
        table_data.append(["-", "-", "-", "-", "-"])
    lb_tbl = Table(table_data, colWidths=[54 * mm, 30 * mm, 28 * mm, 38 * mm, 24 * mm], repeatRows=1)
    lb_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), _PDF_BRAND_GREEN_DARK),
        ("TEXTCOLOR", (0, 0), (-1, 0), rl_colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [rl_colors.white, _PDF_PANEL_SOFT]),
        ("GRID", (0, 0), (-1, -1), 0.5, _PDF_BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(lb_tbl)

    _pdf_activity_chart(story, styles, [
        {"date": d["date"], "registrations": d.get("registered", 0), "manual_overrides": d.get("manual", 0)}
        for d in overview["daily"]
    ])

    doc.build(story)
    return buf.getvalue()


def _pdf_response(pdf_bytes, filename):
    return Response(pdf_bytes, mimetype="application/pdf",
                     headers={"Content-Disposition": f"attachment; filename={filename}"})


@app.route("/api/admin/guards/<int:guard_id>/report/pdf", methods=["GET"])
@head_guard_required_api
def api_admin_guard_report_pdf(guard_id):
    """Head Guard downloading ONE guard's activity report as a PDF."""
    days = request.args.get("days", 14, type=int)
    guard = db.get_guard_by_id(guard_id)
    if not guard:
        return jsonify({"error": "Guard not found"}), 404
    report = _build_guard_activity_report(guard["full_name"], guard_id, days=days)
    pdf_bytes = _build_activity_pdf(guard["full_name"], guard["role"].replace("_", " ").title(), days, report)
    safe_name = guard["full_name"].strip().replace(" ", "_") or "guard"
    filename = f"{safe_name}_report_{datetime.now(MY_TZ).strftime('%Y%m%d_%H%M')}.pdf"
    return _pdf_response(pdf_bytes, filename)


@app.route("/api/admin/reports/pdf/team", methods=["GET"])
@head_guard_required_api
def api_admin_team_report_pdf():
    """Head Guard downloading the whole-team leaderboard report as a PDF."""
    days = request.args.get("days", 14, type=int)
    overview = _build_team_overview(days)
    pdf_bytes = _build_team_pdf(days, overview)
    filename = f"team_report_{datetime.now(MY_TZ).strftime('%Y%m%d_%H%M')}.pdf"
    return _pdf_response(pdf_bytes, filename)


@app.route("/api/alerts", methods=["GET"])
@login_required_api
def api_alerts():
    """List recent repeat-visit alerts (any logged-in guard can view)."""
    acknowledged_param = request.args.get("acknowledged")
    acknowledged = None
    if acknowledged_param is not None:
        acknowledged = acknowledged_param.lower() == "true"
    return jsonify(db.get_recent_alerts(limit=50, acknowledged=acknowledged))


@app.route("/api/alerts/<int:alert_id>/acknowledge", methods=["POST"])
@login_required_api
def api_acknowledge_alert(alert_id):
    db.acknowledge_alert(alert_id, by=session.get("guard_name"))
    return jsonify({"status": "success"})


@app.route("/api/admin/guards/<int:guard_id>/analytics", methods=["GET"])
@head_guard_required_api
def api_admin_guard_analytics(guard_id):
    """Head Guard viewing ANY individual guard's full activity report (their 'profile')."""
    days = request.args.get("days", 14, type=int)
    guard = db.get_guard_by_id(guard_id)
    if not guard:
        return jsonify({"error": "Guard not found"}), 404

    report = _build_guard_activity_report(guard["full_name"], guard_id, days=days)
    report["username"] = guard["username"]
    report["role"] = guard["role"]
    return jsonify(report)


@app.route("/api/logs/export", methods=["GET"])
@login_required_api
def api_logs_export():
    """
    Auto-generate a CSV of ALL detection logs (auto-detections + manual
    overrides) that fell within the currently logged-in guard's OWN shift
    windows (login_at -> logout_at, or now if the shift is still open) -
    not just the rows that have performed_by set to them. Same column
    layout the importer expects, so an exported file can be re-imported
    as-is.
    """
    import csv
    import io

    def _parse_ts(ts_str):
        if not ts_str:
            return None
        try:
            return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        except Exception:
            return None

    days = request.args.get("days", 14, type=int)
    guard_id = session.get("guard_id")
    guard_name = session.get("guard_name")

    sessions = db.get_login_sessions_for_guard(guard_id, days=days)
    windows = []
    for s in sessions:
        start = _parse_ts(s.get("login_at"))
        end = _parse_ts(s.get("logout_at")) or datetime.now(timezone.utc)
        if start:
            windows.append((start, end))

    if not windows:
        return jsonify({
            "error": f"Takde rekod shift (login) untuk anda dalam {days} hari lepas, "
                     "jadi tak tahu nak ambik detection dalam tempoh mana."
        }), 404

    all_logs = db.get_logs_since(days=days, limit=5000)
    my_logs = []
    for log in all_logs:
        ts = _parse_ts(log.get("timestamp"))
        if ts and any(start <= ts <= end for start, end in windows):
            my_logs.append(log)
    my_logs.sort(key=lambda l: l.get("timestamp") or "", reverse=True)

    if not my_logs:
        return jsonify({
            "error": f"Tiada detection log dalam tempoh shift anda ({days} hari lepas)."
        }), 404

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["plate_number", "status", "timestamp", "confidence", "performed_by"])
    for log in my_logs:
        confidence = log.get("confidence")
        writer.writerow([
            log.get("plate_number", ""),
            log.get("status", ""),
            log.get("timestamp", ""),
            confidence if confidence is not None else "",
            log.get("performed_by") or guard_name,
        ])

    safe_name = (guard_name or "guard").strip().replace(" ", "_") or "guard"
    filename = f"{safe_name}_logs_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@app.route("/api/logs/import", methods=["POST"])
@login_required_api
def api_logs_import():
    """
    Import detection logs from a CSV file.
    Expected headers (case-insensitive): plate_number, status, timestamp, confidence, performed_by
    Only 'plate_number' is required. 'status' defaults to 'unregistered' if missing/invalid.
    'timestamp' should be ISO format (e.g. 2026-08-14T09:30:00) - defaults to now if missing.
    """
    import csv
    import io

    if "file" not in request.files:
        return jsonify({"error": "No CSV file uploaded (expected form field 'file')"}), 400

    f = request.files["file"]
    try:
        raw = f.read().decode("utf-8-sig")
    except Exception:
        return jsonify({"error": "Could not read the file as UTF-8 text"}), 400

    reader = csv.DictReader(io.StringIO(raw))
    if not reader.fieldnames:
        return jsonify({"error": "CSV appears to be empty"}), 400

    fieldmap = {name.strip().lower(): name for name in reader.fieldnames}
    if "plate_number" not in fieldmap:
        return jsonify({"error": "CSV must have a 'plate_number' column"}), 400

    valid_statuses = {"registered", "unregistered", "manual"}
    rows = []
    skipped = 0
    for row in reader:
        plate_number = (row.get(fieldmap["plate_number"]) or "").strip().upper()
        if not plate_number:
            skipped += 1
            continue

        status = (row.get(fieldmap.get("status", "")) or "").strip().lower()
        if status not in valid_statuses:
            status = "unregistered"

        timestamp = (row.get(fieldmap.get("timestamp", "")) or "").strip() or None
        confidence_raw = (row.get(fieldmap.get("confidence", "")) or "").strip()
        try:
            confidence = float(confidence_raw) if confidence_raw else None
        except ValueError:
            confidence = None
        performed_by = (row.get(fieldmap.get("performed_by", "")) or "").strip() or None

        rows.append({
            "plate_number": db.normalize_plate(plate_number),
            "status": status,
            "snapshot_path": None,
            "confidence": confidence,
            "performed_by": performed_by,
            "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
        })

    if not rows:
        return jsonify({"error": "No valid rows found in the CSV"}), 400

    inserted = db.add_logs_bulk(rows)
    return jsonify({"status": "success", "message": f"Imported {inserted} log entr{'y' if inserted == 1 else 'ies'}" + (f" ({skipped} skipped)" if skipped else ""), "imported": inserted, "skipped": skipped})


# --- Pi reachability (read-only TCP connect; never sends a gate command) ---
GATE_PROBE_ENABLED = True       # set False to skip the reachability check entirely
GATE_PROBE_INTERVAL = 15        # seconds between checks (result is cached)
_gate_probe = {"reachable": None, "checked_at": None, "running": False}
_gate_probe_lock = threading.Lock()


def _gate_probe_worker():
    ok = False
    try:
        with socket.create_connection((RASPBERRY_PI_IP, 5000), timeout=0.8):
            ok = True
    except OSError:
        ok = False
    with _gate_probe_lock:
        _gate_probe.update(reachable=ok, checked_at=time.time(), running=False)


def gate_link_status():
    """Cached Pi reachability. None = not checked yet / probe disabled. Runs in a
    background thread so /api/system/status never blocks on a slow or offline Pi."""
    if not (GATE_INTEGRATION_ENABLED and GATE_PROBE_ENABLED):
        return {"reachable": None, "checked_at": None}
    with _gate_probe_lock:
        stale = _gate_probe["checked_at"] is None or time.time() - _gate_probe["checked_at"] >= GATE_PROBE_INTERVAL
        if stale and not _gate_probe["running"]:
            _gate_probe["running"] = True
            threading.Thread(target=_gate_probe_worker, daemon=True).start()
        checked = _gate_probe["checked_at"]
        return {"reachable": _gate_probe["reachable"],
                "checked_at": datetime.fromtimestamp(checked, MY_TZ).isoformat(timespec="seconds") if checked else None}


def _system_status_payload():
    link = gate_link_status()
    return {
        "camera_online": camera_is_online(),
        "gate_integration": GATE_INTEGRATION_ENABLED,
        "scan_mode": SCAN_MODE,
        "gate_reachable": link["reachable"],          # additive field (new)
        "gate_checked_at": link["checked_at"],        # additive field (new)
    }


@app.route("/api/system/status", methods=["GET"])
@login_required_api
def api_system_status():
    return jsonify(_system_status_payload())


# ============ MOTORCYCLE QR PASSES ============
# Motorcycles only carry a REAR plate, so the gate camera (which faces the front of the
# vehicle) can't read them. Instead the system issues a QR sticker per motorcycle:
#   1. Guard registers the bike on /motor-passes -> system makes a random-token QR (+ printable card).
#   2. Sticker goes on the bike.
#   3. At the gate the guard scans the QR with the phone camera -> /scan/<token> (guard login required).
#   4. The page shows plate / owner / house / status. Guard compares the plate on the bike, ticks the
#      confirmation and presses "Open gate" -> logged as a manual override (reason: motor_qr).
# The QR carries only a token, never the plate, so a forged QR is simply "not found" and a lost
# sticker can be revoked or replaced. Scanning alone never opens the gate - only a logged-in guard can.
import qrcode
import qrcode.image.svg

MOTOR_VALID_DAYS_MAX = 3650
_SCAN_PATH_RE = re.compile(r"/scan/[A-Za-z0-9-]{1,32}")


def _lan_ip():
    """Best-effort LAN IP of this laptop (what a phone on the same WiFi/hotspot can reach)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # UDP connect: picks the outgoing interface, sends nothing
        return s.getsockname()[0]
    except Exception:
        return None
    finally:
        s.close()


def _scan_base_url():
    """Base URL baked into the QR. The phone has to be able to open it.
    Priority: PUBLIC_BASE_URL in .env (stable - recommended for printed stickers) >
    the address the dashboard was opened with (if not localhost) > this laptop's LAN IP."""
    env = (os.environ.get("PUBLIC_BASE_URL") or "").strip().rstrip("/")
    if env.startswith(("http://", "https://")):
        return env
    host, _, port = request.host.partition(":")
    if host not in ("localhost", "127.0.0.1", "[::1]", "::1"):
        return request.host_url.rstrip("/")
    ip = _lan_ip()
    if ip:
        return f"http://{ip}:{port or 5050}"
    return request.host_url.rstrip("/")


def _motor_state(row, now=None):
    """'valid' | 'inactive' | 'expired' | 'unknown' for a motor_passes row (None = unknown)."""
    if not row:
        return "unknown"
    if not row.get("is_active"):
        return "inactive"
    if db.motor_pass_is_expired(row, now):
        return "expired"
    return "valid"


def _motor_pass_public(row, base_url, now=None):
    state = _motor_state(row, now)
    return {
        "id": row["id"],
        "plate_number": row["plate_number"],
        "owner_name": row.get("owner_name"),
        "house_no": row.get("house_no"),
        "state": "revoked" if state == "inactive" else state,   # valid | revoked | expired
        "expires_at": row.get("expires_at"),
        "created_by": row.get("created_by"),
        "created_at": row.get("created_at"),
        "deactivated_by": row.get("deactivated_by"),
        "code": db.format_motor_token(row["token"]),
        "scan_url": f"{base_url}/scan/{row['token']}",
    }


def _clean_str(value, max_len):
    return " ".join(str(value or "").split())[:max_len] or None


def _motor_schema_error(e):
    print(f"[motor_pass] database error: {e}")
    return jsonify({"error": "Could not read the motor_passes table. Run migrations_motor_pass.sql "
                             "in the Supabase SQL Editor first."}), 500


@app.route("/motor-passes")
@login_required_page
def motor_passes_page():
    return render_template("motor_passes.html")


@app.route("/api/motor-passes", methods=["GET", "POST"])
@login_required_api
def api_motor_passes():
    base_url = _scan_base_url()

    if request.method == "GET":
        try:
            rows = db.list_motor_passes()
            events = db.get_recent_motor_pass_events(15)
        except Exception as e:
            return _motor_schema_error(e)
        now = datetime.now(timezone.utc)
        by_id = {r["id"]: r for r in rows}
        for ev in events:
            ev["owner_name"] = (by_id.get(ev.get("pass_id")) or {}).get("owner_name")
        return jsonify({"passes": [_motor_pass_public(r, base_url, now) for r in rows],
                        "events": events, "base_url": base_url,
                        "base_url_is_custom": bool((os.environ.get("PUBLIC_BASE_URL") or "").strip())})

    data = request.json or {}
    plate = db.normalize_plate(data.get("plate_number"))
    owner = _clean_str(data.get("owner_name"), 80)
    house = _clean_str(data.get("house_no"), 60)
    if not re.fullmatch(r"[A-Z0-9]{2,12}", plate or ""):
        return jsonify({"error": "Enter a valid plate number (letters and digits, 2-12 characters)"}), 400
    if not owner:
        return jsonify({"error": "Owner name is required"}), 400
    bl = _banned_entry(plate)
    if bl:
        return jsonify({"error": f"This plate is blacklisted ({bl.get('reason')}). It cannot get a QR pass."}), 409

    expires_at = None
    raw_days = data.get("valid_days")
    if raw_days not in (None, "", 0, "0"):
        try:
            days = int(raw_days)
        except (TypeError, ValueError):
            return jsonify({"error": "Validity must be a number of days"}), 400
        if not 1 <= days <= MOTOR_VALID_DAYS_MAX:
            return jsonify({"error": f"Validity must be between 1 and {MOTOR_VALID_DAYS_MAX} days"}), 400
        expires_at = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()

    try:
        existing = db.get_active_motor_pass_for_plate(plate)
        if existing:
            return jsonify({"error": f"{plate} already has an active QR pass. Use 'Replace QR' on it "
                                     "if the sticker was lost, or revoke it first.",
                            "existing_id": existing["id"]}), 409
        row = db.create_motor_pass(plate, owner, house, expires_at, created_by=session.get("guard_name"))
    except Exception as e:
        return _motor_schema_error(e)
    return jsonify({"status": "success", "pass": _motor_pass_public(row, base_url)})


def _pass_action(pass_id, fn):
    try:
        row = db.get_motor_pass(pass_id)
        if not row:
            return None, (jsonify({"error": "QR pass not found"}), 404)
        fn(row)
        return db.get_motor_pass(pass_id), None
    except Exception as e:
        return None, _motor_schema_error(e)


@app.route("/api/motor-passes/<int:pass_id>/deactivate", methods=["POST"])
@login_required_api
def api_motor_pass_deactivate(pass_id):
    row, err = _pass_action(pass_id, lambda r: db.set_motor_pass_active(pass_id, False, by=session.get("guard_name")))
    return err or jsonify({"status": "success", "pass": _motor_pass_public(row, _scan_base_url())})


@app.route("/api/motor-passes/<int:pass_id>/reactivate", methods=["POST"])
@login_required_api
def api_motor_pass_reactivate(pass_id):
    try:
        row = db.get_motor_pass(pass_id)
        if not row:
            return jsonify({"error": "QR pass not found"}), 404
        other = db.get_active_motor_pass_for_plate(row["plate_number"])
        if other and other["id"] != pass_id:
            return jsonify({"error": f"{row['plate_number']} already has another active QR pass"}), 409
        db.set_motor_pass_active(pass_id, True)
        row = db.get_motor_pass(pass_id)
    except Exception as e:
        return _motor_schema_error(e)
    return jsonify({"status": "success", "pass": _motor_pass_public(row, _scan_base_url())})


@app.route("/api/motor-passes/<int:pass_id>/rotate", methods=["POST"])
@login_required_api
def api_motor_pass_rotate(pass_id):
    """Replace a lost / damaged / stolen sticker: new token, the old printed QR stops working at once."""
    row, err = _pass_action(pass_id, lambda r: db.rotate_motor_pass_token(pass_id))
    if err:
        return err
    db.log_motor_pass_event(pass_id, "qr_replaced", row["plate_number"], session.get("guard_name"))
    return jsonify({"status": "success", "pass": _motor_pass_public(row, _scan_base_url())})


def _qr_svg_bytes(text):
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=3)
    qr.add_data(text)
    qr.make(fit=True)
    buf = io.BytesIO()
    qr.make_image(image_factory=qrcode.image.svg.SvgPathImage).save(buf)
    return buf.getvalue()


@app.route("/motor-passes/<int:pass_id>/qr.svg")
@login_required_api
def motor_pass_qr_svg(pass_id):
    try:
        row = db.get_motor_pass(pass_id)
    except Exception as e:
        return _motor_schema_error(e)
    if not row:
        return jsonify({"error": "QR pass not found"}), 404
    resp = Response(_qr_svg_bytes(f"{_scan_base_url()}/scan/{row['token']}"), mimetype="image/svg+xml")
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/motor-passes/<int:pass_id>/print")
@login_required_page
def motor_pass_print(pass_id):
    try:
        row = db.get_motor_pass(pass_id)
    except Exception:
        row = None
    if not row:
        return redirect(url_for("motor_passes_page"))
    return render_template("motor_pass_print.html", p=_motor_pass_public(row, _scan_base_url()))


@app.route("/scan/<token>")
def motor_scan_page(token):
    """Opened by the guard's phone camera. Needs a guard login; after logging in the guard is
    returned here. Records the scan, then shows plate / owner / status for the guard to verify."""
    if not session.get("guard_id"):
        path = request.path
        if _SCAN_PATH_RE.fullmatch(path):
            session["post_login_next"] = path
        return redirect(url_for("login_page"))

    guard = session.get("guard_name")
    row, error = None, None
    try:
        row = db.get_motor_pass_by_token(token)
    except Exception as e:
        print(f"[motor_pass] scan lookup failed: {e}")
        error = "Could not read the QR pass table. Ask the Head Guard to run migrations_motor_pass.sql."

    state = "error" if error else _motor_state(row)
    if not error:
        note = None if row else f"unrecognised code starting {db.normalize_motor_token(token)[:4] or '?'}"
        db.log_motor_pass_event(row["id"] if row else None, f"scan_{state}",
                                row["plate_number"] if row else None, guard, note)
    last_entry = db.get_last_motor_pass_entry(row["id"]) if row and state == "valid" else None
    return render_template("scan.html", state=state, error=error, token=db.normalize_motor_token(token),
                           p=_motor_pass_public(row, _scan_base_url()) if row else None,
                           last_entry=last_entry, guard_name=guard)


@app.route("/api/motor-passes/open", methods=["POST"])
@login_required_api
def api_motor_pass_open():
    """Guard confirmed the plate on the bike matches the QR page and pressed 'Open gate'."""
    data = request.json or {}
    if data.get("confirmed") is not True:
        return jsonify({"error": "Tick the box to confirm the plate on the motorcycle matches the QR pass"}), 400
    guard = session.get("guard_name")
    try:
        row = db.get_motor_pass_by_token(data.get("token"))
    except Exception as e:
        return _motor_schema_error(e)
    state = _motor_state(row)
    if state != "valid":
        msg = {"unknown": "This QR code is not registered", "inactive": "This QR pass has been revoked",
               "expired": "This QR pass has expired"}[state]
        return jsonify({"error": msg, "state": state}), 409

    plate = row["plate_number"]
    guard_note = f"Motorcycle QR pass #{row['id']} - {plate}"
    if not GATE_INTEGRATION_ENABLED:
        result = {"status": "simulated",
                  "message": "Gate integration is OFF - entry logged, but NO signal was sent to the Pi."}
    else:
        try:
            response = requests.post(f"{RASPBERRY_API}/plate_detected",
                                     json={"plate": "MANUAL", "status": "open", "note": guard_note},
                                     timeout=GATE_REQUEST_TIMEOUT)
            result = {"status": "success", "message": "Gate opened", "pi_response_code": response.status_code}
        except Exception as e:
            db.log_motor_pass_event(row["id"], "open_failed", plate, guard, f"Pi unreachable: {e}"[:200])
            return jsonify({"error": f"Failed to reach the Pi: {e}. Open the gate with Manual Override on the dashboard."}), 502

    # Same audit trail as a dashboard manual override (status 'manual'), but with the real plate.
    db.add_log(plate, "manual", None, None, performed_by=guard, reason_code="motor_qr",
               note=f"QR pass #{row['id']} - {row.get('owner_name') or 'owner n/a'}"
                    + (f", {row['house_no']}" if row.get("house_no") else ""))
    db.log_motor_pass_event(row["id"], "opened", plate, guard)
    try:
        db.add_traffic("in", plate, "motor_qr", guard)
    except Exception as e:
        print(f"[traffic] could not record motorcycle entry for {plate}: {e}")
    result["plate_number"] = plate
    return jsonify(result)


def check_motor_pass_schema():
    """Startup sanity check - Motor QR Pass page needs migrations_motor_pass.sql."""
    try:
        db.supabase.table("motor_passes").select("id").limit(1).execute()
        db.supabase.table("motor_pass_events").select("id").limit(1).execute()
        print("[startup] motor_passes + motor_pass_events: OK")
    except Exception as e:
        print("=" * 60)
        print("[STARTUP WARNING] Could not read 'motor_passes' / 'motor_pass_events' from Supabase.")
        print(f"  Error: {e}")
        print("  The Motor QR Pass page will NOT work until you run")
        print("  migrations_motor_pass.sql in the Supabase SQL Editor.")
        print("=" * 60)


# ============ ENTRY / EXIT TRACKING + ANTI-PASSBACK ============

_exit_lock = threading.Lock()
_last_exit_ts = [0.0]


def _banned_entry(plate_number):
    """Exact 'ban' match on the blacklist, else None. (A near-match never blocks.)"""
    try:
        bl = db.get_blacklist_match(plate_number)
    except Exception:
        return None
    return bl if (bl and not bl.get("near") and bl.get("severity") == "ban") else None


@app.route("/api/gate/exit", methods=["POST"])
def api_gate_exit():
    """Called by the Raspberry Pi when the exit ultrasonic sensor sees a vehicle leave.
    The sensor cannot read plates, so only 'a vehicle left' is recorded.
    Auth: X-Gate-Key header must equal GATE_API_KEY (.env). If no key is configured the
    request is only accepted from the Pi's own IP address."""
    if GATE_API_KEY:
        if not hmac.compare_digest(request.headers.get("X-Gate-Key", ""), GATE_API_KEY):
            return jsonify({"error": "unauthorized"}), 401
    elif request.remote_addr != RASPBERRY_PI_IP:
        return jsonify({"error": "unauthorized"}), 403
    with _exit_lock:
        now = time.time()
        if now - _last_exit_ts[0] < EXIT_DEBOUNCE_SECONDS:
            return jsonify({"status": "ignored", "reason": "duplicate signal"})
        _last_exit_ts[0] = now
    try:
        db.add_traffic("out", None, "sensor", "exit sensor")
    except Exception as e:
        print(f"[traffic] could not record exit: {e}")
        return jsonify({"error": "could not record exit"}), 500
    return jsonify({"status": "success"})


@app.route("/api/presence", methods=["GET"])
@login_required_api
def api_presence():
    try:
        summary = db.get_presence_summary()
        summary["recent"] = db.get_recent_traffic(15)
    except Exception as e:
        print(f"[presence] {e}")
        return jsonify({"error": "Presence tracking needs migrations_security_rules.sql (gate_traffic table)."}), 500
    summary["anti_passback_mode"] = ANTI_PASSBACK_MODE
    summary["exit_source"] = "ultrasonic sensor (no plate)"
    return jsonify(summary)


@app.route("/api/presence/exit", methods=["POST"])
@login_required_api
def api_presence_exit():
    """Guard saw a vehicle leave that the sensor missed -> record one exit by hand."""
    try:
        db.add_traffic("out", None, "manual", session.get("guard_name"),
                       note=_clean_str((request.json or {}).get("note"), 120))
    except Exception as e:
        print(f"[presence] manual exit failed: {e}")
        return jsonify({"error": "Could not record the exit."}), 500
    return jsonify({"status": "success"})


@app.route("/api/admin/presence/reset", methods=["POST"])
@head_guard_required_api
def api_presence_reset():
    """Head Guard starts a fresh baseline (e.g. after sensor trouble): 'inside now' returns to 0."""
    try:
        db.add_traffic("reset", None, "manual", session.get("guard_name"),
                       note=_clean_str((request.json or {}).get("note"), 120))
    except Exception as e:
        print(f"[presence] reset failed: {e}")
        return jsonify({"error": "Could not reset the counter."}), 500
    return jsonify({"status": "success"})


@app.route("/api/alerts/<int:alert_id>/release", methods=["POST"])
@login_required_api
def api_alert_release(alert_id):
    """Guard verified the car held by anti-passback and lets it in. Opens the gate, writes a
    manual-override log + an entry, and marks the alert reviewed - all under the guard's name."""
    try:
        alert = db.get_alert(alert_id)
    except Exception as e:
        print(f"[release] {e}")
        return jsonify({"error": "Could not read the alert."}), 500
    if not alert or alert.get("alert_type") != "passback":
        return jsonify({"error": "Only an anti-passback hold can be released."}), 400
    if alert.get("acknowledged"):
        return jsonify({"error": "This alert was already handled."}), 409
    plate = alert["plate_number"]
    if _banned_entry(plate):
        return jsonify({"error": "This plate is blacklisted - it cannot be released."}), 409
    guard = session.get("guard_name")
    if GATE_INTEGRATION_ENABLED:
        try:
            requests.post(f"{RASPBERRY_API}/plate_detected", json={"plate": plate, "status": "open"},
                          timeout=GATE_REQUEST_TIMEOUT)
        except Exception as e:
            return jsonify({"error": f"Failed to reach the Pi: {e}. Use Manual Override instead."}), 502
    db.add_log(plate, "manual", None, None, performed_by=guard, reason_code="anti_passback",
               note=("Verified by guard. " + (alert.get("detail") or ""))[:300])
    try:
        db.add_traffic("in", plate, "guard_verified", guard, note="released after anti-passback hold")
    except Exception as e:
        print(f"[traffic] {e}")
    db.acknowledge_alert(alert_id, by=guard)
    return jsonify({"status": "success", "plate_number": plate})


# ============ BLACKLIST / WATCHLIST ============

@app.route("/blacklist")
@login_required_page
def blacklist_page():
    return render_template("blacklist.html", is_head=(session.get("guard_role") == "head_guard"))


@app.route("/api/blacklist", methods=["GET"])
@login_required_api
def api_blacklist_list():
    include_inactive = request.args.get("all") == "1" and session.get("guard_role") == "head_guard"
    try:
        return jsonify(db.list_blacklist(include_inactive=include_inactive))
    except Exception as e:
        print(f"[blacklist] {e}")
        return jsonify({"error": "Blacklist needs migrations_security_rules.sql."}), 500


@app.route("/api/admin/blacklist", methods=["POST"])
@head_guard_required_api
def api_blacklist_add():
    data = request.json or {}
    plate = db.normalize_plate(data.get("plate_number"))
    reason = _clean_str(data.get("reason"), 200)
    severity = data.get("severity") if data.get("severity") in ("ban", "watch") else "ban"
    if not re.fullmatch(r"[A-Z0-9]{2,12}", plate or ""):
        return jsonify({"error": "Enter a valid plate number (letters and digits, 2-12 characters)"}), 400
    if not reason:
        return jsonify({"error": "A reason is required so the guards know why"}), 400
    expires_at = None
    raw_days = data.get("expiry_days")
    if raw_days not in (None, "", 0, "0"):
        try:
            days = int(raw_days)
        except (TypeError, ValueError):
            return jsonify({"error": "Expiry must be a whole number of days"}), 400
        if not 1 <= days <= 3650:
            return jsonify({"error": "Expiry must be between 1 and 3650 days"}), 400
        expires_at = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()
    try:
        row, err = db.add_blacklist(plate, reason, severity, session.get("guard_name"), expires_at)
    except Exception as e:
        print(f"[blacklist] {e}")
        return jsonify({"error": "Blacklist needs migrations_security_rules.sql."}), 500
    if err:
        return jsonify({"error": err}), 409
    return jsonify({"status": "success", "entry": row})


@app.route("/api/admin/blacklist/<int:entry_id>", methods=["DELETE"])
@head_guard_required_api
def api_blacklist_remove(entry_id):
    try:
        row = db.deactivate_blacklist(entry_id, session.get("guard_name"))
    except Exception as e:
        print(f"[blacklist] {e}")
        return jsonify({"error": "Could not remove the entry."}), 500
    if not row:
        return jsonify({"error": "Entry not found or already removed"}), 404
    return jsonify({"status": "success"})


def check_security_rules_schema():
    """Startup sanity check for gate_traffic / blacklist / lookup_audit."""
    missing = []
    for table in ("gate_traffic", "blacklist", "lookup_audit"):
        try:
            db.supabase.table(table).select("id").limit(1).execute()
        except Exception:
            missing.append(table)
    if missing:
        print("=" * 60)
        print(f"[STARTUP WARNING] Missing table(s): {', '.join(missing)}")
        print("  Entry/exit tracking, anti-passback, blacklist and guard lookups will NOT work")
        print("  until you run migrations_security_rules.sql in the Supabase SQL Editor.")
        print("  (The gate itself keeps working - these rules are skipped safely.)")
        print("=" * 60)
    else:
        print("[startup] gate_traffic + blacklist + lookup_audit: OK")
    print(f"[startup] anti-passback mode: {ANTI_PASSBACK_MODE}; exit endpoint auth: "
          f"{'X-Gate-Key' if GATE_API_KEY else 'Pi IP only (set GATE_API_KEY in .env)'}")


# ============ SECURITY INTELLIGENCE (Head Guard only, read-only) ============
intelligence.register(
    app, db=db,
    head_guard_page=head_guard_required_page, head_guard_api=head_guard_required_api,
    guard_page=login_required_page, guard_api=login_required_api,
    override_labels=OVERRIDE_REASON_LABELS, system_status_fn=_system_status_payload,
)


def check_alerts_table_exists():
    """Startup sanity check - the #1 reason repeat-visit alerts silently never
    fire is the `alerts` table not existing yet (migration not run). Warn loudly
    at startup instead of only failing quietly later when a plate is detected."""
    try:
        db.get_recent_alerts(limit=1)
        print("[startup] alerts table: OK")
    except Exception as e:
        print("=" * 60)
        print("[STARTUP WARNING] Could not read the 'alerts' table from Supabase.")
        print(f"  Error: {e}")
        print("  Repeat-visit alerts will NOT work until you run")
        print("  migrations_new_features.sql in the Supabase SQL Editor.")
        print("=" * 60)


def check_guards_schema():
    """Startup sanity check - Team Management (list/deactivate/reactivate
    guard) needs the `is_active` column on `guards`. Without it, list_guards()
    silently falls back and deactivate/reactivate silently no-op, which looks
    like 'guards disappeared' with no clue why."""
    try:
        db.supabase.table("guards").select("is_active").limit(1).execute()
        print("[startup] guards.is_active column: OK")
    except Exception as e:
        print("=" * 60)
        print("[STARTUP WARNING] Could not read 'guards.is_active' from Supabase.")
        print(f"  Error: {e}")
        print("  Team Management will still load (fallback), but Remove/")
        print("  Deactivate/Reactivate on guards with login history will NOT")
        print("  work until you run migrations_new_features.sql.")
        print("=" * 60)


def check_plate_audit_schema():
    """Startup sanity check - removing a plate needs the plate_audit table."""
    try:
        db.supabase.table("plate_audit").select("id").limit(1).execute()
        print("[startup] plate_audit table: OK")
    except Exception as e:
        print("=" * 60)
        print("[STARTUP WARNING] Could not read the 'plate_audit' table from Supabase.")
        print(f"  Error: {e}")
        print("  Guards will NOT be able to delete plates (deletion needs an audit entry)")
        print("  until you run migrations_plate_audit.sql in the Supabase SQL Editor.")
        print("=" * 60)


def check_residents_schema():
    """Startup sanity check - Residents page + Telegram bot need the tables /
    columns from migrations_telegram.sql."""
    try:
        db.supabase.table("residents").select("id").limit(1).execute()
        db.supabase.table("plates").select("resident_id,created_via").limit(1).execute()
        print("[startup] residents table + plates.resident_id: OK")
    except Exception as e:
        print("=" * 60)
        print("[STARTUP WARNING] Could not read 'residents' / 'plates.resident_id' from Supabase.")
        print(f"  Error: {e}")
        print("  The Residents page and Telegram bot will NOT work until you")
        print("  run migrations_telegram.sql in the Supabase SQL Editor.")
        print("=" * 60)


if __name__ == "__main__":
    db.init_db()
    detector.load_models()
    check_alerts_table_exists()
    check_guards_schema()
    check_residents_schema()
    check_motor_pass_schema()
    check_plate_audit_schema()
    check_security_rules_schema()

    # Background thread does the heavy YOLO+OCR work at its own pace, decoupled from
    # the MJPEG stream, so the live feed itself never stutters waiting on detection.
    threading.Thread(target=detection_worker, daemon=True).start()
    threading.Thread(target=visitor_expiry_worker, daemon=True).start()
    telegram_bot.start()  # resident Telegram bot - only runs if TELEGRAM_BOT_TOKEN is in .env

    print("=" * 50)
    print("  PLATE CHECKPOINT DASHBOARD (Windows, standalone)")
    print("  Open: http://localhost:5050")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5050, debug=False, threaded=True)
