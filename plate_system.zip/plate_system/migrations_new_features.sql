-- Run this in Supabase SQL Editor BEFORE using the new features
-- (#3 reason code override, #8 visitor pre-registration + expiry).
-- Safe to run multiple times (IF NOT EXISTS guards).

-- #3: Manual gate override audit trail
alter table logs add column if not exists reason_code text;
alter table logs add column if not exists note text;

-- #8: Visitor pre-registration + auto-expiry
alter table plates add column if not exists is_visitor boolean not null default false;
alter table plates add column if not exists expires_at timestamptz;

-- Optional but recommended: speeds up the expiry sweep query
create index if not exists idx_plates_visitor_expiry on plates (is_visitor, expires_at) where is_visitor = true;

-- Guard personal-info fields (Head Guard team management: full name already
-- existed; this adds gender/phone/address + IC front & back photo paths so a
-- Head Guard can review a guard's personal details for verification).
alter table guards add column if not exists gender text;
alter table guards add column if not exists phone text;
alter table guards add column if not exists address text;
alter table guards add column if not exists ic_front_path text;
alter table guards add column if not exists ic_back_path text;

-- Repeat-visit alerts (e.g. same plate seen 3x within 60 min) - raised by
-- check_repeat_visit_alert() in app.py, viewed via /api/alerts.
create table if not exists alerts (
    id bigint generated always as identity primary key,
    plate_number text not null,
    alert_type text not null default 'frequent_visit',
    occurrence_count int not null,
    window_minutes int not null,
    created_at timestamptz not null default now(),
    acknowledged boolean not null default false
);
create index if not exists idx_alerts_plate on alerts (plate_number, created_at desc);

-- Soft-delete for guards: "Remove" can't hard-delete a guard once they have
-- login_logs referencing them (FK constraint login_logs_guard_id_fkey blocks
-- it - that's expected, not a bug). Deactivating instead keeps the audit
-- trail (login_logs, leaderboard, analytics) intact while hiding them from
-- the active guard list and blocking further login.
alter table guards add column if not exists is_active boolean not null default true;
