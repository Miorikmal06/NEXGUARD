# Plate Checkpoint - Windows Standalone

Sistem live plate recognition macam `face_recognition` punya flow (register -> simpan -> recognize),
tapi untuk nombor plat. **Berasingan 100% dari barrier_v2 / Raspberry Pi** — boleh develop dan test
kat laptop Windows tanpa risau kacau sistem sedia ada.

## Database: Supabase (bukan SQLite lagi)

Sistem ni guna **Supabase** (Postgres cloud). Fail `.env` dalam folder ni dah ada `SUPABASE_URL`
dan `SUPABASE_KEY` — **jangan share/commit fail `.env` ni ke GitHub public** (dah masuk
`.gitignore`).

Table `plates` dan `logs` kena dibuat dulu kat Supabase SQL Editor sebelum run `app.py` kali
pertama (rujuk balik chat setup untuk SQL script-nya).


## 1. Setup (sekali sahaja)

```bash
cd plate_system
python -m venv venv
venv\Scripts\activate          # Windows
pip install -r requirements.txt
```

## 2. Download pretrained plate detector

Model YOLO ni **pretrained** (single class "License_Plate", dilatih atas dataset besar Roboflow) —
kau tak payah train dari kosong, macam `face_recognition` punya dlib model.

```bash
mkdir models
curl -L -o models/license_plate_detector.pt https://raw.githubusercontent.com/Muhammad-Zeerak-Khan/Automatic-License-Plate-Recognition-using-YOLOv8/main/license_plate_detector.pt
```

(Kalau `curl` tak function kat Windows CMD, download terus dari link tu guna browser dan letak
dalam folder `models/`.)

EasyOCR punya model akan auto-download first run (~64MB), tunggu sekejap je.

## 3. Run

```bash
python app.py
```

Buka browser: **http://localhost:5050**

- `/` — Dashboard (live feed + log deteksi + senarai plat berdaftar)
- `/register` — Daftar plat baharu (capture live, OCR akan cadangkan text, kau confirm/edit)

## 4. Cara kerja

1. Live feed jalan → setiap frame di-run through YOLO detect kotak plat → EasyOCR baca teks.
2. Setiap plat yang dikesan di-check dalam SQLite (`plates.db`):
   - **Berdaftar** → kotak hijau, log status "registered".
   - **Tidak Berdaftar** → kotak merah, log status "unregistered", snapshot disimpan untuk rekod.
3. Ada cooldown 8 saat per-plat supaya tak log berulang-ulang untuk kereta yang sama duduk lama
   dalam frame. Boleh ubah kat `LOG_COOLDOWN` dalam `app.py`.
4. Register baharu: tekan capture → OCR cadangkan nombor plat → kau boleh edit kalau OCR salah baca
   → simpan. Tiada retrain model diperlukan — sama macam tambah encoding baru dalam face recognition.

## 5. Nak sambung ke gate sebenar (Pi / barrier_v2)

Integration dah sedia dalam `app.py`, cuma OFF secara default. Nak aktifkan:

1. Buka `app.py`, cari bahagian atas fail (config):
   ```python
   GATE_INTEGRATION_ENABLED = False
   RASPBERRY_PI_IP = "172.20.10.2"
   ```
2. Tukar `RASPBERRY_PI_IP` ikut IP Pi kau **sekarang** (semak balik — zip lama `barrier.zip`
   ada guna 2 IP berbeza antara `app.py` (172.20.10.2) dan `dashboard.py`/`laptop_api.py`
   (172.20.10.3), jadi pastikan yang betul dulu sebelum aktifkan).
3. Tukar `GATE_INTEGRATION_ENABLED = True`.
4. Restart `python app.py`.

**Logic dia:**
- Plat **berdaftar** → hantar `POST /plate_detected` ke Pi (`{"plate": ..., "status": "open"}`),
  format sama macam `app.py`/`dashboard.py` original kau, supaya endpoint Flask kat Pi tak perlu
  diubah langsung.
- Plat **tidak berdaftar** → **tiada request dihantar** → Pi kekal pada default state dia
  (tutup), sebab Pi memang cuma bertindak bila terima signal "open".
- Request dihantar dalam thread berasingan (fire-and-forget) supaya kalau Pi lambat respond atau
  offline, live feed & OCR loop kat Windows **tak freeze/lag**.
- Cooldown 8 saat (`LOG_COOLDOWN`) automatik elak spam request berulang untuk plat yang sama
  duduk lama dalam frame.

⚠️ **Cadangan**: test dulu dengan `GATE_INTEGRATION_ENABLED = False` sampai kau confident
accuracy detection tinggi (terutama untuk motor), baru aktifkan True — sebab bila True, plat
berdaftar yang dikesan akan **terus** trigger buka pagar sebenar.

## Troubleshooting

- **Camera tak bukak / hitam je**: tukar `CAMERA_INDEX` dalam `app.py` (0, 1, 2...).
- **OCR salah baca huruf/nombor**: normal untuk plat kotor/blur — sebab tu register page bagi kau
  edit manual sebelum save.
- **EasyOCR lambat**: kalau ada GPU NVIDIA + CUDA, tukar `gpu=False` → `gpu=True` dalam `detector.py`.
