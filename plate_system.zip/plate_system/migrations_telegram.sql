-- Run this in Supabase SQL Editor BEFORE using the Residents page / Telegram bot.
-- Safe to run multiple times (IF NOT EXISTS guards).
-- Covers all Telegram phases (1: residents, 2: bot passes, 3: approve/reject, 4: messages)
-- so it only needs to be run once.

-- Phase 1: residents allowed to use the Telegram bot. A house can have more than
-- one resident (e.g. husband & wife) - each gets their own row + phone.
-- Residents are never hard-deleted (is_active = false instead) so history stays intact.
create table if not exists residents (
    id bigint generated always as identity primary key,
    full_name text not null,
    house_no text not null,
    phone text not null unique,            -- normalized digits, e.g. 60123456789
    telegram_user_id bigint unique,        -- filled in when the resident shares their contact with the bot
    telegram_chat_id bigint unique,
    telegram_linked_at timestamptz,
    is_active boolean not null default true,
    created_by text,
    created_at timestamptz not null default now()
);
create index if not exists idx_residents_house on residents (house_no);

-- Link plates (resident's own cars / visitor passes they create) to a resident
alter table plates add column if not exists resident_id bigint references residents(id) on delete set null;
alter table plates add column if not exists created_via text not null default 'dashboard';  -- 'dashboard' | 'telegram'
create index if not exists idx_plates_resident on plates (resident_id);

-- Phase 3: guard asks a resident to approve/reject an unknown visitor at the gate
create table if not exists visitor_requests (
    id bigint generated always as identity primary key,
    resident_id bigint not null references residents(id),
    plate_number text,
    snapshot_path text,
    status text not null default 'pending',   -- pending | approved | rejected | expired
    requested_by text,                         -- guard full_name
    created_at timestamptz not null default now(),
    expires_at timestamptz not null,
    responded_at timestamptz
);
create index if not exists idx_visitor_requests_status on visitor_requests (status, created_at desc);

-- Phase 4: resident -> guardhouse messages
create table if not exists resident_messages (
    id bigint generated always as identity primary key,
    resident_id bigint not null references residents(id),
    message text not null,
    created_at timestamptz not null default now(),
    read_by text,
    read_at timestamptz
);
create index if not exists idx_resident_messages_created on resident_messages (created_at desc);
