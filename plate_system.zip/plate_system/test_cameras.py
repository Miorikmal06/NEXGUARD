"""
test_cameras.py
Diagnostic script - test semua camera index dengan pelbagai backend, untuk cari punca
sebenar kenapa OpenCV tak boleh access webcam.

Run: python test_cameras.py
"""

import cv2

print("Testing camera indexes 0-4 with DirectShow (CAP_DSHOW)...")
print("-" * 50)

for i in range(5):
    cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
    opened = cap.isOpened()
    if opened:
        ret, frame = cap.read()
        shape = frame.shape if ret else "read failed"
        print(f"Index {i} (DSHOW): OPENED -> read: {ret}, shape: {shape}")
    else:
        print(f"Index {i} (DSHOW): failed to open")
    cap.release()

print("-" * 50)
print("Testing camera indexes 0-4 with default backend (MSMF)...")
print("-" * 50)

for i in range(5):
    cap = cv2.VideoCapture(i)
    opened = cap.isOpened()
    if opened:
        ret, frame = cap.read()
        shape = frame.shape if ret else "read failed"
        print(f"Index {i} (default): OPENED -> read: {ret}, shape: {shape}")
    else:
        print(f"Index {i} (default): failed to open")
    cap.release()

print("-" * 50)
print("Done. If BOTH sections show 'failed to open' for every index, the issue is likely:")
print("  1. Another app is currently using the camera (Zoom, Teams, Camera app, a leftover")
print("     python.exe from a previous run - check Task Manager).")
print("  2. Windows camera privacy setting is blocking desktop apps:")
print("     Settings > Privacy & security > Camera > 'Let desktop apps access your camera' -> On")
print("  3. A driver/antivirus issue - try restarting the PC.")
