"""
database.py
Semua fungsi berkaitan database untuk sistem Plate Recognition - guna Supabase (Postgres).

Function name & signature KEKAL SAMA macam versi SQLite sebelum ni, jadi app.py dan
detector.py tak perlu diubah langsung - cuma layer database di dalam sini yang bertukar.

Table (dah dibuat kat Supabase SQL Editor):
  plates -> senarai plat berdaftar
  logs   -> setiap kali plat dikesan (berdaftar / tidak berdaftar)
"""

import os
import time
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

SUPABASE_URL = os.environ.get("SUPABASE_URL")
# Use the service_role key (bypasses RLS) since this Flask app runs as a trusted
# local server, not in the browser. Falls back to the anon/publishable key if the
# service key isn't set yet, but the "guards" table (login credentials) is only
# readable with the service key - see README for how to add it.
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_KEY") or os.environ.get("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError(
        "SUPABASE_URL / SUPABASE_KEY not found. Make sure .env exists in the "
        "plate_system/ folder with:\n"
        "SUPABASE_URL=https://xxxxx.supabase.co\n"
        "SUPABASE_SERVICE_KEY=eyJ...  (service_role key, from Project Settings > API)"
    )

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)


def init_db():
    """
    Table dah dibuat terus kat Supabase (SQL Editor), jadi function ni cuma
    test sambungan supaya app.py terus dapat tahu awal-awal kalau credential salah.
    """
    try:
        supabase.table("plates").select("id").limit(1).execute()
        print("Sambungan Supabase OK.")
    except Exception as e:
        raise RuntimeError(f"Gagal sambung ke Supabase: {e}")


def normalize_plate(text):
    """Bersihkan text OCR: uppercase, buang semua simbol/space untuk konsistenkan matching."""
    if not text:
        return ""
    return "".join(c for c in text.upper() if c.isalnum())


def fix_ambiguous_chars(plate):
    """
    Betulkan keliru OCR biasa (0/O/Q, B/8, S/5, dll) berdasarkan format plat
    Malaysia standard: [HURUF...][NOMBOR...] - contoh QRN4383.

    Bahagian huruf (depan) tak akan ada digit dalam plat sebenar, jadi kalau
    OCR detect '0' di posisi huruf, besar kemungkinan sebenarnya 'O' (bulatan
    penuh) atau lagi tepat 'Q' bila crop jelas nampak garis ekor kecil.
    Sini kita default ke 'O' sebab lebih neutral (semua plat guna huruf O
    lazimnya boleh convert balik ke Q secara manual kalau perlu).
    """
    if not plate:
        return plate

    # Plat yang bermula dengan nombor (contoh diplomatik 1234DC) - jangan ubah apa-apa,
    # kalau tak '0' di depan akan tersalah jadi 'O'.
    if not plate[0].isalpha():
        return plate

    import re
    match = re.match(r'^([A-Z0-9]+?)(\d+)$', plate)
    if not match:
        return plate

    letters, numbers = match.groups()
    letters = letters.replace('0', 'O')  # digit takkan wujud dalam bahagian huruf
    return letters + numbers


_plates_cache = {"data": [], "ts": 0}
PLATES_CACHE_TTL = 20  # seconds - senarai plat registered jarang berubah frame-ke-frame,
                        # so takyah query Supabase setiap kali OCR confidence rendah


def _get_registered_plates_cached():
    """Senarai plate_number registered, refresh dari Supabase paling laju setiap PLATES_CACHE_TTL saat.
    Ni elak network round-trip ke Supabase pada SETIAP frame video (punca utama lag)."""
    now = time.time()
    if now - _plates_cache["ts"] > PLATES_CACHE_TTL:
        try:
            res = supabase.table("plates").select("plate_number").execute()
            _plates_cache["data"] = [r["plate_number"] for r in res.data]
            _plates_cache["ts"] = now
        except Exception as e:
            print(f"_get_registered_plates_cached failed to fetch plates: {e}")
    return _plates_cache["data"]


def find_closest_registered_plate(plate, max_distance=1):
    """
    Fuzzy-match plate OCR result terhadap plat yang dah registered dalam Supabase.
    Kalau ada plat registered yang beza cuma 1 huruf/nombor (Levenshtein distance),
    anggap itu match sebenar - ni bantu bila OCR masih silap lepas fix_ambiguous_chars
    (contoh Q<->0, B<->8, S<->5).

    Guna cache local (_get_registered_plates_cached) supaya function ni CEPAT dan tak
    buat network call setiap kali dipanggil per-frame.

    Return plate_number registered yang paling hampir, atau None kalau takde yang cukup dekat.
    """
    if not plate:
        return None

    import difflib
    registered = _get_registered_plates_cached()
    if not registered:
        return None

    matches = difflib.get_close_matches(plate, registered, n=1, cutoff=0.0)
    if not matches:
        return None

    best = matches[0]
    # Kira Levenshtein distance ringkas guna SequenceMatcher ratio -> approx edit distance
    distance = sum(1 for a, b in zip(plate, best) if a != b) + abs(len(plate) - len(best))
    if distance <= max_distance:
        return best
    return None


# ---------- PLATES (registered) ----------

def add_plate(plate_number, owner_name=None, photo_path=None,
              car_type=None, car_color=None, house_no=None, registered_by=None,
              is_visitor=False, expires_at=None, resident_id=None, created_via=None):
    """
    expires_at: ISO timestamp string (UTC) or None. Only meaningful when
    is_visitor=True - a permanent (resident) plate should always pass None.
    resident_id / created_via: set by the Telegram bot (migrations_telegram.sql).
    Only sent when given, so dashboard registration still works even if that
    migration hasn't been run.
    """
    plate_number = normalize_plate(plate_number)
    row = {
        "plate_number": plate_number,
        "owner_name": owner_name,
        "photo_path": photo_path,
        "car_type": car_type,
        "car_color": car_color,
        "house_no": house_no,
        "registered_by": registered_by,
        "registered_at": datetime.now(timezone.utc).isoformat(),
        "is_visitor": bool(is_visitor),
        "expires_at": expires_at,
    }
    if resident_id is not None:
        row["resident_id"] = resident_id
    if created_via is not None:
        row["created_via"] = created_via
    try:
        supabase.table("plates").insert(row).execute()
        return True
    except Exception as e:
        # unique constraint violation = plate already exists
        print(f"add_plate failed (plate may already be registered): {e}")
        return False


def get_plate_audit(limit=200):
    """Audit pembuangan plat terkini dulu (untuk Head Guard)."""
    res = (supabase.table("plate_audit").select("*")
           .order("created_at", desc=True).limit(limit).execute())
    return res.data


def delete_plate(plate_id, performed_by=None, performed_by_id=None, action="deleted", strict=True):
    """Buang plat dari whitelist DAN rekod audit (plat apa + siapa buang).

    Audit ditulis DULU, baru plat dipadam. strict=True (guard buang dari dashboard): kalau
    audit gagal ditulis, plat TIDAK dipadam dan error di-raise - tiada pembuangan tanpa
    jejak. strict=False (sweep automatik / Telegram): kalau audit gagal, tetap padam supaya
    kerja pembersihan tak tersekat, cuma print amaran.
    Return baris plat yang dipadam, atau None kalau plat tak wujud."""
    row = get_plate_by_id(plate_id)
    if not row:
        return None
    audit_id = None
    try:
        res = supabase.table("plate_audit").insert({
            "action": action,
            "plate_id": row.get("id"),
            "plate_number": row.get("plate_number") or "?",
            "owner_name": row.get("owner_name"),
            "house_no": row.get("house_no"),
            "is_visitor": bool(row.get("is_visitor")),
            "performed_by": performed_by or "unknown",
            "performed_by_id": performed_by_id,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }).execute()
        audit_id = res.data[0].get("id") if res.data else None
    except Exception as e:
        if strict:
            raise
        print(f"[plate_audit] could not write audit row for {row.get('plate_number')}: {e}")
    try:
        supabase.table("plates").delete().eq("id", plate_id).execute()
    except Exception:
        # padam gagal -> buang balik baris audit supaya audit tak tipu (best effort)
        if audit_id is not None:
            try:
                supabase.table("plate_audit").delete().eq("id", audit_id).execute()
            except Exception:
                pass
        raise
    return row


def get_all_plates():
    res = supabase.table("plates").select("*").order("registered_at", desc=True).execute()
    return res.data


def is_registered(plate_number):
    """
    Returns the plate row if it's a valid, non-expired registration - or None.
    A visitor pass whose expires_at has already passed is treated as NOT
    registered even if the periodic sweep (see get_expired_visitor_plates)
    hasn't deleted the row yet - this is the defensive check; the sweep is
    what actually cleans the whitelist up so it doesn't grow forever.
    """
    plate_number = normalize_plate(plate_number)
    res = supabase.table("plates").select("*").eq("plate_number", plate_number).execute()
    if not res.data:
        return None
    row = res.data[0]
    if row.get("is_visitor") and row.get("expires_at"):
        try:
            expires = datetime.fromisoformat(row["expires_at"].replace("Z", "+00:00"))
            if expires <= datetime.now(timezone.utc):
                return None
        except Exception:
            pass
    return row


def get_expired_visitor_plates(limit=500):
    """Visitor passes whose expiry has already passed - used by the periodic
    sweep in app.py to auto-remove them from the whitelist."""
    now_iso = datetime.now(timezone.utc).isoformat()
    res = (
        supabase.table("plates")
        .select("id,plate_number,expires_at")
        .eq("is_visitor", True)
        .lte("expires_at", now_iso)
        .limit(limit)
        .execute()
    )
    return res.data


# ---------- LOGS ----------

def add_log(plate_number, status, snapshot_path=None, confidence=None, performed_by=None,
            timestamp=None, reason_code=None, note=None):
    """
    reason_code / note only apply to status='manual' (gate override audit trail) -
    reason_code is one of app.py's OVERRIDE_REASONS values, note is optional free text
    (required by app.py when reason_code == 'other').
    """
    supabase.table("logs").insert({
        "plate_number": plate_number,
        "status": status,
        "snapshot_path": snapshot_path,
        "confidence": confidence,
        "performed_by": performed_by,
        "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
        "reason_code": reason_code,
        "note": note,
    }).execute()


def _plates_similar(a, b):
    """True kalau dua plat sama, atau beza max 1 aksara (OCR kadang tersilap 1 huruf/nombor,
    contoh VCP7032 vs VCP7082). Guna untuk kira lawatan berulang."""
    a = (a or "").replace(" ", "").upper()
    b = (b or "").replace(" ", "").upper()
    if not a or not b:
        return False
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) == len(b):
        return sum(1 for x, y in zip(a, b) if x != y) <= 1
    # beza panjang 1 -> cek satu insert/delete
    short, long_ = (a, b) if len(a) < len(b) else (b, a)
    i = j = diff = 0
    while i < len(short) and j < len(long_):
        if short[i] == long_[j]:
            i += 1
            j += 1
        else:
            diff += 1
            j += 1
            if diff > 1:
                return False
    return True


def count_recent_logs(plate_number, minutes=60):
    """Berapa kali plat ni (atau plat yang hampir sama - OCR typo 1 aksara) dilog
    dalam N minit lepas. Dipakai oleh repeat-visit alert."""
    since = (datetime.now(timezone.utc) - timedelta(minutes=minutes)).isoformat()
    res = (
        supabase.table("logs")
        .select("plate_number,status")
        .gte("timestamp", since)
        .limit(1000)
        .execute()
    )
    return sum(
        1 for r in (res.data or [])
        if r.get("status") != "manual" and _plates_similar(plate_number, r.get("plate_number"))
    )


def create_alert(plate_number, occurrence_count, window_minutes, alert_type="frequent_visit", detail=None):
    """alert_type: frequent_visit | blacklist | watchlist | passback. `detail` (optional text)
    needs the alerts.detail column from migrations_security_rules.sql - without it the alert
    is still created, just without the extra text."""
    row = {
        "plate_number": plate_number,
        "alert_type": alert_type,
        "occurrence_count": occurrence_count,
        "window_minutes": window_minutes,
    }
    if detail:
        try:
            supabase.table("alerts").insert(dict(row, detail=detail[:300])).execute()
            return
        except Exception:
            pass  # detail column missing -> fall through to the plain insert
    supabase.table("alerts").insert(row).execute()


def has_recent_alert(plate_number, minutes=60, alert_type=None):
    """Cooldown check - elak alert berganda untuk plat yang sama selagi guard belum
    Dismiss. Alert yang dah di-dismiss TIDAK block alert baru. Bila alert_type diberi,
    hanya alert jenis itu dikira (alert 'blacklist' tak disekat oleh alert 'frequent_visit')."""
    since = (datetime.now(timezone.utc) - timedelta(minutes=minutes)).isoformat()
    query = (
        supabase.table("alerts")
        .select("plate_number,alert_type")
        .eq("acknowledged", False)
        .gte("created_at", since)
    )
    res = query.execute()
    rows = res.data or []
    if alert_type:
        rows = [r for r in rows if (r.get("alert_type") or "frequent_visit") == alert_type]
    else:
        rows = [r for r in rows if (r.get("alert_type") or "frequent_visit") == "frequent_visit"]
    return any(_plates_similar(plate_number, r.get("plate_number")) for r in rows)


def get_alert(alert_id):
    res = supabase.table("alerts").select("*").eq("id", alert_id).execute()
    return res.data[0] if res.data else None


def get_recent_alerts(limit=50, acknowledged=None):
    """For the dashboard - list recent repeat-visit alerts, newest first."""
    query = supabase.table("alerts").select("*")
    if acknowledged is not None:
        query = query.eq("acknowledged", acknowledged)
    res = query.order("created_at", desc=True).limit(limit).execute()
    return res.data


def acknowledge_alert(alert_id, by=None):
    """Mark an alert reviewed. When migrations_audit_trail.sql has been applied the reviewer
    and time are stored too; before that migration this behaves exactly as it always did."""
    if by:
        try:
            supabase.table("alerts").update({
                "acknowledged": True,
                "acknowledged_by": by,
                "acknowledged_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", alert_id).execute()
            return
        except Exception:
            pass  # audit columns not present yet -> fall back to the original update below
    supabase.table("alerts").update({"acknowledged": True}).eq("id", alert_id).execute()


def add_logs_bulk(rows):
    """rows: list of dicts already shaped for the `logs` table (used by CSV import)."""
    if not rows:
        return 0
    supabase.table("logs").insert(rows).execute()
    return len(rows)


def get_recent_logs(limit=50, status=None):
    query = supabase.table("logs").select("*")
    if status:
        query = query.eq("status", status)
    res = query.order("timestamp", desc=True).limit(limit).execute()
    return res.data


def get_logs_by_date(date_str, limit=200, status=None):
    """date_str format: 'YYYY-MM-DD' (Malaysia calendar date). Return semua log pada hari tersebut.
    Guna offset +08:00 (bukan +00:00) supaya 'hari' dikira ikut waktu tempatan Malaysia,
    bukan UTC - elak indicator reset pada waktu pelik (8 pagi) sebab UTC-Malaysia beza 8 jam."""
    start = f"{date_str}T00:00:00+08:00"
    end = f"{date_str}T23:59:59+08:00"
    query = (
        supabase.table("logs")
        .select("*")
        .gte("timestamp", start)
        .lte("timestamp", end)
    )
    if status:
        query = query.eq("status", status)
    res = query.order("timestamp", desc=True).limit(limit).execute()
    return res.data


# ---------- ANALYTICS / REPORTING ----------

def get_logs_since(days=14, limit=3000):
    """Semua log dari N hari lepas - untuk graph analytics."""
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    res = (
        supabase.table("logs")
        .select("*")
        .gte("timestamp", start)
        .order("timestamp", desc=False)
        .limit(limit)
        .execute()
    )
    return res.data


def get_all_plates_light():
    res = supabase.table("plates").select("plate_number,registered_by,registered_at").execute()
    return res.data


# ---------- PERSONAL ANALYTICS (per-guard, "My Activity") ----------

def get_logs_for_guard(guard_name, days=14, limit=1000):
    """Semua log (manual override / detection performed_by) untuk SATU guard sahaja."""
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    res = (
        supabase.table("logs")
        .select("*")
        .eq("performed_by", guard_name)
        .gte("timestamp", start)
        .order("timestamp", desc=True)
        .limit(limit)
        .execute()
    )
    return res.data


def get_plates_for_guard(guard_name, days=14, limit=1000):
    """Semua plat yang didaftarkan oleh SATU guard sahaja, dalam tempoh N hari."""
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    res = (
        supabase.table("plates")
        .select("*")
        .eq("registered_by", guard_name)
        .gte("registered_at", start)
        .order("registered_at", desc=True)
        .limit(limit)
        .execute()
    )
    return res.data


def get_login_sessions_for_guard(guard_id, days=14, limit=200):
    """Semua sesi login/logout untuk SATU guard sahaja, dalam tempoh N hari."""
    start = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    res = (
        supabase.table("login_logs")
        .select("*")
        .eq("guard_id", guard_id)
        .gte("login_at", start)
        .order("login_at", desc=True)
        .limit(limit)
        .execute()
    )
    return res.data


# ---------- GUARDS (login) ----------

def get_guard_by_username(username):
    res = supabase.table("guards").select("*").eq("username", username).execute()
    return res.data[0] if res.data else None


def list_guards(include_inactive=True):
    """Senarai semua guard (TANPA password_hash) - untuk admin panel Head Guard.
    Includes personal-info fields (gender, phone, address, IC copies) so the Head
    Guard can review a guard's details without a second round-trip.
    include_inactive=True (default) so the Head Guard can still see/reactivate
    deactivated guards; set False for lists that should only show active staff
    (e.g. dropdowns for assigning new work)."""
    query = (
        supabase.table("guards")
        .select("id,username,full_name,role,created_at,gender,phone,address,ic_front_path,ic_back_path,is_active,ic_number,photo_path")
    )
    if not include_inactive:
        query = query.eq("is_active", True)
    try:
        res = query.order("created_at", desc=False).execute()
    except Exception as e:
        # `is_active` column missing (migration not run yet) - fall back to the
        # old column set so the Team page still loads instead of going blank.
        print(f"[list_guards] falling back without is_active (run migrations_new_features.sql + migrations_guard_profile.sql): {e}")
        res = (
            supabase.table("guards")
            .select("id,username,full_name,role,created_at,gender,phone,address,ic_front_path,ic_back_path")
            .order("created_at", desc=False)
            .execute()
        )
    return res.data


def create_guard(username, full_name, password_hash, role="guard",
                  gender=None, phone=None, address=None,
                  ic_front_path=None, ic_back_path=None,
                  ic_number=None, photo_path=None):
    row = {
        "username": username.strip().lower(),
        "full_name": full_name.strip(),
        "password_hash": password_hash,
        "role": role,
        "gender": gender,
        "phone": phone,
        "address": address,
        "ic_front_path": ic_front_path,
        "ic_back_path": ic_back_path,
    }
    # Only send the new profile columns when they have a value, so creating a guard
    # still works on a database where migrations_guard_profile.sql hasn't been run yet.
    if ic_number:
        row["ic_number"] = ic_number
    if photo_path:
        row["photo_path"] = photo_path
    try:
        supabase.table("guards").insert(row).execute()
        return True, None
    except Exception as e:
        return False, str(e)


def deactivate_guard(guard_id):
    """Soft-delete: blocks login and hides from the active roster, but keeps
    login_logs / analytics / leaderboard history intact (no FK violation,
    unlike a hard delete)."""
    try:
        supabase.table("guards").update({"is_active": False}).eq("id", guard_id).execute()
    except Exception as e:
        print(f"[deactivate_guard] failed - is_active column may be missing "
              f"(run migrations_new_features.sql): {e}")


def reactivate_guard(guard_id):
    try:
        supabase.table("guards").update({"is_active": True}).eq("id", guard_id).execute()
    except Exception as e:
        print(f"[reactivate_guard] failed - is_active column may be missing "
              f"(run migrations_new_features.sql): {e}")


def delete_guard(guard_id):
    """Hard delete - kept for cases where a guard has NO login_logs yet (e.g.
    created by mistake, never logged in). Returns (success: bool, error: str|None).
    If this guard has any activity logs, the FK constraint on login_logs will
    block it - use deactivate_guard() instead for guards with history."""
    try:
        res = supabase.table("guards").delete().eq("id", guard_id).execute()
        if not res.data:
            return False, ("Delete was blocked by the database (no rows removed). "
                            "This guard may have activity logs referencing them, "
                            "or a database permission issue - check the Flask console.")
        return True, None
    except Exception as e:
        return False, str(e)


def purge_guard(guard_id):
    """PERMANENT removal: the guard's login history rows first (they hold the FK that
    blocks a plain delete), then the guard row itself. Returns
    (ok: bool, error: str|None, guard_row: dict|None) - guard_row is what was deleted so the
    caller can also remove the guard's photo / IC image files from disk."""
    guard = get_guard_for_login(guard_id)
    if not guard:
        return False, "Guard not found", None
    # Never leave the system without a Head Guard who can still log in.
    if guard.get("role") == "head_guard":
        others = [g for g in list_guards()
                  if g["id"] != guard_id and g.get("role") == "head_guard" and g.get("is_active", True)]
        if not others:
            return False, "You can't remove the last Head Guard - promote or create another one first.", None
    try:
        supabase.table("login_logs").delete().eq("guard_id", guard_id).execute()
        res = supabase.table("guards").delete().eq("id", guard_id).execute()
        if not res.data:
            return False, ("The database refused to delete this guard (no rows removed). "
                           "Check the Flask console / Supabase permissions."), None
        return True, None, guard
    except Exception as e:
        return False, str(e), None


def reset_guard_password(guard_id, password_hash):
    supabase.table("guards").update({"password_hash": password_hash}).eq("id", guard_id).execute()


def update_guard_details(guard_id, updates: dict):
    """Update personal-info fields for a guard. `updates` should only contain
    keys that changed (e.g. full_name, gender, phone, address, ic_front_path,
    ic_back_path) - None values are skipped so a partial edit doesn't wipe
    fields the guard didn't touch."""
    clean = {k: v for k, v in updates.items() if v is not None}
    if not clean:
        return
    supabase.table("guards").update(clean).eq("id", guard_id).execute()


def get_guard_by_id(guard_id):
    res = (
        supabase.table("guards")
        .select("id,username,full_name,role,gender,phone,address,ic_front_path,ic_back_path,created_at")
        .eq("id", guard_id)
        .execute()
    )
    guard = res.data[0] if res.data else None
    if guard:
        # ic_number / photo_path come from migrations_guard_profile.sql - fetched
        # separately so this still works before that migration has been run.
        try:
            extra = supabase.table("guards").select("ic_number,photo_path").eq("id", guard_id).execute()
            if extra.data:
                guard.update(extra.data[0])
        except Exception as e:
            print(f"[get_guard_by_id] ic_number/photo_path not available (run migrations_guard_profile.sql): {e}")
        guard.setdefault("ic_number", None)
        guard.setdefault("photo_path", None)
    return guard


def get_guard_for_login(guard_id):
    """Full row INCLUDING password_hash - only for the login check, never send to a client."""
    res = supabase.table("guards").select("*").eq("id", guard_id).execute()
    return res.data[0] if res.data else None


def list_login_roster():
    """Active guards for the login screen's name scroller. Deliberately minimal: only
    the id and display name (no username, role or personal details) because this list
    is shown to anyone who can open the login page."""
    try:
        res = (supabase.table("guards").select("id,full_name,is_active")
               .order("created_at", desc=False).execute())
        rows = [r for r in (res.data or []) if r.get("is_active", True)]
    except Exception:
        # is_active column missing (migration not run) - show everyone
        res = supabase.table("guards").select("id,full_name").order("created_at", desc=False).execute()
        rows = res.data or []
    return [{"id": r["id"], "full_name": r["full_name"]} for r in rows if r.get("full_name")]


# ---------- RESIDENTS (Telegram bot users) ----------

def normalize_phone(phone):
    """Normalisasi nombor telefon Malaysia kepada digit sahaja dengan kod negara,
    supaya nombor yang ditaip guard (012-345 6789) sepadan dengan nombor yang
    Telegram hantar bila penduduk kongsi contact (+60123456789 / 60123456789)."""
    digits = "".join(c for c in (phone or "") if c.isdigit())
    if not digits:
        return ""
    if digits.startswith("0"):
        digits = "6" + digits
    return digits


def list_residents():
    """Semua penduduk (aktif + tak aktif) beserta plat yang dipautkan kepada mereka."""
    residents = (
        supabase.table("residents")
        .select("*")
        .order("house_no", desc=False)
        .execute()
    ).data or []
    plates = (
        supabase.table("plates")
        .select("id,plate_number,resident_id,is_visitor,expires_at")
        .not_.is_("resident_id", "null")
        .execute()
    ).data or []
    by_resident = {}
    for p in plates:
        by_resident.setdefault(p["resident_id"], []).append(p)
    for r in residents:
        r["plates"] = by_resident.get(r["id"], [])
    return residents


def get_resident_by_id(resident_id):
    res = supabase.table("residents").select("*").eq("id", resident_id).execute()
    return res.data[0] if res.data else None


def create_resident(full_name, house_no, phone, created_by=None):
    """Returns (success, error)."""
    try:
        supabase.table("residents").insert({
            "full_name": full_name.strip(),
            "house_no": house_no.strip(),
            "phone": normalize_phone(phone),
            "created_by": created_by,
        }).execute()
        return True, None
    except Exception as e:
        return False, str(e)


def update_resident(resident_id, full_name=None, house_no=None, phone=None):
    """Returns (success, error). Field None = kekalkan nilai sedia ada.
    Tukar nombor telefon akan unlink Telegram, sebab akaun Telegram yang dah
    dipautkan disahkan guna nombor lama."""
    updates = {}
    if full_name:
        updates["full_name"] = full_name.strip()
    if house_no:
        updates["house_no"] = house_no.strip()
    if phone:
        new_phone = normalize_phone(phone)
        current = get_resident_by_id(resident_id)
        if current and current.get("phone") != new_phone:
            updates.update({
                "phone": new_phone,
                "telegram_user_id": None,
                "telegram_chat_id": None,
                "telegram_linked_at": None,
            })
    if not updates:
        return True, None
    try:
        supabase.table("residents").update(updates).eq("id", resident_id).execute()
        return True, None
    except Exception as e:
        return False, str(e)


def set_resident_active(resident_id, active):
    supabase.table("residents").update({"is_active": bool(active)}).eq("id", resident_id).execute()


def unlink_resident_telegram(resident_id):
    supabase.table("residents").update({
        "telegram_user_id": None,
        "telegram_chat_id": None,
        "telegram_linked_at": None,
    }).eq("id", resident_id).execute()


def get_linkable_plates():
    """Plat penduduk (bukan pelawat) - untuk dropdown 'Link Plates' di page Residents."""
    res = (
        supabase.table("plates")
        .select("id,plate_number,owner_name,house_no,resident_id")
        .eq("is_visitor", False)
        .order("plate_number", desc=False)
        .execute()
    )
    return res.data or []


def normalize_house_no(house_no):
    """'No. 12' == 'no 12' == 'NO12' - supaya penghuni serumah dipadankan walaupun
    Head Guard taip house_no sikit berbeza untuk setiap orang."""
    return "".join(c for c in (house_no or "").lower() if c.isalnum())


def get_resident_by_phone(phone):
    phone = normalize_phone(phone)
    if not phone:
        return None
    res = supabase.table("residents").select("*").eq("phone", phone).execute()
    return res.data[0] if res.data else None


def get_resident_by_telegram_user(telegram_user_id):
    res = supabase.table("residents").select("*").eq("telegram_user_id", telegram_user_id).execute()
    return res.data[0] if res.data else None


def link_resident_telegram(resident_id, telegram_user_id, telegram_chat_id):
    # Satu akaun Telegram hanya boleh terpaut pada satu penduduk (unique constraint) -
    # lepaskan pautan lama dulu kalau ada.
    supabase.table("residents").update({
        "telegram_user_id": None, "telegram_chat_id": None, "telegram_linked_at": None,
    }).eq("telegram_user_id", telegram_user_id).neq("id", resident_id).execute()
    supabase.table("residents").update({
        "telegram_user_id": telegram_user_id,
        "telegram_chat_id": telegram_chat_id,
        "telegram_linked_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", resident_id).execute()


def get_house_residents(house_no):
    """Semua penduduk AKTIF yang tinggal di rumah yang sama (padanan house_no dinormalisasi)."""
    target = normalize_house_no(house_no)
    res = supabase.table("residents").select("*").eq("is_active", True).execute()
    return [r for r in (res.data or []) if normalize_house_no(r.get("house_no")) == target]


def get_plate_by_number(plate_number):
    """Row plat (termasuk pas pelawat yang dah luput) atau None - tiada semakan expiry."""
    plate_number = normalize_plate(plate_number)
    res = supabase.table("plates").select("*").eq("plate_number", plate_number).execute()
    return res.data[0] if res.data else None


def get_plate_by_id(plate_id):
    res = supabase.table("plates").select("*").eq("id", plate_id).execute()
    return res.data[0] if res.data else None


def get_active_passes_for_residents(resident_ids):
    """Pas pelawat yang masih aktif, dicipta oleh mana-mana penduduk dalam senarai."""
    resident_ids = list(resident_ids)
    if not resident_ids:
        return []
    res = (
        supabase.table("plates")
        .select("*")
        .eq("is_visitor", True)
        .in_("resident_id", resident_ids)
        .gt("expires_at", datetime.now(timezone.utc).isoformat())
        .order("expires_at", desc=False)
        .execute()
    )
    return res.data or []


def set_resident_plates(resident_id, plate_ids):
    """Tetapkan senarai plat penduduk (bukan pelawat) untuk seorang penduduk:
    plat yang dipilih dipautkan, plat lama yang tak dipilih lagi dilepaskan.
    Pas pelawat yang dicipta penduduk melalui bot tak disentuh."""
    plate_ids = [int(i) for i in plate_ids]
    supabase.table("plates").update({"resident_id": None}) \
        .eq("resident_id", resident_id).eq("is_visitor", False).execute()
    if plate_ids:
        supabase.table("plates").update({"resident_id": resident_id}) \
            .in_("id", plate_ids).eq("is_visitor", False).execute()


# ---------- LOGIN SESSIONS (for Power BI reporting) ----------

def create_login_log(guard_id, guard_name, username):
    res = supabase.table("login_logs").insert({
        "guard_id": guard_id,
        "guard_name": guard_name,
        "username": username,
        "login_at": datetime.now(timezone.utc).isoformat(),
    }).execute()
    return res.data[0]["id"] if res.data else None


def close_login_log(log_id):
    if not log_id:
        return
    supabase.table("login_logs").update({
        "logout_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", log_id).execute()


# ============ MOTORCYCLE QR PASSES (migrations_motor_pass.sql) ============
# The QR only carries a random token; plate/owner/status live here. A forged QR therefore
# resolves to "not found", and a lost/stolen sticker can be revoked or replaced (rotate).
import re as _re
import secrets as _secrets

# No 0/O/1/I/L so a code typed by hand from the printed sticker can't be misread.
MOTOR_TOKEN_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
MOTOR_TOKEN_LENGTH = 12


def new_motor_token():
    return "".join(_secrets.choice(MOTOR_TOKEN_ALPHABET) for _ in range(MOTOR_TOKEN_LENGTH))


def normalize_motor_token(raw):
    """Accepts 'K7M2-9QXA-4HTB', 'k7m2 9qxa 4htb' or the bare token. Returns '' if it can't be a token."""
    t = _re.sub(r"[^A-Za-z0-9]", "", raw or "").upper()
    if len(t) != MOTOR_TOKEN_LENGTH or any(c not in MOTOR_TOKEN_ALPHABET for c in t):
        return ""
    return t


def format_motor_token(token):
    t = token or ""
    return "-".join(t[i:i + 4] for i in range(0, len(t), 4))


def create_motor_pass(plate_number, owner_name=None, house_no=None, expires_at=None, created_by=None):
    """Returns the new row. Raises on DB error (caller turns that into a 500/502)."""
    row = {
        "plate_number": normalize_plate(plate_number),
        "owner_name": owner_name,
        "house_no": house_no,
        "expires_at": expires_at,
        "created_by": created_by,
        "is_active": True,
    }
    last_err = None
    for _ in range(5):  # token collision is ~impossible, but the unique index makes a retry free
        row["token"] = new_motor_token()
        try:
            res = supabase.table("motor_passes").insert(row).execute()
            return res.data[0]
        except Exception as e:
            last_err = e
    raise last_err


def list_motor_passes(include_inactive=True):
    q = supabase.table("motor_passes").select("*")
    if not include_inactive:
        q = q.eq("is_active", True)
    return q.order("created_at", desc=True).execute().data or []


def get_motor_pass(pass_id):
    res = supabase.table("motor_passes").select("*").eq("id", pass_id).execute()
    return res.data[0] if res.data else None


def get_motor_pass_by_token(token):
    token = normalize_motor_token(token)
    if not token:
        return None
    res = supabase.table("motor_passes").select("*").eq("token", token).execute()
    return res.data[0] if res.data else None


def get_active_motor_pass_for_plate(plate_number):
    res = (supabase.table("motor_passes").select("*")
           .eq("plate_number", normalize_plate(plate_number)).eq("is_active", True).execute())
    now = datetime.now(timezone.utc)
    for r in res.data or []:
        if not motor_pass_is_expired(r, now):
            return r
    return None


def motor_pass_is_expired(row, now=None):
    exp = (row or {}).get("expires_at")
    if not exp:
        return False
    try:
        dt = datetime.fromisoformat(str(exp).replace("Z", "+00:00"))
    except ValueError:
        return False  # unparseable expiry: don't lock a resident out because of bad data
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt <= (now or datetime.now(timezone.utc))


def set_motor_pass_active(pass_id, active, by=None):
    upd = {"is_active": bool(active)}
    if active:
        upd.update({"deactivated_by": None, "deactivated_at": None})
    else:
        upd.update({"deactivated_by": by, "deactivated_at": datetime.now(timezone.utc).isoformat()})
    supabase.table("motor_passes").update(upd).eq("id", pass_id).execute()


def rotate_motor_pass_token(pass_id):
    """Issue a replacement QR: the old printed QR stops working immediately. Returns the new token."""
    for _ in range(5):
        token = new_motor_token()
        try:
            supabase.table("motor_passes").update({
                "token": token, "is_active": True,
                "deactivated_by": None, "deactivated_at": None,
                "token_rotated_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", pass_id).execute()
            return token
        except Exception as e:
            last_err = e
    raise last_err


def log_motor_pass_event(pass_id, event, plate_number=None, guard_name=None, note=None):
    """Audit row. Never raises - an audit hiccup must not block the guard at the gate."""
    try:
        supabase.table("motor_pass_events").insert({
            "pass_id": pass_id, "event": event, "plate_number": plate_number,
            "guard_name": guard_name, "note": note,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }).execute()
    except Exception as e:
        print(f"[motor_pass] could not write event '{event}': {e}")


def get_last_motor_pass_entry(pass_id):
    """Most recent 'opened' event for a pass (or None) - shown on the scan page."""
    try:
        res = (supabase.table("motor_pass_events").select("created_at,guard_name")
               .eq("pass_id", pass_id).eq("event", "opened")
               .order("created_at", desc=True).limit(1).execute())
        return res.data[0] if res.data else None
    except Exception:
        return None


def get_recent_motor_pass_events(limit=20):
    try:
        return (supabase.table("motor_pass_events").select("*")
                .order("created_at", desc=True).limit(limit).execute().data or [])
    except Exception:
        return []


# ---------- GATE TRAFFIC: entry / exit / anti-passback ----------

def add_traffic(direction, plate_number=None, source=None, performed_by=None, note=None):
    """Rekod satu kejadian pintu: 'in' | 'out' | 'reset'. Exit dari sensor tiada plat."""
    res = supabase.table("gate_traffic").insert({
        "direction": direction,
        "plate_number": plate_number,
        "source": source,
        "performed_by": performed_by,
        "note": note,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }).execute()
    return res.data[0] if res.data else None


def _last_reset_iso():
    res = (supabase.table("gate_traffic").select("created_at").eq("direction", "reset")
           .order("created_at", desc=True).limit(1).execute())
    return res.data[0]["created_at"] if res.data else None


def get_presence_summary(max_rows=5000):
    """Anggaran kenderaan di dalam sekarang.

    Sensor keluar (ultrasonic) tak boleh baca plat, jadi sistem TAHU berapa kereta keluar
    tetapi tak tahu plat yang mana. Maka:
      inside        = masuk - keluar sejak reset terakhir (tak kurang dari 0)  -> ANGGARAN
      confirmed_inside = plat yang masuk dan LANGSUNG tiada rekod keluar selepas itu -> pasti masih di dalam
    """
    since = _last_reset_iso()
    q = supabase.table("gate_traffic").select("direction,plate_number,source,created_at").neq("direction", "reset")
    if since:
        q = q.gt("created_at", since)
    rows = q.order("created_at").limit(max_rows).execute().data or []
    ins = [r for r in rows if r["direction"] == "in"]
    outs = [r for r in rows if r["direction"] == "out"]
    out_times = sorted(r["created_at"] for r in outs)

    last_in = {}
    for r in ins:                      # rows are oldest -> newest, so the last write wins
        if r.get("plate_number"):
            last_in[r["plate_number"]] = r["created_at"]
    confirmed = []
    for plate, ts in last_in.items():
        if not any(o > ts for o in out_times):
            confirmed.append({"plate_number": plate, "entered_at": ts})
    confirmed.sort(key=lambda x: x["entered_at"], reverse=True)

    return {
        "inside": max(0, len(ins) - len(outs)),
        "entries": len(ins),
        "exits": len(outs),
        "more_exits_than_entries": len(outs) > len(ins),
        "since": since,
        "last_exit_at": out_times[-1] if out_times else None,
        "confirmed_inside": confirmed[:100],
    }


def check_passback(plate_number, window_hours=24, grace_seconds=120):
    """Anti-passback (versi sensor): plat ini masuk, dan SEJAK ITU tiada satu pun kereta
    direkod keluar -> dia tak mungkin dah keluar, jadi masuk lagi = mencurigakan.

    Return dict {last_in_at, seconds_since} kalau melanggar, atau None.
      - Dalam `grace_seconds` selepas masuk dianggap pas yang sama (kereta masih di depan gate).
      - Lebih `window_hours` dianggap lapuk (mungkin sensor terlepas) - tak disekat selamanya.
    """
    res = (supabase.table("gate_traffic").select("created_at")
           .eq("direction", "in").eq("plate_number", plate_number)
           .order("created_at", desc=True).limit(1).execute())
    if not res.data:
        return None
    last_in = res.data[0]["created_at"]
    ts = datetime.fromisoformat(last_in.replace("Z", "+00:00"))
    age = (datetime.now(timezone.utc) - ts).total_seconds()
    if age <= grace_seconds or age > window_hours * 3600:
        return None
    later = (supabase.table("gate_traffic").select("id")
             .in_("direction", ["out", "reset"]).gt("created_at", last_in).limit(1).execute())
    if later.data:
        return None
    return {"last_in_at": last_in, "seconds_since": int(age)}


def get_recent_traffic(limit=30):
    res = (supabase.table("gate_traffic").select("*")
           .order("created_at", desc=True).limit(limit).execute())
    return res.data


# ---------- BLACKLIST / WATCHLIST ----------

_blacklist_cache = {"data": [], "ts": 0}
_BLACKLIST_TTL = 15  # seconds


def _invalidate_blacklist_cache():
    _blacklist_cache["ts"] = 0


def levenshtein(a, b):
    """Jarak Levenshtein sebenar (insert/delete/replace), bukan perbandingan posisi."""
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _active_blacklist_cached():
    now = time.time()
    if now - _blacklist_cache["ts"] > _BLACKLIST_TTL:
        try:
            res = supabase.table("blacklist").select("*").eq("is_active", True).execute()
            nowdt = datetime.now(timezone.utc)
            rows = []
            for r in res.data or []:
                exp = r.get("expires_at")
                if exp:
                    try:
                        if datetime.fromisoformat(exp.replace("Z", "+00:00")) <= nowdt:
                            continue
                    except Exception:
                        pass
                rows.append(r)
            _blacklist_cache["data"] = rows
            _blacklist_cache["ts"] = now
        except Exception as e:
            print(f"[blacklist] could not load list (run migrations_security_rules.sql?): {e}")
            _blacklist_cache["ts"] = now - _BLACKLIST_TTL + 5   # retry soon, keep old data
    return _blacklist_cache["data"]


def get_blacklist_match(plate_number):
    """Padanan blacklist/watchlist untuk satu plat.
    Return {**row, "near": False} untuk padanan TEPAT, {**row, "near": True} kalau cuma
    beza 1 aksara (OCR mungkin silap) - near-match HANYA patut beri amaran, bukan sekat gate.
    Return None kalau tiada."""
    plate = normalize_plate(plate_number)
    if not plate:
        return None
    near_hit = None
    for r in _active_blacklist_cached():
        target = normalize_plate(r.get("plate_number"))
        if target == plate:
            return dict(r, near=False)
        if near_hit is None and len(plate) >= 5 and levenshtein(plate, target) <= 1:
            near_hit = dict(r, near=True)
    return near_hit


def list_blacklist(include_inactive=False, limit=300):
    q = supabase.table("blacklist").select("*")
    if not include_inactive:
        q = q.eq("is_active", True)
    return q.order("added_at", desc=True).limit(limit).execute().data


def add_blacklist(plate_number, reason, severity, added_by, expires_at=None):
    plate = normalize_plate(plate_number)
    existing = (supabase.table("blacklist").select("id").eq("plate_number", plate)
                .eq("is_active", True).limit(1).execute())
    if existing.data:
        return None, "This plate is already on the list."
    res = supabase.table("blacklist").insert({
        "plate_number": plate, "severity": severity, "reason": reason, "added_by": added_by,
        "added_at": datetime.now(timezone.utc).isoformat(), "expires_at": expires_at, "is_active": True,
    }).execute()
    _invalidate_blacklist_cache()
    return (res.data[0] if res.data else None), None


def deactivate_blacklist(entry_id, removed_by):
    res = supabase.table("blacklist").update({
        "is_active": False, "removed_by": removed_by,
        "removed_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", entry_id).eq("is_active", True).execute()
    _invalidate_blacklist_cache()
    return res.data[0] if res.data else None


# ---------- GUARD LOOKUP AUDIT ----------

def log_lookup(guard_name, query):
    try:
        supabase.table("lookup_audit").insert({
            "guard_name": guard_name or "unknown", "query": (query or "")[:60],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }).execute()
        return True
    except Exception as e:
        print(f"[lookup_audit] could not record lookup: {e}")
        return False


def get_lookup_audit(limit=100):
    return (supabase.table("lookup_audit").select("*")
            .order("created_at", desc=True).limit(limit).execute().data)
